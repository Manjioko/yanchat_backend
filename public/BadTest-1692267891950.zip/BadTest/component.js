window["component"] =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "./";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 3);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports) {

var g;

// This works in non-strict mode
g = (function() {
	return this;
})();

try {
	// This works if eval is allowed (see CSP)
	g = g || Function("return this")() || (1,eval)("this");
} catch(e) {
	// This works if the window reference is available
	if(typeof window === "object")
		g = window;
}

// g can still be undefined, but nothing to do about it...
// We return undefined, instead of nothing here, so it's
// easier to handle this case. if(!global) { ...}

module.exports = g;


/***/ }),
/* 1 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__bundle_node_modules_expose_loader_index_js_PACKAGING_TOOL_webpack_bundle_node_modules_babel_loader_lib_index_js_ref_4_1_bundle_node_modules_vue_loader_lib_index_js_vue_loader_options_Component_vue_vue_type_script_lang_js___ = __webpack_require__(2);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__bundle_node_modules_expose_loader_index_js_PACKAGING_TOOL_webpack_bundle_node_modules_babel_loader_lib_index_js_ref_4_1_bundle_node_modules_vue_loader_lib_index_js_vue_loader_options_Component_vue_vue_type_script_lang_js____default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__bundle_node_modules_expose_loader_index_js_PACKAGING_TOOL_webpack_bundle_node_modules_babel_loader_lib_index_js_ref_4_1_bundle_node_modules_vue_loader_lib_index_js_vue_loader_options_Component_vue_vue_type_script_lang_js___);
/* harmony namespace reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in __WEBPACK_IMPORTED_MODULE_0__bundle_node_modules_expose_loader_index_js_PACKAGING_TOOL_webpack_bundle_node_modules_babel_loader_lib_index_js_ref_4_1_bundle_node_modules_vue_loader_lib_index_js_vue_loader_options_Component_vue_vue_type_script_lang_js___) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return __WEBPACK_IMPORTED_MODULE_0__bundle_node_modules_expose_loader_index_js_PACKAGING_TOOL_webpack_bundle_node_modules_babel_loader_lib_index_js_ref_4_1_bundle_node_modules_vue_loader_lib_index_js_vue_loader_options_Component_vue_vue_type_script_lang_js___[key]; }) }(__WEBPACK_IMPORT_KEY__));
 /* harmony default export */ __webpack_exports__["default"] = (__WEBPACK_IMPORTED_MODULE_0__bundle_node_modules_expose_loader_index_js_PACKAGING_TOOL_webpack_bundle_node_modules_babel_loader_lib_index_js_ref_4_1_bundle_node_modules_vue_loader_lib_index_js_vue_loader_options_Component_vue_vue_type_script_lang_js____default.a); 

/***/ }),
/* 2 */
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(global) {module.exports = global["__PACKAGING_TOOL_webpack__"] = __webpack_require__(7);
/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(0)))

/***/ }),
/* 3 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__Component_vue_vue_type_template_id_a1d7c38c_scoped_true___ = __webpack_require__(4);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__Component_vue_vue_type_script_lang_js___ = __webpack_require__(1);
/* harmony namespace reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in __WEBPACK_IMPORTED_MODULE_1__Component_vue_vue_type_script_lang_js___) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return __WEBPACK_IMPORTED_MODULE_1__Component_vue_vue_type_script_lang_js___[key]; }) }(__WEBPACK_IMPORT_KEY__));
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__Component_vue_vue_type_style_index_0_id_a1d7c38c_lang_scss_scoped_true___ = __webpack_require__(11);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__bundle_node_modules_vue_loader_lib_runtime_componentNormalizer_js__ = __webpack_require__(17);






/* normalize component */

var component = Object(__WEBPACK_IMPORTED_MODULE_3__bundle_node_modules_vue_loader_lib_runtime_componentNormalizer_js__["a" /* default */])(
  __WEBPACK_IMPORTED_MODULE_1__Component_vue_vue_type_script_lang_js___["default"],
  __WEBPACK_IMPORTED_MODULE_0__Component_vue_vue_type_template_id_a1d7c38c_scoped_true___["render"],
  __WEBPACK_IMPORTED_MODULE_0__Component_vue_vue_type_template_id_a1d7c38c_scoped_true___["staticRenderFns"],
  false,
  null,
  "a1d7c38c",
  null
  
)

/* hot reload */
if (false) {
  var api = require("C:\\Users\\wanzhongke\\Desktop\\ocs0.13\\bundle\\node_modules\\vue-hot-reload-api\\dist\\index.js")
  api.install(require('vue'))
  if (api.compatible) {
    module.hot.accept()
    if (!api.isRecorded('a1d7c38c')) {
      api.createRecord('a1d7c38c', component.options)
    } else {
      api.reload('a1d7c38c', component.options)
    }
    module.hot.accept("./Component.vue?vue&type=template&id=a1d7c38c&scoped=true&", function () {
      api.rerender('a1d7c38c', {
        render: render,
        staticRenderFns: staticRenderFns
      })
    })
  }
}
component.options.__file = "src/yelink/WorkStationMachine/BadTest/Component.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),
/* 4 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__bundle_node_modules_expose_loader_index_js_PACKAGING_TOOL_webpack_bundle_node_modules_babel_loader_lib_index_js_ref_4_1_bundle_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_2_bundle_node_modules_vue_loader_lib_index_js_vue_loader_options_Component_vue_vue_type_template_id_a1d7c38c_scoped_true___ = __webpack_require__(5);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__bundle_node_modules_expose_loader_index_js_PACKAGING_TOOL_webpack_bundle_node_modules_babel_loader_lib_index_js_ref_4_1_bundle_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_2_bundle_node_modules_vue_loader_lib_index_js_vue_loader_options_Component_vue_vue_type_template_id_a1d7c38c_scoped_true____default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__bundle_node_modules_expose_loader_index_js_PACKAGING_TOOL_webpack_bundle_node_modules_babel_loader_lib_index_js_ref_4_1_bundle_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_2_bundle_node_modules_vue_loader_lib_index_js_vue_loader_options_Component_vue_vue_type_template_id_a1d7c38c_scoped_true___);
/* harmony namespace reexport (by used) */ if(__webpack_require__.o(__WEBPACK_IMPORTED_MODULE_0__bundle_node_modules_expose_loader_index_js_PACKAGING_TOOL_webpack_bundle_node_modules_babel_loader_lib_index_js_ref_4_1_bundle_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_2_bundle_node_modules_vue_loader_lib_index_js_vue_loader_options_Component_vue_vue_type_template_id_a1d7c38c_scoped_true___, "render")) __webpack_require__.d(__webpack_exports__, "render", function() { return __WEBPACK_IMPORTED_MODULE_0__bundle_node_modules_expose_loader_index_js_PACKAGING_TOOL_webpack_bundle_node_modules_babel_loader_lib_index_js_ref_4_1_bundle_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_2_bundle_node_modules_vue_loader_lib_index_js_vue_loader_options_Component_vue_vue_type_template_id_a1d7c38c_scoped_true___["render"]; });
/* harmony namespace reexport (by used) */ if(__webpack_require__.o(__WEBPACK_IMPORTED_MODULE_0__bundle_node_modules_expose_loader_index_js_PACKAGING_TOOL_webpack_bundle_node_modules_babel_loader_lib_index_js_ref_4_1_bundle_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_2_bundle_node_modules_vue_loader_lib_index_js_vue_loader_options_Component_vue_vue_type_template_id_a1d7c38c_scoped_true___, "staticRenderFns")) __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return __WEBPACK_IMPORTED_MODULE_0__bundle_node_modules_expose_loader_index_js_PACKAGING_TOOL_webpack_bundle_node_modules_babel_loader_lib_index_js_ref_4_1_bundle_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_2_bundle_node_modules_vue_loader_lib_index_js_vue_loader_options_Component_vue_vue_type_template_id_a1d7c38c_scoped_true___["staticRenderFns"]; });


/***/ }),
/* 5 */
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(global) {module.exports = global["__PACKAGING_TOOL_webpack__"] = __webpack_require__(6);
/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(0)))

/***/ }),
/* 6 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c("div", {
    staticClass: "container"
  }, [_c("div", {
    staticClass: "box-list"
  }, [_vm.showObj.att ? _c("div", {
    staticClass: "box",
    attrs: {
      id: "att"
    }
  }, [_c("div", {
    staticClass: "per"
  }, [_vm._v(_vm._s(Math.floor(_vm.attData.attendanceNum / _vm.attData.total) || 0) + "%")]), _vm._v(" "), _c("div", {
    staticClass: "text"
  }, [_vm._v("出勤率")]), _vm._v(" "), _c("img", {
    staticClass: "image",
    attrs: {
      src: _vm.img,
      alt: "img"
    }
  }), _vm._v(" "), _c("div", {
    staticClass: "box-number"
  }, [_vm._v(_vm._s(_vm.attData.attendanceNum + "/" + _vm.attData.total))])]) : _vm._e(), _vm._v(" "), _vm.showObj.plan ? _c("div", {
    staticClass: "box",
    attrs: {
      id: "plan"
    }
  }, [_c("div", {
    staticClass: "per"
  }, [_vm._v(_vm._s(_vm.planData.completeRate) + "%")]), _vm._v(" "), _c("div", {
    staticClass: "text"
  }, [_vm._v("计划达成率")]), _vm._v(" "), _c("img", {
    staticClass: "image",
    attrs: {
      src: _vm.img,
      alt: "img"
    }
  }), _vm._v(" "), _c("div", {
    staticClass: "box-number"
  }, [_vm._v(_vm._s(_vm.planData.produceQuantity + "/" + _vm.planData.planQuantity))])]) : _vm._e(), _vm._v(" "), _vm.showObj.pass ? _c("div", {
    staticClass: "box",
    attrs: {
      id: "pass"
    }
  }, [_c("div", {
    staticClass: "per"
  }, [_vm._v(_vm._s(Math.floor(_vm.passData.directAccessQuantity / _vm.passData.produceQuantity) || 0) + "%")]), _vm._v(" "), _c("div", {
    staticClass: "text"
  }, [_vm._v("直通率")]), _vm._v(" "), _c("img", {
    staticClass: "image",
    attrs: {
      src: _vm.img,
      alt: "img"
    }
  }), _vm._v(" "), _c("div", {
    staticClass: "box-number bad"
  }, [_vm._v("不良数 " + _vm._s(_vm.passData.unqualifiedQuantity))])]) : _vm._e()])]);
};
var staticRenderFns = [];
render._withStripped = true;


/***/ }),
/* 7 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__request__ = __webpack_require__(8);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__request___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__request__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__img_png__ = __webpack_require__(10);


/* harmony default export */ __webpack_exports__["default"] = ({
  props: {
    // element 是组件本身定义的数据（register.js），可以通过 element 去做
    // 数据绑定等操作
    element: {
      type: Object,
      default: () => {}
    }
  },
  data() {
    return {
      img: __WEBPACK_IMPORTED_MODULE_1__img_png__["a" /* default */],
      showObj: {
        att: true,
        plan: true,
        pass: true
      },
      planData: {
        planQuantity: '',
        produceQuantity: '',
        completeRate: ''
      },
      passData: {
        directAccessQuantity: '',
        produceQuantity: '',
        unqualifiedQuantity: ''
      },
      attData: {
        total: '',
        attendanceNum: ''
      }
    };
  },
  computed: {
    show() {
      return window.__ocs__.ocsMethods.getComponentVariableByName('show', this.element.id).value;
    },
    attendance() {
      return window.__ocs__.ocsMethods.getComponentVariableByName('attendance', this.element.id).value;
    },
    plan() {
      return window.__ocs__.ocsMethods.getComponentVariableByName('plan', this.element.id).value;
    },
    pass() {
      return window.__ocs__.ocsMethods.getComponentVariableByName('pass', this.element.id).value;
    },
    attTotal() {
      return window.__ocs__.ocsMethods.getComponentVariableByName('attTotal', this.element.id).value;
    }
  },
  watch: {
    show: {
      deep: true,
      immediate: true,
      handler(val) {
        // console.log('val --- ', val)
        const [att, plan, pass] = val.split(',');
        Object.assign(this.showObj, {
          att: !!Number(att),
          plan: !!Number(plan),
          pass: !!Number(pass)
        });
      }
    },
    attendance: {
      deep: true,
      immediate: true,
      handler(val) {
        if (!val) return;
        const el = document.querySelector('#att');
        if (!el) return;
        const [per, text,, num] = [...el.children];
        const [perStyle = '', textStyle = '', numStyle = ''] = val.split(',');
        per.style.fontSize = perStyle.split('#')[0] + 'px';
        per.style.color = '#' + perStyle.split('#')[1];
        text.style.fontSize = textStyle.split('#')[0] + 'px';
        text.style.color = '#' + textStyle.split('#')[1];
        num.style.fontSize = numStyle.split('#')[0] + 'px';
        num.style.color = '#' + numStyle.split('#')[1];
      }
    },
    plan: {
      deep: true,
      immediate: true,
      handler(val) {
        if (!val) return;
        const el = document.querySelector('#plan');
        if (!el) return;
        const [per, text,, num] = [...el.children];
        const [perStyle = '', textStyle = '', numStyle = ''] = val.split(',');
        per.style.fontSize = perStyle.split('#')[0] + 'px';
        per.style.color = '#' + perStyle.split('#')[1];
        text.style.fontSize = textStyle.split('#')[0] + 'px';
        text.style.color = '#' + textStyle.split('#')[1];
        num.style.fontSize = numStyle.split('#')[0] + 'px';
        num.style.color = '#' + numStyle.split('#')[1];
      }
    },
    pass: {
      deep: true,
      immediate: true,
      handler(val) {
        if (!val) return;
        const el = document.querySelector('#pass');
        if (!el) return;
        const [per, text,, num] = [...el.children];
        const [perStyle = '', textStyle = '', numStyle = ''] = val.split(',');
        per.style.fontSize = perStyle.split('#')[0] + 'px';
        per.style.color = '#' + perStyle.split('#')[1];
        text.style.fontSize = textStyle.split('#')[0] + 'px';
        text.style.color = '#' + textStyle.split('#')[1];
        num.style.fontSize = numStyle.split('#')[0] + 'px';
        num.style.color = '#' + numStyle.split('#')[1];
      }
    },
    attTotal: {
      deep: true,
      immediate: true,
      handler(val) {
        this.attData.total = val;
      }
    }
  },
  mounted() {
    this.getPlanData();
    this.getPassData();
    this.getAttData();
  },
  methods: {
    getPlanData() {
      Object(__WEBPACK_IMPORTED_MODULE_0__request__["ocsRequest"])({
        method: 'POST',
        url: '/api/v1/open/ocs/screen/work/order/today/complete/rate'
      }).then(res => {
        const {
          data: {
            code,
            data
          }
        } = res;
        if (code !== '200') {
          console.log('code err ', code);
          return;
        }
        const {
          planQuantity,
          produceQuantity,
          completeRate
        } = data;
        this.planData = {
          planQuantity,
          produceQuantity,
          completeRate
        };
      }).catch(err => {
        console.log('error --- ', err);
      });
    },
    getPassData() {
      Object(__WEBPACK_IMPORTED_MODULE_0__request__["ocsRequest"])({
        method: 'POST',
        url: '/api/v1/open/ocs/screen/work/order/today/through/rate'
      }).then(res => {
        // console.log('getPassData res -----', res)
        const {
          data: {
            code,
            data
          }
        } = res;
        if (code !== '200') {
          console.log('code err ', code);
          return;
        }
        const {
          directAccessQuantity,
          produceQuantity,
          unqualifiedQuantity
        } = data;
        this.passData = {
          directAccessQuantity,
          produceQuantity,
          unqualifiedQuantity
        };
      }).catch(err => {
        console.log('getPassData error --- ', err);
      });
    },
    getAttData() {
      Object(__WEBPACK_IMPORTED_MODULE_0__request__["ocsRequest"])({
        method: 'GET',
        url: '/scr/center/screen/get/attendance/info'
      }).then(res => {
        // console.log('getAttData res -----', res)
        const {
          data: {
            code,
            data
          }
        } = res;
        if (code !== '200') {
          console.log('code err ', code);
          return;
        }
        // console.log('getAttData data  ', data)
        this.attData = {
          total: 0,
          attendanceNum: data.attendanceNum
        };
      }).catch(err => {
        console.log('getAttData error --- ', err);
      });
    }
  }
});

/***/ }),
/* 8 */
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(global) {module.exports = global["__PACKAGING_TOOL_webpack__"] = __webpack_require__(9);
/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(0)))

/***/ }),
/* 9 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }
function _defineProperty(obj, key, value) { key = _toPropertyKey(key); if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return typeof key === "symbol" ? key : String(key); }
function _toPrimitive(input, hint) { if (typeof input !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (typeof res !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
const baseUrl = localStorage.getItem('baseUrl');
const requestHeader = {
  // 请求头
  Authorization: `${localStorage.getItem('Token-Type') || 'Bearer'} ${localStorage.getItem('Token') || 'eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICJmQm9wV2otVTFIYjlTa0ZHMHZYQ1lRVVhkRkdDMGhXRTBkVjJCN1FaSl9ZIn0.eyJleHAiOjE2OTE1NzM2MzEsImlhdCI6MTY5MTU0NDgzMSwianRpIjoiODdlZDcyYTItYTk3NC00ZGIzLTllODAtNzMxMDc4ZmY2ZDc4IiwiaXNzIjoiaHR0cDovLzE5Mi4xNjguMTAzLjI5Ojg0MTEvYXV0aC9yZWFsbXMvZWRnZSIsInN1YiI6ImJhODRlZjdhLTI3ZTYtNDQ3YS1iMGI1LTI4NjY2MDFmMWNkNSIsInR5cCI6IkJlYXJlciIsImF6cCI6ImRmcyIsInNlc3Npb25fc3RhdGUiOiI4OGM2NzMxNS1hNmY3LTQwYjAtYjc4Yi00YTI1NGMxZmRmZjMiLCJhY3IiOiIxIiwicmVhbG1fYWNjZXNzIjp7InJvbGVzIjpbIueyvuWIti3ns7vnu5_nrqHnkIblkZgiLCJhZG1pbiIsIueuoeeQhuWRmCJdfSwicmVzb3VyY2VfYWNjZXNzIjp7ImRmcyI6eyJyb2xlcyI6WyJhZG1pbiJdfX0sInNjb3BlIjoicHJvZmlsZSBlbWFpbCIsInNpZCI6Ijg4YzY3MzE1LWE2ZjctNDBiMC1iNzhiLTRhMjU0YzFmZGZmMyIsImVtYWlsX3ZlcmlmaWVkIjpmYWxzZSwibmFtZSI6IueuoeeQhuWRmCIsInByZWZlcnJlZF91c2VybmFtZSI6ImFkbWluIiwiZ2l2ZW5fbmFtZSI6IueuoeeQhuWRmCJ9.Ofi4-4wtn80sq7-F9vxrHY2AYSoXL4tto0UmEv0qhMGnHyFtRez0m32C0DePYUJvWdPykwovYdOs7-yad5Gh978st3cO5qCb2ySXWoWOrBDo0E5jKldoovC0Vh_U0wLJTrQ1reTfJNhlK3xZDaDCARWmEZBP_18iFoACP1_m3vj3BIxJAN7ROi-jDCODapfYEjHDzLWscQWQw9832NVv_R_Yo0CRF0E56wVwwWkay0n2YCpyT93kox8dRMLXVmnAMLUkkMrepQpX6NJRwjXeC_nrCDQZ8lIOU9t98LFdYXoW7jm2z2ZJh_sybkDd6Z-KrnWHBfwQl6U4Np-XG0Iw5Q'}`
};

// console.log(baseUrl, requestHeader)
// console.log(window.$axios, 'window.$axios')
const ocsRequest = _ref => {
  let {
    url,
    method,
    params,
    data
  } = _ref;
  return window.$axios({
    baseURL: baseUrl || '/prefix',
    headers: _objectSpread({}, requestHeader),
    url,
    method,
    params,
    data
  });
};
/* harmony export (immutable) */ __webpack_exports__["ocsRequest"] = ocsRequest;


/***/ }),
/* 10 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony default export */ __webpack_exports__["a"] = ("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAZIAAAGWCAYAAABSEwXsAAAAAXNSR0IArs4c6QAAIABJREFUeF7sfQmYXUWZ9lfn3LVvdzaSAEKUP67DliDOOPz+jjjjDo4gRBFxYRxBUYYk6DCb0hBQXEgCqCg6iiLqEDdccUZJQGUUwYSwuSAS1pBO0kl33+67nu9/zqntqzp17r3dfbvTnZx+Hkj3vXWq6tTyvfV+WzFIf9IRSEcgHYF0BNIRmMQIsEk8mz6ajkA6AukIpCOQjgCkQJIugnQE0hFIRyAdgUmNQAokkxq+9OF0BNIRSEcgHYEUSNI1kI5AOgLpCKQjMKkRSIFkUsOXPpyOQDoC6QikI5ACSboG0hFIRyAdgXQEJjUCKZBMavjSh9MRSEcgHYF0BFIgSddAOgLpCKQjkI7ApEYgBZJJDV/6cDoC6QikI5COQAok6RpIRyAdgXQE0hGY1AikQDKp4UsfnlkjsMKH4w5ZkANY5DW8hcxjCxnAQsa8gxjDHkRWQIS850Eu/BcA8ozp3wEgAwxqDKGKAFUAqAGDKv8bawCsyhhUEYMhANiJ6O1ErO8Mmpmd1SzuhC3r98ys8Uh7k47A9IxACiTTM85pK5MdgWM/UMqx5hEZxp4FgEcwBs8EhP/DgB0GAIsQcCFjbMFkm5nM8wjQAMRdIcgAg6cB4TEE9ghD3NYE9ggEuK2SKz8Gd19Xn0w76bPpCMy0EUiBZKbNyIHcn+Ur5xUBjmKIRzPPey4DdgQCHAEAzwqZRbuhQYQyAA4Cg92AsJsBDCJj4e+DDGAEIRgLWQYyqEIAEbsIQsbR5EyDAasjYh49yEfMBTCPTDCXkMEwyDPwcgg4H4DNB4AFDGABMpwPCAuAhX+zbKt+ImATlxw+hMuOCaAZPBTkMndhpfoEjFW21YqlO+Gjr/4TMIbt3jX9Ph2BmTQCKZDMpNk4UPpy5Hm9xWz+SA/gKAj/89jRgHg0ADyDMRZbkwhYB4QnGIPHEOExYPAoIj4OAXsUWOPx0XrhKSju3TUjTvpHntdbgMwC5nuHgYfP9BhbAsAOZwyWIMIzAWAJLjn8YHzx8c7Zxnq9Bo3mHzCb3QTDI4/A0Mh91T1P3w4bVocgmP6kIzAjRyAFkhk5LftVp1juqPP/IuNnTvA89tcIeAIA+wvGwHO85V4AeBARfgcQPIjM+10TGw9Wtzz1MMCG5v4yKoVLfvpW5me+2un7YBAgjI49jn72hzAydD/uHLq1duM/PNDp82m5dASmegRSIJnqET7Q6n/+P/eVeuovxoCdwBiewIC9OFT50GHgtgS4nwHcCQD3QBA8GNThwdEH1z91IAxX8dKNZ4DHvj6Zd8VKZRSazV8Dsp8FOwfuqz0U/AQ2nV2ZTJ3ps+kITHQEUiCZ6Milz4kRWOEXly95MYPglR6wVyJjL2ah95OBHPgwMrgTAvxNE4I7KwOV38KT140esEO44iY/d9whz4cgOMpDPAqBHcVCFR+D5zCAljaWpDHDRqPJxir3IMJ3GwO7b2986e23HbDjm774tI9ACiTTPuSzv8H88n96rg9+BBzA4OUAMFe+FWLoMou/RsSfQRPuHK3X74TffTr0ZEp/2o1A/025XHbR8wDhKA/ZUcjYkQwwtCOFAGOCc5u6sFodxWbwExgdvZ3t2n1z5YZ3/7ld8+n36QhMdARSIJnoyB1Iz73gfQcV87m/81nIOOCVDOBZJuHArYDwP8jYraOBdxts/WT5QBqeKX/XtXcUC8Ojfw2+/xJA9lJgcAID6Ou0XUQENjq2PWDet9ieXXdWHnryW/DfH0znqNMBTMu1HYEUSNoO0QFa4NgPlHq94HUIeDoAO4kxKBHWsQ0Qfxog/mwMKj+DrZ/dcYCO0r557RU3+dmjDlrmhcAC8FKPwf8DgEM77QxWamPQqH8r2Dv049qDv78JNvU3On02LZeOgGsEUiBJ14UegeecP6fUmzmZAZyODF7DgBU1eOAWRPZtDxvfGdl69X3psM2sEciv+eWzGdZeCoy9nAGcbDs4JPUWa/UKNBrfhcGhH1bu3PNfcPe5abDkzJraWdGbFEhmxTRNYSePPydbDHre4CM7Cxl7NQMoqNYQ7kAIvtMMMt+qbP1kqmOfwmnoatX96GW8jSdkmHcSAJzMGBzTSf1Yq9Ww3rwZ9wx9rXbtm7/byTNpmXQEwhFIgeQAXQe5484/Mhtk/gEYvJ0xtkiDB94RANwIVfzOgeKOu98vgYt//sx8pnYSY/7rAeHljJHDQtLLj43txFrwWRjY8Z+V689+ZL8fo/QFJzUCKZBMavhm2cNHntfbk8ud4THvXQDw10ptBfgoQ3ZDvY7XV+9f99Ase6u0u+MZgf67evJ++RWMBW8EYG9sa7QPAsRq9TYYGv5y5d4HvpraU8Yz2AdO2RRIDoC5Lh67+q99D0LweDMw7u0T5aVi+G1osi+Xt6792QEwDOkr2iPQ//2eQqb3VADvbQDBKxgwv9UgYaVaxkb9S8HAri/W//Mdm9MBTUdAjkAKJPvrWnjO+fmekv8O5rGVDNhfKPaBcDsAfrE8tvfb8PsvDu+vr5++1zhH4PLbD81j860esLcBwLEtASV0Jx6rbMW9w5+sfPpNN4yzpbT4fjgCKZDsZ5Pae+wHFgde8F4GcB5jsDh6PcSRAOArjQZ+qnbf+gf3s1dOX6fLI5C99NZlnuefxQDfytq4FeNY5WmsVq+sbnv8WtjwvpEudyWtbpaMQAoks2Si2nWzdPQFx0LGXwUAb2E89XkIIH9EYJ8pD418CR6+LkyImP6kI9D5CKy4yc8vX/gKhn6o+jqdAePryvGDtfoY1iqfZ08Mrq/c8PbUw6/zUd4vSqZAMrunkfUsX/1axmA1IP6tTMGOCD+AAD9d3rrultn9emnvZ8wIfOTXBxWC0XcDeu9lDMN0+G5AaTYDHKve3Ny56+rGF962acb0P+3IlI5ACiRTOrxTVjnrOWbV37MMXMqAcX024h5k7IuNev0z1fuu+dOUtZxWfGCPQJhw8tiD3+AxfD+DKM+aG1AQAUZHf94Y3P3hxmdTQNnfF00KJLNshnuWrzyJMRYCyAt513EAA3ZluV75NDzwmVRHPcvmczZ3N3f5xqO9AN4PDM5iwFQKHfpOYZ4vHB3d2Ny198ON6878xWx+37TvySOQAsksWR2lZRe8mjHvYmDshAg+ALYDwCfKA3gtPL4uvT1vlszjftnN/o3zir73LmB4YVLOLwwQcGzsJ8GOgQ/X//Md4T006c9+NAIpkMzwyexdtvrl4OElAOylAkCeZAAfGxncfR08cn16kdEMn78Dqnvn/yifX1Q8m3nsIgZwhOvdMfwpj/4weHr3xfUvve23B9T47McvmwLJDJ3cnqNXvcjLwCeAsRMFgGzDAK8YrT/+RXhgQ22GdjvtVjoCAP0bM4UsnAXI/pUBPC8RUEZGb2YDT19Y+eI/PJwO2+wegRRIZtj89fzFykNZ3vsIQJgDK7zXHHchemvK/vBn4O7r0sysk5+vyax5nHzzB1AN/egVM7e+GcH/NwZwtBNQGs0GjpQ/Vf3Dgx+G712UBsjO0uUxmU01S195hnb7Gef09Czu+aAH7APAWC8CVADxmvJI4zJ46JqhGdrrfd0tsX47le+XdGG9X9xBY0YzHZTf18M49e3n1mw8xQfvP4Dh8c7WqrU9wfDQv1XXn37t1PcmbaHbI9CFjdXtLh1w9bHS8pVnArArGGOHR2osxK8GDfZvY/etfeyAG434C7cACwEM/QBw//0MYIX19AqAgU1Ts8YXnSgAYoPV5gaAo45CCPsU/biAR3XpgAOZ3GW3n+ZBcAUDeI6ToYxVfoe796yuXnvGj9O1P3tGYGo22ex5/33a0+LylS/xmfdJmYkXAX6GzeCfR7euPxCNkAmAcQmLhLIBFA6AGO6Lr+WxhxkcFV55DgAj27q31nufxQHgfgAojsXBoG/Y/CwCHQE4Rz3QAmQOEIA5565sfsnweR6DDwGwg+xNGLkMl0dvwd07VtWuO/t3+3STpo13NALd21wdNZcWikbgmPfOL/mFKwHgnWE0OiLchyz459HN6w+UUxiLHJiNHwdgDCzS65MCxdKHGYz06u/Cs+1wkf9dzptrurKLp4uq7mJwsGzwkAksxO0AT4vH8gchwFP8j0L4u/x5HKC0COFpAi4SdB6Wn90N0Pc8/owTYGwGsx+DS/+v5uT9yn8wBucbF6qJ4cRmo4lD5bXVTdv/Pb25cQJLdhofSYFkGgc7bKq47II3e8y7ijF2cJhMERE+XL7n8asBNjSnuSvT2ZwFHBI0jhTrjzAMAzCKTDGJg0OgOAKg/BR/ppJjMC8ECQEKfbvF51kGsJC/W3WPqP8ggNpe/vt8AKgNk3U/L2Ec9pif5/oQBsVHubkIsIv/kZ/HQaHQ5P8O7AAoLBDgsh1gTw012FhAE4KME2AG+PNHrUDov8ShHou6v9+oxQqX/exZAJnLwySRrsnASuVPjd173934zJs3TueiTdvqfARSIOl8rCZVsrB85RE+Y9cyYK+JKkL4XjOov29s6zWPT6rimflwa+CQTEOCBmUYIWBQVlEY9iKwqOxmsGgxQGWQQTXD120tw6AUgsI8gNoIg6LPPx8dzcKIF6LJQh+9BRDgXPQzcwChB5ifC9DLAHgZ8FjGQywBYAkD7AGGBQBWZcBGA2BlYF4ZIGgABg0PsAGANWDBGAtwCDzc22TBbsg2dkGu92noCeqQ60UYE4CSa3LgyTXQABsJNE9vB8hLkHkc4JDeAMIrxUJwmT+GcHf4IpS9SHCRqjHKXPYPYMn2b3yR77OrGYMo6Jb+hOEnMDRyQ+WJx1bC186TkD4zV/8B2KsUSKZ80lf4xeVLzvcB10TeWIiPI8D7R7esu3nKm56+BloAh4NtLBVMg4JGxDCyTAOGzyJGQcHCH/Ng53Ap0/Cfjyx3BLLswQH4ixk2XgABOwKYtxjAK0KY/Tg8r4erOzq3syk4vSNT9fN26gDBWOiuDQCPoOc96GFzB7Dm9oDVt4EHv4NDD9obAY0NMiGbGW7wPu6pIxRqCGCBi2Qu0v6yKAlYZr8qLH/pxvd4HvsoRCcE66dW293cO3xe7arT/mv6lnfaUrsRSIGk3QhN4vueY1e+kPns82FeLARoRO68gf8h2PrJ8iSqnSmPmuDRfwmD+4WqKsY4LOCwQWPvsBepm+oZBvPmAYSAMTK60B/xX4iYPRaZ91cA7FkA7GAAv1dAxAQAwkCXDsdRotFktooEHRwFwKcBcBsD3My8xuamh3fDM+Y9FQFMOQQZwWAUuGwHqPQFUWdLVW5/oayFAotTFTZL2Ur/LxcX/NqVjLGzHOwEoDx6Czyx67w0ZX2Hy3iKi01md0xx12Zx9cefky01ey4B5n2QAWQQ4U5EeM/oPWtn+/WkBDyonUOwDqWqagEcfVmumoqYhs8i0BgYWeo1CycAyx6JAR4PzHsOgD8PwjM/tmMTyWSDQoCCEARgHgsVJcDCt+n03wCZUZ4SnsSl2mZ7MWScOeEwYPAn9Py7vaD5YODXfgWHzXvAAJe5fYGyv+x5lNtdKLBEjEWowlqzlSlgZ1O3VwuXb3o5IHzWFSGPjUYVh4ZXVdeemsaeTN0UdFRzCiQdDVPnhXLHXPiCbCa4MWIhCDVAvLh8z9yPA/TzU+Xs+3GDB2Ud0sYhVVWUcUjgKI950HMQg2B70R9iJ6DXcwwi/F8A74UA2QUAyJJVUC1kH2MYCuNQyMfNz1MpM5OZSoQNEUiF75T002rrhQwGhwHwt+ixOwCr98Kc7M8hmx/RrKWBMByqwRYgVMp8bY3s4f8uWRxENpaQrUjPsBhbmUVMpf/+XCE7cBEg/DsDcWkbGVYcLv+48uSj74Qb3rtj9m2v/aPHKZB0cR57jlv1HgbskwyghAj3I9bfNnrPNbORhXQAHhbrmJ9jMDjsAWUc2TEP6o28P9L8O/RLL8EAXwYs8xxgLJfMNOLCP/KQDsHCmKtug4TkLF1cEKoq3XMFMpLhGM0lbccIkJrAgj8jsJ8Da/wSCj23QAnLClhqfQEUGqhsLIqtjCA8vBT3B1DJr7ntuQzwPxmDKIGp8VOt7wr27n179erTfzQVM5jW2XoEUiDpwgrpPfY9i9ErXs8Ye21YHSKuK480/hUeuqbaheqnq4rxg0foURWyj75DGQyPeFJVlX16aEkTi69EyLwKIPMSAK/HzTbcoKGZxbjAAmOUZFyPT3CYY8Qk2lLj2FcmyHBmRn9cVUVlQuP+b9DHWyDj3QIHFx6CsV0I9WIAecFW5vcFMFiLq8BmM1Pp7/eK/stWIYPL7at/I8+uvUNfrNy/7X3w43+aTXtvgotv5jw2jgU/czo9k3rSc+yq1zOPfYExWIwAjzEM3j6yZf1suWI0wWBObB62h1UEHoczyIUG8gyDkHVkch7sGjzOw77XIsDrwcs9GzBSNlEFRMyqYDKNdlKfGxO4UUOosSx1ltMmoqQ6NbQnVKDdvES/W9cYHRrIWyXVqvurSrQznvD2w9kJhKFefqBaNMaWAQseQ4Afghf8GOZ5vwQv14TyToS+JQEMP4UQAxXKVIQH2IYHxCSErsUzW/WV6994tJ9hNwDAclseYLX6UHPX4Jn1z5zxm5kkK/bnvqRAMtHZPf6cnt5m71UI+C4enY5fLfu598PdH9s70Sqn8TmTfawg3lahwdy2eSSAR2bX0IsCKJ6EyE4Blo/yhMXBg3zCmDCdtwUNXsBRLL5g7ULtjPNuEOoIQ9pOEGUT7q0VeyVVzAZeuzFeENsylrAPuBMBbwa//iMo1W+H/LxGpALr63WDSmRTIYb62WJP6b8pV/AWXQIefJAB8w1obTabweCeS2rrT1vTdtrSApMegRRIJjCEuaNX/kU2432TMTgSAIeaTXzX2Nb135xAVdP5iJt9hEZz6m1V2uFFAYG22ipkHtjw/eH6XyH0vA4D/w3Asoe1Ao/OGEdIMUzQMLVFtsuuBRQxSuDiCFM1zC7GYlEUo2kJNPo5p0OyJi4J+1N87GQs1ruyYDcCuxm8+i1Qym2EvN/gTKUYQL0vgGIdI/XXQBVh0eKAB0PeDbD0nCDKD7ZhBQLI6PqZyVKKl976EvS8rzCApbGjzMjopsq2x1bA18/dOVWrIK13XLrcdLjCESguW/lG32NfAmBzEOGeRh1Pr96/LoxJnqk/ybaPiH0Io3nviAfzl2qD+XDBk2qr7O7BZzWDntMRMmcCyz2zHXhwJpHIOrgtw/rathQ4bSrqmXaMRvYw9K/V6qduT5AGgVbeWaovZvMGRFCA0cWMt+SEpSWwRF5imuFYryuYCmPfgNzYN2B+5kFohmBSDaJgyNC9OPT+sl2KI3vKAMbTtXTA/Lo94K3q+8BPSoW5uTDu5NwYmFRrjzUHBk6vf/at6RW/UzQnKSPpeGD7M6XlQx8FwAtFosWvlnfiOTP4vvS4+spw2S0yMNiHsHuEzMPPezA42OdVS3+PmD0DWPavADxDdaCQQMRlJBvI3YzDFJdEKCnp7DyrR49xcLBBQpR32VASjRcdT767YAyl4rDVGmys8jFwSWAubdVhIjxFucY5tjkLtjIIvhHM8W+CYn0PNKtBZKivjQXKnkJZyh9mB6DkLrn1NM/3vsQA+uikhQkgYXD4vMr6U6+b5KynjztGIAWSDpZF6cjzDoFc/huMsZchYhUZrBzdvO6zHTy6L4okAMiJAM+7m8FjOzwI4z1yfR531xUeVyGA5DHj76i+FKFnBTL/ZMBMyXwBfUYO1VbJzCMJPOTzFnCoRpLtHdJCEBVNxpgkgd8phel8vnA8nlmUS9jcy8VmyLZUv8ZZi8VYXGihhkt7g9nFggYyuAVYfQMsLN4C1XID6pVAqb4oS5G2lKXzAwdDaUlDOx/YyZfMf3Tjc1iDfZsxOMYAk3BZDo98o/Lnu98BG/rT66onP9SqhhRI2gxmeGeIx7xvhmlmEWAb1vH00fvW3dXFOehWVW4AocZzpb4qepHXlWQfQ2NFr+ydjpA/F1juBRMCj9D1UhygHTYOLfMS1VMuhtEKNCIqFNeRJY0mAZ9xRbSTyHfDW6yjWYuMGGGgZRtGIxmExEg7nF/bRAiTM+rtTA3GeJCkU/0Vqb4eR4ZfgN7gy1DCIcVSvGIzsqXUhgOeoiX0+BpEmMmA0v/9noLf93nG4Ex78IOx6r3w+COnVr987p86msa0UNsRSIGkxRAVl616v+fBWgYsi4C3lBuVM+Hea2da5tEWAFJkcMg2BttHPCjM9aDvcAZhXius+5HL7uDgIR72vgMxczaAv9C0SwjR1NLTSjMPcyFFUtsCDzfbiDEN13xwOdv+RwUttis+Ef1+OzuIAAORdqU9X4kKxvefQ8i39NSKyptspT2oyFFP8jLDUfTgq9DTuA7y5W3gHdSMbClS7VU7KICnGwi9NYSHfzGjASV/2e3vYRhcxRjkDHZSawzj4N63VK857YftF1Zaot0IpEDiHKEVfs9xh6/3gL0//DpA6B/dsjZ0XZlJP60BhNo/siUPpPEcG35mqHpMgH3vRpY5FcDPuxkIZwhxo7kJHvKgL87SXN0VUZI4cHCmInRCSeqpJNBQzMClUxoPMIRZRLxwVif4b6dLwBTS0XuzkBG0CldsDy58VBOCFg01mGP2omxh9KeNLYVhgAA/Aq/2OZiX+RU0agGwbBPCKPr5YwF0BijtUL3TAZ1wueylm/7S93ADixJ/6h9sNhEH91xQXX/aNROuPH0wGoEUSOyFcOR5vSVuDzkptIdAgGeXt67/+gxaLxMAkJwHvTU/s33nMc1m74UAudcAeKE0FT/E9hExCXvvmzYPU8tPmYcbPKhh3iHH4kPrZBatwKJNGrPx2lQ6mey2O4cMb6w+G2Ra7EQnbuqtm8hWWoFK9F0cVPixweVBhuGp4hfgNz4Oh3t3wOB4AYXTpk6GdcrK9N+yoOAXbmQM+H1AcuWHS3tw6NrK2jecN2VtHwAVt90OB8AYqFcsLlt1mOfB98KEi4Cwu4GNN1TuufoXM2cM5Ca/hEEYRChjQEIX3kNyDLYPeFH8h2IgEkB2HdmsFy8Er/A67X1lGs6licN81/DybDOQvFPm4QSP0EBvyxMn03CBBmUQSbYT+pxGD2qzoZgy+c/DE72LYoh5Mo1FFgNyrSpuG0lmLkmMhdpYHOoqpf4yjwDiGBm34YTMKRZRz/uLLLgdMs2PwWHz7oTBnRZDaWdD2ceA0t/v5f2Xfdxj7EJ79HFo5EeVex9+Y5paZWLSLgUSMW6loy84FjLejxhjhwHi7+t1OHkGxYcIFhKmbr8Y4P4NDB4e9GDpfH53eWhED20gFEDyezIwUH4+w95VAPm/N913JYg41VdGnIdWkEyEeUQoET+JRuCk+xBfuhbDUDXYQGGD3MQ2wVQ9xbttbzECMkbDLgaj2UGihcZmLIRomGyFGuyjTMscGGQfYnEqst/S8G9ZwVhwK+TYFXBo72YNKMJ1WBrlQy8v6TY8gwIb82tuO5cx/FR4xQOdgmB07LfVJ7efBNefvX2q1sT+Wm8KJADQs3z16zyAbwCDPkS4vdzMnQL3XjETjOpajSUvjqIsJLSDhG68maIHA2M+ZDkDgad2PMdrllYhK54C4GXFWVKtYe66m6y+MkWMEN5RcfqMACEatyFFEwWPGOOwgaUdaChnsDZOU4IZhP3xGBomkKnavbapJbo/Rea0dzdqMiIJp60YDK2nDWNxgIpuj0CRodXioGIZ6OO2lARvL/SCn0A2+DgcyrZqlRcBlLKIlleAEubzktcEj8e21d1JzK+57VWMYeiNacab1GqPBo/uOLl2/Vn3drfF/bu2Ax5Iepateg/z2DXiAqoby/7I2XD3dfV9PO3t7SARgAx7sLfIvbB6iz4MDhzklXtWIiueDeARLxV5Nk6wfwgpEmMfSeAhxY6SPnHmwZUYSayDgEdURAoUaqtJmoGQMI1XAE2Fen6cW4c43cbUKkY6S80ETEKTxFgECMSIj0WFBHjEWEqSLSXRjuJgKCF8suCbUGhcBov9J6Gc415eodvwwgUBDD6EEAJKePnW0oetGJR9p+7KXXrbMZ6H32cAphG+Vh+DPXteX7l6xc/2sRyYNc2PczfMmvfqqKM9y1de7DGvPyocsEtH7rny4o4enNpCphpr0yYvyoUV2kFCBrIrVGP1epArepDNexDUfKjtzXvD/tsQSh8EyCzoiIFYcR+tbB/hLUtxm4cFHp0yDwUcbhuGGlrKLJzjnWxBV6YJeY9J0k2Ijuy9simDObS6SdF5r4jSF7VO0BIxmjCuI74NefvUBkPviJ8gqOiBEUcBy7BObCnG6Lq8vVwMheEYsuAaWMg+DU0cBW+0CV62CfVyEF0XPLIoSHYZ3keAcvlPDy4Gme8Dg780uF+jEQQ795xW+9Tp353a7b5/1H7AAklp+YUfZww/iIBNRHzP6Jb1X9jHU+pWYy0a8LgdZJ42pAd1H4IeP0qiuHPklQHr/RCw/PN0/1vZQLgBPeIB0f8jkcE/MdRdxH5iaLQsLYjBWihTcLGOVuHgrZiGg1EI9Zlb/EwFA2m3OhLAIPGmxIStF2JEwjCZNhdqa7GBhairaDO0XvV5BFaklDSfEPuMwkWXp5fLhoLbMYOXwTMrG2A00wQ/14RGJYBMoamCGg37yT5Wd629o5gvV7/mMXaKASbNZtDcvffs+lVv/Eq72T/Qvz8QgYT1LF/1KY+x8xCgESCcObZl7YZ9uxBaeGNRO0hjzIdmzYeg4Wd2jR7dbPT+B3iFE03BE8UrdGgDkWlOJKBE8MI7Y9s+iBo9OtiKQPZYckUMhAVcq6uciyyEM2ljMAbfVG9FObUMRhBKQ3m07mTW5Nla+J85L2lPuliENBy/eWQce0dRAV6LrDamo0uo0qEW04wlmiz+oHqcAgtnPGb8iuX9FX4fPW6Bgu6OVoBF7bjiUeLeYsiCe8CHD8PB3v/CyFiTx6BY9pNQ3dWV1IB8AAAgAElEQVT3A4QTLw6gf99mGS6u2bgeGLvAAJMAsbln73vra0/5XCer7UAtM47NsD8MUb9XWj70ZcbgLASoYBPfNLp13ff34ZsRFgIMNl3iwfDJWo2VG/FgUKixlB1kV59Xzl2IrPSP2g4iKYbrvg/twsvf081AnOorOzjQCR6UeXQAHrHBttiDvINd9bXt7OgK9gURsbtHTvrxwEHXu4gH5Eowot07A5bOmIo4H4Ro05KlWA4AsrCl9uIfU0CR/NaRE8wLboK5tYthbnZnZD/xypa6azPCwKIgyjIceXcpzjztM1pYs+lSxuBDBpiEVy/uHryouu6Nn2i7Gg/QAgcOkBx/TrbULH2VMfYmQBxpIPv7yj1rN+67eU9gIYt3eKYaq+RHdpBQjbW7/KoAei8HlltCs+3y827IJOi+s9OXCABRRaj6i4Z3OGwfFHzUgAkAITYPczGJemKxgoRxEBtG3IssAXGSTSPigQAYeBC6bWkeYN9kyNQB3bCFkCbtz0P1T3J9vD0eMd/iR1UQ/dJi79F0K0lpTGRYimljcTOVuOqLMyOyYiIA06DG34KqvQwA4vEuUuLbDCViQKQ+fijYg37zEpjb/DrkWCOm7pLG+DBt/Ykn7lN2kr9s02oP4EoLTAB27VlTWX/qh/edzJi5LR8YQPKc8/Ol3sx3ojvVEQabQfO1Y1uv+vU+mpY2LES48yo1VsGHvTuW+JVSf+AVTtJX2IpzaFyNpdRa8ozosoG0ZSAq1sNh90gEDyF72oBHcsp5NSP85VqeR3kjRPvS/vRK1VoTnfx2FxnqVyDCtgXAtGUw+g0jSFGMxbF1LRWYZipJ9hSXLcWt9jLyeRF2oqbJwVB0gkjyDh7eAcXGRTAv+3ul7oq8u8oB/E4Y4wd27HN2Eubo8iC41gYT3D24rrrujasnunz21+f2fyA54p2F0rwF32MMXomIT7Og+YqRrVfft48mVHtk0ch0xUJKHgRjvnLnbVRy3lO1d6JXugjAF/7ulEnY0paqscbPQLickhZZCSBu5qEsD1Lix1xyibrN6KYt70k/1RGXzg5lFppJaHlN0vM6n98HM20YdcyYRJPZhEzG8UPQ0fxWcyI+/u5gwYgYWQZ7A1RU/Q5biiE5dey7ds0gqitb3SWfVQwlKZcXNtDDq2BOcBX4bEx5d0lj/AxhJ4VLN54FHlwfu8Z3cM8XKlee8u59sLJmbJP7N5AcuSJXyh5+M/PYaxDw0QY2X1HdcvUf981siA0oAwsfXuopl94wJqRR8SFT8KBZ9KG2J5MZHHp2EPRdgyx/vB1nYbAJLsiJJ5YQzEp4SxEiXHip5KIG9FjMRzvVlcjAaAymCzycojKBcWgqw9/R+okFUdoF7Gfak5TJrwV7C7VSWREOZTwm7Rfh9wnshSvWrMY050y+byTuXixCPPnD0f9NQIm+py2pswV/QEye1oO5AMVQd/H6Yuouhn/GLL4PFnl3udkJtZ1Izy7e2OTnrbMaxEVZX2cAIrCXPxfsHlxbXXtqLNVKZ7Xuf6X2YyAJM/gu+S8P4DQEeLLB8GXV3+6TK3HHx0JgNOs9Xj0Doa8fWIZE3Tq9sSI1FhUncTUW8cLioGOmLemQgailryBLfmKDh2uPCy+yloxDuhuLehNBIx686NyWlKjYcSACA2WcRmf/knQsVn3JqU81g+B9TACZiMG4mEsSY3GBihbyiUyFqL4MW4o0r7HOGQr3nXN5ednqMtMgH1d3YRMzwcdhPrsGAqwnspN4IOO0gUl+za2vY8z7FgMoqFUfrs9dey+vrD/lP/Y/WBj/G+2nQBJ6Z+39MmPsLADYWYP6y2qbr3lg/MMz6SdMEInyY/0/nmCx+jsfMr0eNBo+NJ8RsRAYGVzMqnOuAFZ8nT4SWoxCS3SVUNEIJiQ5rBThUNowklqJm5vJZqQMhJcjmm0rmlw/lnxTooMB8bOcOAhbebPcOh7xaYLMIB9TMI36NM0//LRNhbk4NifuMPlFC3Ax3iEU2g620oqpcF2lZg567RhBkHG1VyuGQmwoUc0ug7yVdoWXM/phZxlGFvwGSvB+mOv92WAn4Q2NI3sCcMadTB87yVyy6eUZH37IAIoUTHDn7g9UrzrNMMxP89KbEc3tl0DSs2z1Zz0PzgWAPYjBy8tb1m+Z/tEmqqxNYLr1hrEgYYLFoORDbk8GgqLvb9/7iiDo+wSw3CHi9Cq6bCdWtAMKpaZBoYWOA+Gn4A4ZSILrroOBhIJahpnY+bdi8SfKe6oTxuHODqxuXuTqkejP9mAhj/gWptCPKWEY7+cCNGJUImGhSbVO1Ezi5VcJ4GIkYqS2EQtYYqDSxvvLYyKyXnbazv3VgqEYXl7J6i4j6sdWd8UYDY6gD/8Kh+Y2QD3TAH+sCZliExrh3SfDQZRmRRnip1/VJZjJdxjoS7JCz2Dcuff91atO+cz0y5iZ0+J+BySlZauvZB6sDl18mwxfNbZ5/f9O83C3V2VVdmRg4cEeVBoZaAz0ervyH0JWehsA8ymIJNlC9Onbvjdd6CicDESAimIhkoFw4W0shFbqq6ju2IHfsnlwA3k8WNF+zpX7S2CfAMHWgOEACXOyHcxkomSlLbUwW1bFk7cYBRe3eiyJtVAbhlQvtQcVPnMuhiLysYg3GBdDSbSfUAJC1V2Cxiggln3S74oe/BAOaq6CXGYQan4jytlV3xZELsOxnF3TG3OSu+z20zwIvmFkDg4CbO4aOqt21Slfm2ZZM2Oa26+ApGf56os9Bv1hsGEzgNftgziROIgsWuwpVVZjvjaoZxsZeOKJpV5zzrXo5ZfrIOdObCEmgISAY948SHNjJXlhORhIeLBU9m5bfdUZePB4FvJjpV1pdx9JHDgsZmH+KQJgnMaXxE3mJCLSpiLjI+y/x7VlaQvUQ1nGgxrfGzUHGMarJCRi5NRMD6/8U32SBCo2TCUEHXLw5pHwKk4kBC0RoqRsKCQLsey9kX6ljbrLUHVFBw5yl7wEIHwMC/gP0JfZCl6lCRWPA4qt6toHMSeFyza9jQEYaVMwzM01uOdNtatO/9a4lsp+Uni/AZLislWrfI+tRcA6Ip46umX9dN/FbNlDHF5ZkSqrmYHacMbfUf2bAOZ8Clhu4WRYiGItbe0gpg3EmHgDQIg6zLg3RK14i6/YNg/77iq3ukqyKjfjiJlGWttKyGaMZOu4b1icyG62TvYkX3Pr2iyq0oK5tGYsFqhE8pjOqmVTUUTACnA0coGR5y3DvMx7Y3p5CaZhNCvJaJK6i3+vjXDadhI3xAdVzLCVcGjuO0rV1XgigMxhTcjPbcL2fefVlV+z6b0eA0Odhc1GE3YNvvpAzBq8XwBJz/KVpzDGvhku0KCJZ4xtXR/9Pn0/0h4SpjkR2Xrt2JA5PX6kymKj2cz2sXOabO6/2ClOTFWWHZnexhai9q100GwdByI0Cw4GwnNb2Qkc3bYPYtTuhHnw8y6aShiCEZpYOK771VfBcxuDvAM90sJPQF81IaPI+JZURBX1Xe3SOSteCVX3UC8Hc3uGVSkbi1GJzVT0czxuxfL+SrKl2DaLWHZiyZQkGMmZDEGLqNuIusvt3aWj3jmgEDCRrEgs0Ah0fPwcLKyugUyhxlVdIsWKUnX9AmHp/AA2TK/dJL9m0wc9Bh+nU4G1ejl4auDFtc+fef/4FsvsLj3rgaTnmH863vP9TcBYbwD43tHN6z47vVMSbgrr6tvFcz14wYAH1aqvvLJCVdbI7jn+LvbxwCudYnplOdKbGKdq2xYi9Bs2C4lFowfy6GemT3GpsJgrT5cELzmilu0j7qJrCnTRH7e6yjC1tGYcSQkiYxPdKZ5YwCMxRatp7DgKlcuyQ7bRZglq9ZG7oAtY4qASCdnYDm4NKkbMCH/WoCGcLTjsKDGGInJn2jEolBXF7Cd2MCNlJ3beLtO1GFnwCyg1z4We/E6oZhrAwhT1QtUFc5vqrhOVq0sTn6mUB4XLblvDAA0XYKzUHqv86c8vhK+fu3Mq255Jdc9qICkc+U/P9POZXzGAQxFgbXnz2ukMEGphD9nrRwGGoSqrVPOhPJqFkdpSb7T3s8jyR/MFoFDAFPLKjzSSbkSNJE/exgleaQi4NxNhIfybFoZ0UU8IIFF3qBA2swdzoiD8SGM3IlqqK3nHeyvmEb18XOhzIsRP8OIydMdesWwmSvjzQ7FW7ieU6+ruEw3SOBA+bda+oh1zdiCaaCP3VYxxkKTHVpqWZKZi2UbUc5YtJYGhxIIcScR8skHeAsmYd1eLyHjePzp2YkGLjxg+hlk8Fw6u/xbqrAFDuSbAcBMg34xchHcsDkDl6hLZnqcheLG4ZuOngLH3GcxkdOzOyh+HXwob3lTr6pKboZXNXiB5zvlzSn2ZnzNgxwaIN49uWWfcJTDF4+0GEZnyPQSRCmaiWwszQcZ/fNdfYWPe55FlF1EQiamyWrAQ0xaiXXr5ThOgIy3lfJdrNbQ4ZuoxEc/HbSDkybB0yEBIAKAh+6lBn+9+mgPQAEtVqxs8RI5zB51wMQxX6vvOZ9vAmshbzdCnUWkdYZk0fJvPdd6emQjRFTPi2oIO24NqkgjbmNyNzgN8woxq3SyFMw/b28tiKE4bip0oUtQftdlO3WW7GMu+UQcDK4gx6qcEExjDLL4XDmr+BGqsAYWFDchUmpCf04TfVQJYspffE28a4TulquOZWF22v98rZl72bQD2BqOC4ZGbxz528nTKpYn1vwtPzVIgWeGXli8J82e9DgHvKg/A38Dj68a6MB6dVJFsVG8u8KNcWXPqPlRKkT3E2z76eoS5VwLze6Rwjd8X4sqRRRkLYQztbSGW1xQ9+otzZCzRI2UgMrdVAlMh1UkG4RkBgIaWymAevLywCcdcjBW1IHMg+6WFPZ0gFyhE12NNXOp3Mv+6TDxinjML4XXl7jWR8nxAiNIocTu2sI1IFZOJHm5DvRtQdLSpAAHeDdKZxNTyqozkt/xJCibECcBSdel2FU5onaMVc8JBTzGTAD28BA6Hz0PDayi7SZirK9kIP8Vg8v2eYqbvNgB4EV1Ewa7dB0SSx1kJJD3LVl3reew9CPAIg/pfjWy+ZmB8EmDCpd0gAnt9KJQ8COND5pR8yGIGgGW9R0feh2zeBwE8HR8S2SLomjbuCxFnd0vtpf7UBndDjRUxDluNRW8cJGos067RIQOJq688I2d9MnjIkY4WmhM8bJUaL5j0I0ShUMd1Oo9TIUM63DqymGQKLd/MVou52UoEVTEvMUFP1CP62cilOE4XDaAQ1gozet4JKO3sJ252YtBVBSjjcRO2yoarxAu+Aoc1/h2CXDWKhi8sahjxJvHgxalYCISZbDyk4LNfMwbPVMeiKJXKnrMr60+9vtPVOhvLdbgbZs6rFZetXO173pUAOAQB/N+Re9ZNl3eEBpETRaQ69cyKQOQZPrDhLDSw6O8YuzRgfWdRo7rJRNp5ZRGDOhXabW0h9j0gPC5FZ/UVc0mEOoNA3GfisJVIoS7UbqY8omEcluU9kXm4gMMNHp2BRqItJEFo0PI2pXD8TSIqLH2RvSlMwWwnz7KolDA1caYRg06lxrHM6bHtmsRUCAToZ+Jqr04ZSryc474RknZFCH3VdGRcUfEp0VA4404U41Dsg6vpkl2EkeHP4CD2HvC8IR1vspdf7+uOhJ9SMMldeutRnuf9LwNQefLCGBPYOfTKyqfeeOvMkaTd7cmsApLCsSv/1ve9n4TLsIHspOqWK/+nu8PR6riIAGHmXpnuRILIotAzq8+HSjMD3mgWymML/JHeqwOv5295bUKdJAzf4rN4tt6oWCRWuPE9xkKoW29CVLrDGyseHU95QZINxGYgCAnqq5jR3M08OmUdMhgzaR5iMsD6wGBG07Q0RDMOJkA6YIGMo2vCFqGCEY0iVMDKL9ygEreN6LgOckqOBLVlsdEVCrkds6EYRnmq7jJeT/2hsgxHnxB1l8SFtoZ4l1cXz/XF+86bQob3whx8B8ypPxkZ4WXwoj+nCeXRQHt0TY97cH7Nz17FmB/m5cqoaazV9uCjTxxXuf7sR6Z3YU5Pa7MGSIrHnn+452XuYowdHATBuaP3rL9ueoYoXK0hiFgxIi+Y50F1rg+jOzJQ6vGhzLKwZ+AQrz7vPxHyxyWCSJSlSp1tBaAQsFEHe9sgbseFWC7DCpqoWkwDmUI0JXqJF5YayFYG9GT1VXReNZiS0a7wPosfBFszDqM8+YP0I36Uj4nfSMFHnbkIA5j85xFyWznXLfiQlCP62NhuyeCi38sdIOPwslIgwU0S1nNC6lpg1wlD4d2PBTcaYOHIAky+Jy9u2E5ccSftVF3aCG+kwo9iWPBxLOAZsDD/UBS8OPRkEwqLGyoSPvToCjMIT1OsSeHS285hHhr3vOPo2F2VO359Amzqb0yT7Jq2ZmYHkBx/TranWfq5x9iLEeCL5c1r3zU9I2QFGj6vj0F+rhdl7g3TnchI9UyQge27lnjVuV9GyL0gEUTEvSEiAUUcRCQTid0TYrv1ksOkzUJi8SCmK6/hiWXcQUKBwsFA+NdxBpKUl0u5Ljs0CfIwnEwwTOBorYygwNzBsnBUZgh7gjouVtBhCyI1ffL+IidqUWU71uIAFZupOFhKHLv4JzQRpGAG42IoNpi5rtcVbgTymMTVW5KdWJ5pVhAjx38JNkauLmOcTCM8DGCRvQXm1u8H7KvD0FjcPXgawSR/2cZPeMA+QJcMDg5+uXLlqe/sYBnNqiKzAkh6lq/6tMfYeQhwd3m4/hJ46Jrq1I9yEoiQGJEw3UmmmIHt257tVeZ+GVl+qQYRK2uvMz7EwUSUxsDKkYWhOosa1N22EOvucyLmXWqsiTOQuOFcAlE8JYo4YGtvKolJehK1dI/FqahCTmYRq0KCQgwvJhL9nrTKHCKXtmvFeUh+RhiQ2Rn1RYeMJZYNUwJK1JKLIVkuwZNhKCRSPqqGtufImWXk7qK2E63qUoZ4J5hI0DPAhNA7zmsVWDHci/ngDJiPW7h7sN+AQSvWZBrBpLBm048Zg9coxogIzV17zq7vZ8b3GQ8kpWUr38Y8L0yQtqeBwXGVLeunQ8doqrMUE7FABCCb2fHUkc3aQdcDyx2mQMT2zFLqrEjaECaSZA9pF1xoeWTFo9IVfxB9cgQdEtcoBIh5YUU12AZ0Ox2JVqPx2izp7WQeWremxsvNOFowDcqeIpmSwFlaU5nuHEaStpDrfG+W5dhD1TmkRyZjacVWXGosEhRJ23RF1EtQ0eXCM495SyIX1iaTIeou8Q3vPf/DYAr8Y6ruIsyEgxE/ZYgfGd5Dx0YxIFe8ia0SwxHMB2+HPvar6LKsfQkmH/35/EKzsZkBe5Z6vUaj0Xxy54vr153x2+6swX1fy4wGktLylcuBsV8yYD0BwkmjW9b+aBqGrDWIyEBDgKy/ffsLg8aCLwLLkUBD23YhbxaSIKKFr9uo7gIRElzYzhbS3htLSVfJFPjZ0BDOWoUlYx/VnexUODsj4PldITZe2KgRl/EG49BCRYbKy09s0GiBIYQCmP2RrMku0OpvO4OuZWxxLkzX9hLqnWg5EOFtem+ZD7YDFelsZiMqT0rmjFOJplW5EHfKUHRUoHYXDl9cxZ9YgBe7QZGAicgqHI1bgleXrk0wKvUB/ZvQMYOZVNAP/hEOY7dCo9yAGjSgDA0zCv4HCJvCKN6LZSjwlJw8spdtfJEP8AsGLK/ApFp7pPK7R4+HDf+4expk2pQ3MXOB5PiL5vYG9bsB4NmA+JGRLev+fcpHIzpOEcO6wUR6fagMZCCPGWBe1h8YOSEI5n4eIDtPyUiVb1seyiRXbwEiTntIgleWBSKmR5YdVCgEboIdJGxW58BSIGIGEMZuUWyhvooOhXSGOmIeDvCgXegANMw2OxYEEjIUPFl8yv6+s7VnSnxyQLcet1gCP7Hbxng5nB2Aiim/VWoy1appa7A7o7kT6QQBuUAxBNlHM82J4d3Vlp3oqHi3VxdJMGMEMEra2Sp40Y41wQbm2XlwSPEH0BjjgYvlXANgr06pMk1qrvya2871GBp5AHG4/D+Vj530qs7W1swuNWOBpLR89fcZg5MR8aflLXNfDdCvbsqYoiHtHER2jhwXNObeAKw7IBJNghLaKt17QoS6My4kbgtJysaL1JCuhHYsAl3DQjsGQiLJKbORFMeR2JGe+00mRIHDwgSuB1K1JubqUsWEmLLubjfCQjpdSA6iIiP0tXpKdy8OQuTEL9/DaNsCFtVejLFYthVj+ybbRiigRFhgBxXacR+UofA2eIp3GtAUdVLAhnAfAZHiwAATzryMuJNYzi7poqzStWibTidgwrvrZiZhpEAW3gXP6PkfBSY9uQYMJIJJx4eRTpePLFdYs+krjMHbjOPW7sE1lbWnfni8dc208jMSSHqWrT7X8+CzCPhouQbHwf3rppr+dQAiPOVJZvfQ0c36/BsBsgeNl4kY+bJURm4qfWW23mSvrHh6FcoEbJde05iu7SBUjUUkfZILr4ia14vXjvdoyz4sgwFtX8pGx/7lHyUneJRRbQbWuewlUyEbHFtH3Y/O0YyCTHzjU2FNv3WwFSonNXOymIr6kwhUUS8HJjIwSQzFBRbSuiEBJZbLS4GJ2A86Ot5iJ7Gswk6vLle8iQQazoiU/UXUr3W1NB09BUusYh7fCYeUbuuQmUzFggFYdVOxeNDiXwHAsXLGsdkMGk/veGnjM2+5Y6aBw3j6M+OAJHfMhS/I+ngXMMghNl8yuuWq34znhSZQ1hGxPteDJcKwHtpEInVWbzaz++nnBbU5X0OWJ/eqGzaRMEmuVCQLMaiFLGceYi9IRYbiEg4molx7eR0WiCgxG0amK/W4xgXyPU2oKIW4Lij6RTaP/NVlA7Hj2KKyhk1FzIGltnKBhxwQGuhh9ksTEcIw+GCQCuMcoPN1QKmOg3q0ilBPbITWEx3nlUjlTEae4C1eRb/gM276IqubCk2monRicSZjgopiBrLj8uuYp5eVv1gI6HbqLpUFOSnuxBXESMFLsBxXvIkzeFG9HvFKS2AmDMcwB2+BQ3ru5GAyHLeZmGquKQGT/JpfPpux+t0MYK4Ck2r1T5VHnl4GN7y93Pm6nVklZxaQHLkiV8ot+QVj8JcBwn+Mbll7+RQPV2sQCeNEwpQnzMtm9gz9n6A692sI+SXtmYjOiSXEgRLq6hZVw/4QMhHLtZcat11eWWKZaxCRsjyJhSh5b9lB4kkdZV/02LdiIDHCEPVMnF/1UNEswnRSOQ7FNq1SokRyvgVrcS6Q6CFdJ8WKbi0oY+c4XW4TWhIPUnAxchArIW+c5/mnslHbg0oNs+6VIDyiNlPt5WQojhxaRkJ8USGp1/TuEiAg+8lvAtDZhYnJ32AVUflWdpOkS7PizEQdS4yLsgxmMoRFeAss7tm8L8Ekt+a2N/oMjSt5ce/eGyufeMNZ3Vqe013PjAKS0nGrrmDALkLEX5e3PP4SgA3NKRwQd+6sJYv1XSJhnEijkoPhkcO9cu/XkBWsOBHNNpKYiHKM4UdRLmQpiLjiQwxVkh2PIgW/jAuxT/qKcZC0JqYtJNryTjVWnIGYNmjJPoTsN4kAUV9RUFPnLoK/ogNayomU7fIAbntVuVaBAIu2ING2wASWmMUU7BqMr1uBDNl+wruK95baIhSAJGQJtlO6O1yKNZNozVCIi63xSkakfIRJRj1WhDwBMynspVeXBhv3zYm63giEopq4R5fhjhxL+jgOZgI4iPnm6XCI9yAMlhuQJ95c4QVZ05TosbDm1i8y5p2tdgciBAM7T6ldveLmCSzIff7IjAGS4vKVL/EYC9MwVxv1zLHV+z7xp6kdnXCDi5sNH17qQZg7S6U9qWWiu9UBsjC8Z5G3t3AjssJRRBLSy6gS1VnG9UzKJkJPyxYTsVRZKu+WbFjhFgER89wd6UocthCFJNGEG/5VUiCbpCDSvhCcNPyDSZvmwZyoxPhJU0+hk3kIiaBYR5I2wcEwjMXRUgthjJDHAIJwjKLbVhA84CkrE/9lLCpva5kIBiYs04StxScgOa1KZFwxXXZjM6Owhf4SZyniOUOw634b/TPtJ/y0Y4JOW3ZCbSeEnQhwCkc4+jF4Fi/H+6nBgK8cUcd4wISMLT+xJdpMtmNP7TQoZf8cxZmM+Q0oZBsgc3NNB5j0b+wtZNi9DOAIBSa12lDl0SeeD9efvX1qZV/3a58ZQPL8f+4r9TTCQX1WAHDe6Oa113b/VWmNFogsLTIIU8GHCRhHIQO5Pg4ilT19/kDmc4HX+7IJgUi0IxJyZtlMxBkfQhmP7L8AkUnbQhSTUY2Ig7TLMG7ZQCw1nMKMeFR7RH2I1OX3ddjMwznb/LkYRsRBwwPACBwikKCgEIJF7Oqmri4tWX/0bwQ6kVcct1olRaCbA2IE65mdk9uTC9sYU3HaVCRQCW8p9RyZVoOhJAGKdIQyQS8KuFCPRL+orL+OS7UEbMgHOvTqIozHZCZCXaaSPkpYImou0SMOJBxNNIJp0EKGf4D53qngNwfBL9VUbq4YmKwIREUtTysTWVTFS29/CbLgdsb07WJYLv9P5aOzzyV4RgBJafnqGxmDMxHxv8tb1r16IpPS+TMJIBLeJ+LvzkIuzNjZl4WxcsHf1fhYwOaerkDEjFjvnIkYd6k77lFvGR+imUHoRMmFq0kVQmFrxIXw782gwhg9sNRYcQai63AyEFt91Yp9dAIekhnZM+lAEsEoWt1bomuxWVLnKyW55HhsIjy7WQRyWqIRaLVaiZiAa1tqphIHFapuUhJU2B703wZDERigO6LlrRmHQgMHNbBpV2ATTML6zLgTLezFPqJeXQZbMlyEDY8u8354Di7iUZeai7AeNzPhBZDh/8IhwVkAOMpzc4WJHoMGT0E/EMDAogA2nRhO25QFLBYuu+2jDPBf6CoIdg2urK479apurNTpqphK1cIAACAASURBVGOfA0lx2co3+p73LUDYHVSDo0cfXP/U1L08AZGBRQwWLfYA7veh8HwPivUMwHAWMqUMQDGb+fNTFza9+f+kdBrc24YIZ3fEeswmkgAi6kIGAiJJrr2cKcSy9aoTu6HKUp9KxkEj5YlQJVmGHZHoHTAQywButyud0yKp52AqKpKe3LXOt7ea/jjTcK0MLlZd3EVVJ6gW15aQwBJDXyXrcfzLI8T54db+2rlYnYbrqKRmLoJBGahhbUciEM1mKKjQy4KlUJelieCP8ETFewhDuIQRiSoGmBBGJT+3QE7ZTmi7vKx5mVY08EYSRqeqy443aZFWpVMwcTETmr4FPfwOHNy8AADqEZhUhhvgiftMcn3N6NreqQSTc+7KFp858msAEBnDwzsyGnV8dNsx1S++6/dTJwu7W/O+BZLjL5pbCuqhSmtJsxmsGNu6/pvdfT2jNjNWJASR8I718Hrc8FKq4pwM9LJsqNLyHhk8Hdn8j/ObDblgM6LIYwkYZRliV4jZRNowkdjNibIu2x5igJnDoE5USW1sIYl2EOJEpS/ia8VALFdilcU4CUBoCpUYBkRMz7pJnEykYC5JmBLXhTlKumJN2q08S+PnLN7C9MFRzVkgYir8hE32YyegIk/lzhxaDuN83DCvrRaqPbuPVvxJJ7YTceI3sgpLMNEqsyS7iZXRV3VMq9VaxZokxJnw4VVIaYCJD2vhGZl1AKwO9TK/z6SUaUTX9t6xN4C+EExuk6lUuq7iyn3k9iO9IAhdggtyWeHI6KbKFa97ebtVOVO+36dA0rts1bUQXZmL3yhvXveWKRwUC0QGPCgt8qBZ8yGY60OhLxO5+UIx6z/9+N8EwUFfAMiISZUnenXCFztJqmIIiESywmUT0SDSARNRZ/vWrr0yQl32S6uyxPlcfSFO5moDKKWA+EKMO0eKmBpLVpPMQARjkjoMs109qeq9+Ec28+BixWHTMDeuYgRJ+9mVVkVSEhKW0YKAtCcqBsUx5b8dZiPllyJO9uHGXPWKsfCPNUWQf/F6nCgTKWtInIrKu0IxQgEaZSjEUK6xjtyRLiPTRV/j3l0kjkO8MMHFyHai/iZAlOgiHLd5KAGr3l5miOtMzcWZie6Uvs9EgF4GVsKhtW8BYB1YUIcqa0B4B/xjO5oQv8uk62CSv2zjSg/YOroacMeut1euPu2GKZSLXat6nwFJ8biVJ3jo/YJFV+b6zx/Z+skdXXsrsyLTzfd5J4s7RcKAw14f2O4sZEsZaIzlMjv2HN1szL0RWHa+FHY2E+H7OQlE1JfExXdcTITcnCiCDO1cWbZXVrSkKQuhJ3azn2IvObyxTADREswRm8KbI6Akr9vthH2Y4OEIH5GS3gIP175tk04lcTFxSwWBlo7+ln5eiab72E6iHzjYjCPVvIVIUb+CJNddPUlxUImlM6HCneATtTUQQwAfECl0CZbFouNbBTKG12uRlaTAxALIaHeSwbAN7ZY3V7T8JgcmerxMgGtg3nsbzBv7OWDA1VxeuQkDg01o+NMCJoU1Gzcyxk5UoBl6cf15+3PhhrdPlWzsmsjdR0DSnykdN/RbBnBMEMB7Ru9Za9wk1rW3iypyuPnKWJEwat33slAqZbOD2xc2h3tvQlZ4rgKRKIttayYiGtAR6xO3icRBRDEE7SUVVzVJA3wkHInEtUHEGVSo3y/ypiKsgx/h7Ij16O/WDES2q7aDmk5u87DVVrLLou1ExuFgRAYaRCbt8MbC6D2SCYfMQOgqYa88zTy4t5kZkW7yEnlPB+FUtACVn2pdivao7UV1wRTShKmQPUsJCy0vi9jeXkKyGwxlfOouMWrEZVe6KouTvTOrsPhOAhH/U78H17E6ghe7xExiKeiJikuALu8R7sa5zZMh33gUMoWakeTRiDGZGk+u/JrbnssA72MMcnIZBHuHN1Q/8fo3dVcmdr+2fQIkPcet/pAHcCkA/mpk87oTuv9aSoiZsSKhm+/he31+RW6Nq7NKvVkYHiv6A7X1Aes7yQkisZsNtfBTqeDHaROJpTsRVSZ5ZoU7V+fMi+Q5NfybIMCPbZo1OGNCEtRYCkDE2U/9wwFLv6+LgciIfvKsGFAvFrxOmZPUdFHm4YhmN4gJZ2zuBdyh5qFT9da4Fig98MqDTPivEUchEYTUbNkezBcz/gqhMh6PoarsjKGoGAsp0804FOmmxAUsoRbE91ePsvTsIgCmSIYELwkmNLgwQlplhJ8cmJB6ZToVAVi8n7qPQs2lUNg0vsNWWFw7HfxGGSr5mo4x2T0tnlyFSzddwjxQSRxDv3bc/vSrq58547/HtQynufC0A0n+2Auen/G8e4Axv97AF9buXXfvFL1z3LgexoooN18RK5L1cpmHd7636c3/Z6nwMIU8RiLZVmepYEEujIT4JcKxRZyIG0Ri8SEKDsJJUiBCXHujbWhEqMsLr9TWidBGnRWjgaYMJjy5S9dcygwosVGUjNhAqKBOZCAY2TzihnP+sJN5WAxInOj5PybTSHT9pfV6HmFcU7DKpDeXWh7kvYTwcjEZZfRNZCxEqMv34d234EUFS1JqIp3YLKM5F9q8Ohk5346hSEYgBbGSyHIwWxviY15dLjAh7zVpZuIAE951YcPRwNUaTIKvwxL4Fxgt18FfLGJMhFuw8uSaIuP7+T/KFw7u2coAnicHGSuVbZUfb3su3H1ufQpWcVeqnHYgKS1ffStj8HIM8MryPeuM+4y78kZqw4kD9ImbPFgkjesL/MjNN9vMAPZmQ7uI/8TA3wSw4AsAfk57aKnTvBkrElXJBWcyEwmLyNOyELg0TiQWixLWSa7BVelTBBiEQCFzTVnxIdr3iYCAkPtiYlUHVFyJxgANMIqFGMUpmphea3qiXBdYubyuSKtyDKksou3KCQzjzSnjcLCMaCqczKjNUlJo08GSi0n7Dp4RgteIULcfo2lQDLWOKKhP92pJJ7CUuNqLFHQZ5uMp4S0Pr5i6S1fosJ3ouBNXzAk1tJuZhJPiTbrHTDRvUwyrlZpLedUhwxx+EOaN/Rf4+VpkM1GeXDuacMfiAKYwwWPhkk0vZz7caqyY3XuuHlt7SuimPCN/phVIistWv9n34BtRevimfyRs/eQUZbskdpH5Sz2oDfuQ6/Og3MhAIYgupoKcl8s8tetZzercb/EbDuUpngomyUakoigJRKK5FSdt62715DgR8Y3NRET7YuUnMxGLabRTZdG4EcMWYtse2hnSExgIIoZBd2ZaFXJgNVRbMduLAlN9ALeAI/ELe1+J54yQ8/gN8/HdaB79W+5WjS3csU69eLvtZKc/UWBKwlOSQMUZmR5zKY5Wk8kEHAyFqKBowkiSUoT3jCZTjD4QyiLBZIhTmRHEaHt1JTCT6AhlXJplR6rbNy8m2UzE51G3rNxcxj3wtP9cpWYyE3J5FmAVi8EKWJjfDFAmnlyDTRhc2oCBIwNYtAFhwwPhTXhhNY6TzsRlvn13CTYbQfDI9mNqXzrrgYnXOnVPtlv53Wv5+HN6SkHv78KYkSCA14/es/YH3auc1tTGuD5nTsREoFrt83eyLwdez4vEptFMg28ip0pL5c9S6iwCIqFUoVl8J8pEjEh1acuQNgpq/7AZj1CBKeYk+kYi4ZWay2Yh/JVVhVq9bOwPAZYaN0MDusP7KlZOZwuh7CPS9gujvq5TzSaX7S02KAENZ7mu7u2E5ZqwhazEhu6HpaqFfutgKqqJVizFDhaMMM5UeXEoMOgKz+tF25TeVhI3tJpNjCYFE1FId1CPuG03ofRSRuLz57oBJqpvFEw6iH7n20AbnfRijPr/OC5ongyZxk5tfN/TgNIRDSiPBjrB4xQY3z9y+6JiEIQBicKDFCAYKd9SveKk106N3JxcrdMGJD3LV1/sMegHxJtHtqw7ZXLdTnzabReJcmjN08b1Sj3vPzH0r4E/7906ZTq9V0QxES7dlLqIeHExwQjofSIJINKZTYQyEanOagciNM0J9coiSGKDiMOdWKq9IrGmVGlUCEvbiyHsLRsIYSq8IjFJcW8rnibRymqspzRB+ieBRhuwkEQjei8PuU0pHqCuihHX4Fg5HnmtjQxttV7W9moPLtotjAMsYSpCwEcdtQDF8PoigKITTpqAohiDHHTJlNrbTsQ4EZuD6KjAp/j3BsARXWX3wYSPVwiMCTctcldjYuB3shJysmGAHt4Ci2vvjVRclWYNxoYaKo3KFNtLCpffdg5DVB6t4drDpwfeUP3Um743RfJzwtVOC5D0HPf+ZzDM/SGMGm/WGs+tPHD1oxPuccsHo9MTA5ddJEzCGP6X9XL+tu0vC3DhFwC8TFylZYMIF54RO5fC0emhpV10jWtqx2MTaREjEk2UkZOrHYg4vLIs+ws/67fyxiLgEI27ACjDgC7KkK/5FLnUVzStjDGRyeDBsx+S7x1FNQqoL11gwVucLEsxXYAdy1Gc2F0L1SADcbagHmnFVITqy2ApTrWXKpFoQ5kIOyHeWOrGQ9tuoheA4S0lxp+FjtKiCEdL8bcOXJTgJL1MOncN1lmDE6Lf+VFTj73IbcaZiSvyHRlm4SJ4Bn5dGd/DNCpR5Ps02EvWbPwFY+wlcmngWOVPlctfE4YoTHYhd1UETwuQlJavupExdiYGsLZ8z9oLu/oGqjJbpSVuOYzsIn0ZyJdzYeR6duCJQ5vlvm8jyz9DChZ3+hNp83CDCL9/JBSW1s2Gk7CJxHNmJamzXMxIrSsVoc7jKahXFhXumrUojzRzbfIKCbkx1VgEQDQeac2AYiTU24rigb6fxVgPPMe7y4ivcYCjRCQ940xC3VDZYpnZ0e/yRVtRjARPY9EK7wf3s7bjTYwPjF4RLJGZHWO9pqBCQcy2pRCW4mAobSLmDYRT93/Ivhi2E2qI79SrS7yDDUJRq91nJjEwkTaacdxjwre36B/AKJbg9TCn8UfIFGvAhnjkexisWAjtJTsCWDSAsKH7Kq5s/8blmQzbTJfFTEzqOOVAUjx29V97Ht4R5mkfqcOzp+j+dQbQz2DFkQzU3SLHeLB3WwbCoENpF8Gg4D9ZXRd4JF7EODm7EjG28tCy71iPud9KyUmCDaX7rRTEXO4ng4itVrJAhAh66tor+Lty1jIZgm0LcQUyGqd3tOJAYiATZyA0zoMenhIi4GN5wcjWIa2ZC9Z1KHNEvE/F2U1hDu2RG2xoCKQ8ldNgbnI6J/Eh9tZsdU9Jgl2Dn7IVHMhfRLS8pe5y2U6kKkhUZLMgySSs4EKJDpJ28OGPe3TpW1eExJ4yZiJUWHzOBGMkhnvxiWAlCj0omKCHW2Cx9yZANgqZQAcrlnY0pjpTcMzwXq2NVLb94Qj4yvt3Tc2hfPy1TjWQsN7lq34JjJ2AABeWN69dO/4utn1CBnQLlVaY0VfeLTKPX1CV83JQqeczTw2+qckO+ghE3FraFISUcSRiFLJCOt8LcZbARHjEBtEnSZuLVg9xFx/Dg0gZ9FVmYQ4MfE0bpWU9or+hjUaDSELKeIdtQ7ynYiomRTaYQDwSnbAQh62Fj5d1c6OePkucy3GXIBb72mIcLqYhQNWmJs4lQ9242q6phAIJ2cDs0gbImOCimYuMWrIN4GrmeQEXUzE9kQjhofd9ECZjpmOJlpWp7jIwxWAn4XKR154Yl80btgZqe1DgReNYEiLhqbfVJJiJI2uw2iXRcHJPLuVU0B5M1ICYyR3x07Co9kltLwkvxNrF085Pob2k2L/xcPTZHxkjSR33Dl1X+cTfnzvRldzt56YUSErLV72DMXZ95O5bnftceKC/1u0XMFKgSFffKKNvPQOLmxmo+znIVnOZx4ef26zP/Saw7Jx4vEg74zpNxCgFH/fQUup7y35B1PoCLOzcWTqI0Q0iyUxEZ+2VSKJxhKOqFNK2nYLYQygTE7ExHamxbAARxEUnmCRMhkvNOIBY96+oNUFdmKMPbSqhHRKS15FQNdI722OFqUJMfimlv/03RamkViVYJOcsjhnIVVWWzSUpIaPpWSSeJmBBjN0RDbHZQyRQ5YeWQZ7XRpI0UgO5bYgXFSm1D41Mj4FXB2DCRbzqgtNmIuvl1ancXNRpwAATwxPNvLKXenKJd1Bg0c5ewjDAHL4VDoE7oBbw+BJcUIfMSDNuL+muS3D+0k0f8zz4Z7lsZpo78NQByRHvLJTmLXiIMTgMEd9a3rLua90HkXBZWSqtKI+WSMYo4kVgrNLnb8frA6/UxtW3RbxILIcWAZFQFgiy4boeN57Fl7cTDj73vOzMO0sxJC1kacZeM4JdsiOlFhKa45hXlmZM0iASmiiIDFdMTGx2/XfUIWkDiTEGEwVC24eK4iQrQdiatGin9bgM9vLZJMAQNXHvKtOI0q0FaNfLBZoKs9DNJACMg7GMj6mYFINLVy6OdT3UhkIBxKHuSvTuMgJFWrgJU3WRBKV2zCQypymg0YkY2zETG0wsrzDVPAETBVQixiQGJu0i30l8iXQJ7insgmoIJqwOPbkGDOxtgszHtWkAAbpsL+n/1ZxiphJeP75QgclI+aeVK056ZbeW9WTqmTIgKS5fdYHP2HoE/G1587rjJ9PJhGfbuPpiFvJeDmr1fObpXe9qwsJ/5fVwwakPyiReRKmmxmEXoSDSykOLuOFGZzoq0A111oSYiAYRrhRzgJPM0msc8wUHkDIf0VPiv7UaS4ylBV4JHlY0L5icAgFVfAFSzGkHHrah3AA9a6k48nV1bSFawtmuV53Y6RdEuMfKU3bBCYIaFdu7in8t/k+3sMlQ+PNCahoMIvZo9K3I4UXZQTzuJNKoyjYdzEfHpIgeyoY1RRL94iNAwYQyE8LAdJwJZSZhPzoLWIx7cgnf84mruG6EZzQ+BLVmLYovGYT6dKi48ms2XuAxtl4BCSI0Hn3qxMbnz7yta8t6ghVNDZCEbGT+/IcZsEMbAfxt5Z61GyfYvxaPES8tqtKKbjqELDQqOcj5uczOPc9ujs7/NrBMnwQS4qXlTIGiXH1F+g2RS1acxDn1UAMnhWQEIkooKsbBbzYk6dhFHIMZsd7aJiLaUkYFGtui+mIBlVBTcViRqivTpq7qi7ZnGJmuhLodkU6Fe4IXlq2HcjAQ3o70tkpgMLY2y452JExDWiwkcHrAI1Tkj8z1xW82DO9viYLf4v+Se1DMO9hFeWVT4H9LOcrb0z+kP9G0qL8NBkKXtMUs2jEVqb7RMlkIYyOgjneQBBryal3qLgMzBJiIu+cNVZdliBdgIrqrr72VdhN1EyM96ScE/SnFVlibbTPh4xPaaaLVosBTAmEcTIw4EV6M16GM/Y7I96T4Eo6BapC0vQQBC94ZcBD+KlJxhXe+O12Cu8xKzrkrW1gy/CBj7NkKTGbIBVhTAiSKjSD+uLxl3eu6DyJtVFrNag5ymRw0WNF/snFt4PeKHP/SUC5lqPTS0iqtWLwI15CIB5Ij101wkvs7lHoERMTvykMrEv7tDetG6vjIWK9pg9hpmoVoLEsAkZgBnnhkxdRcFrtxGtKJ6Bfe0LYKy04sqRaEy+YhU8yoreLymI/BjTwkxMwqQqwqGS28HegFtbZSyv23aewJxRoFESpq5exb697ca7Z2iqZRlw86AgcTWYoSsootKHWXWo3RL+Y9IfYVuDrEwoqMt4W4yEul+6MFrpVapQNmQlPRh4ZHm/Hwi7ViYCLGJ2ImpH/JYELvfiftCLe6tvEl9P4SBg/hoZmTASujkGnWYCioQ4E1YNhraBWXuu89Yb2OXzLmLr3tTb6H/6V2xwxhJd0HEsJGmk04YWzr2l+Nf7jaPUEDD4WXFlR9yGay0f0i+dDA7ucyj+08pQkLP9G5l9bEgg6NyHVtSOashQQBhmIzKXeWK9hQCD+qPhoHiKgTP13EMa8sDUoSRGRxM+eXujNeS2pzc9gMRNxxryPJLduHkXtLDZSe+KTcXCKbUpRVWDIMzShE3IyM54jHmbRbWUnfS3Bx/xuLH4lARjMgk7kI443eezFQsZmKLGpl73VFqHOssPc1OVVza7Y4ZQh6JZaY7Soc2k6M4D2ORGSMonpUNmFHvIkYLxoJ38IAr6kW75H4H3UL1j0gd8DL94l2jM6hpeHFZBU08p1vMgV29jW/fJxcrAQAs7AWDvE/BbVyXMV1b18Tlh4fwIZLEODicDd0DUwKazbdyRj85UxiJV0HktKy1auZB1ci4k/LW9ZNgSHICjw8Ztjn964LL62xej5UaWUHRw5pDhe/jaxwSLKXlik843m0xPdRDq1o2gQ4aJdVN4jQRIxaIFuxIhFVEbxbqZmiBSdTsnD5pKMC2zMRQX9agQhvyhO5xMRiFG/nAhGdhJIIEJOFxGwgctyopr8d+7BtHY54EwIu0jutswUsuiuzKJsJHVVMqRNEbI9fRWLbtyzjR7Qw1rJRtyWFn/jEwACHTYWAhxGfYqdfiXl50XZUKhQSdJcAJvqWRuLVZau6iJRMCF40s+8mqLmIvURaT5xgQiBYauDinlwkToSDj9hqYhw6cgkmoOQGkxqW8GSYx/4QxZZUSzVAn3txGVf0dlfFlb9k0+s9H1SalPCwtq9tJe13w3iOcMd+oNTrB49EngUYvHxky/pN43m8g7JcfqzY4MHDgx4s/X8MDp/jw95yBoZ3Z2Euz+oLo0HB31G+PPDmnq4FMXXVpSoth5pI3IzojlyXQtKKQ1HxIbF7RaIGoqhwffBWICJtBtIJIKa2ki/QFkT4O8XjQyRYakBK9spy2UIIk6A3Rsb7xTXkKm9GHJT4/FreVgQcPGDosnFEWm0B4uT9rOUizr5hASr8lf6JcokOVpqziOCIth5Ltkf8ptRpUZ75ycldqsUixkIO+cLGk8BUXJHsJkPh8R7SfCfkvhGHQoMaeTNmbiopZDUzkO8RC2KMOQC4hS6N34hCEvkJn4t2PY5WnIkiEORzVyoVu7+KaZkMRDufSVogGEhSfMk4vLg8+A0eCmdC0KhCM1dVXlyjPTqx46bu311SXLNxCzC2bKawkq4CSWnZ6ouYB1cAwh0jW9aq/DAT3bbx5wQbOfFl5h0jfpCNbjvMZ3LAsvnso0+/tAGLP69zaSV4aanTv+Wl1crVl5y+43YRN4hwQ686kaujt3mfSGLEetzFN5Yzy86XpRkTZzgERJTgtgGGMgbLFsJlsGYhLjWWDl6RR2vab0l8CPMynLVshiPFa+SoICHAXA8kxYphrOhQg2C/j5kD39LgEPVH4mJ2bKVIThnuqUJ4a3WQPqkL2arqJwxCq3kEKSbxKoZ6S72UFUdiq7tsdiJASrXjZiedgIk6dkwfM1FqKR4R3MqTq018CblZkc+LNvAnq7iQsTxcFCxu3ARBthpmE4QdJFAxUnE9HHQ73XxuzcbTfcY2KCDZx6yke0BC2EjQCF43eu/6H3cPQKRcoTEjJJeWz7JQCO0iXi7XqJUaj1VvRFYSaG0Y2Nt4aXFhqb20rKBDZ7yIFMgdgYgyruujo6leCwW26f3lYEyOtC7JTETKbumVJQ+ixpnZcBeWZ1Up/fU8RsVsMLCZEDfQk1xbhn7Y9i6jNo+WzEMAh1JLtWAY0TxR9yxChLqxKG3GE4KQK/DexVwsYOFvoYIShW3FtqloHT6ZC3LHudzGtg1FH8XFDrJuTdTf80mVrsIm0FBDdqToVDetaebA+2UFL07GZkLVXI77TKIEDQ5XY/elWMY9I/o5rQ7UhnxleJdjwFO72ABpGPQ9GMD57JXQ2xzUgYpBHYaf1QAYaka5uHRsSYcnnfYLtXDZpgcZwAtmAivpGpDouBG4u7x5rQj8az8YnZdwGNj7Ap1Lq1rNg9fIZ57ee2oTF35MGDT57YIqtVR7Ly3BfYUairj6tokXUUGHlC2oHFpWwGGMUQjh7Ep7InrCFbxarcbhoF2kulyzND7EULFZXlmx7Lw2UzBSsWg3aA126sgtOsjnl9o/qO1Dfx6q/uJqKwIeZsV62UjQaLmQurZ3SSsJW0dnMG8NLg62QkHFCNCTQlqqrQyGEnMhJmodiQ2WuouqlaShRV+/K074AhjIneqUpgX2JViGjaa1mkusCMIkOrCZaDBRdp3Ik8vhIKDtJRQoCTNMcgm2AhVtLy7uNabVctQwzzL4meCgylrI+VWoNmqAzTo0F9TBp3e9d1fFVbj09rOYF9yggCRkJY8/+bLG5956e+dytTsluwQk/V7v8r1/BMaWBshOHd1y5Xe70z1Vi45gd8aMeDnw6vlsZWR+c1f+u+gVDie7WB3J9Umfg4vt6msK6wRX3xhjCHclMUgLwR/KTtO4LtBMucKqg736hYBeR+qs6MwkU9wrzZNmONH3dnyIUnNJyBRnKxnvwg+mGnwT1FimtstmIFElYiQ0yOg4C/56EwKPEDylO5RzkRHC5GnloRKLFhTobL1coib/LY8msQpIWBGfEdOxSVCuSHo6ItLDzwmoUJ4V9ic01HNbClOmH9VAkmFeqbuM9CumusswxttxJ628urhATsjVpUDMuDArgZlY7xG3mZD3MHJlERfmQDATMSsSBDsMVqRxK9EJgN+XMqFARazi/OBVkG88CvlsFUawDk2sx9PNd9HwvuImv7Bs8R8YwFK5KoNy+dvVj550Wpflb9vqugIkPctXnuIx7zuIcF95y9pj2rY67gIYXonFYFN4//piD+aPZVQalNAu0vBywBr5zGMj72uyuRfIALXE9PDSK0oqaoRq2VZpubyqdJ1SeBJ7AgGRsEqSQ8ttFyFqIg4i4qymPKqk7WYcTIQkjgyvcVKMwLCVtLCHGFEbUpWlsFjsNeOET1yKLQ+vqFicgYRiy4zKkGdURlLNGAKbj59hC5FjJdqQMtxYW7qfVMTbol6ChwQB/TcZPQIRVNjHQEO1T1iAvd65jdfae+JP7llgfBf+aXk9JbntavUUPxBEDWmmY2XgdYIJb17I0ySvLtU/bTdxqLloFPx49DbwhQAAIABJREFUbCY8flSBAh8+zgR0JHAYD8OLTCjyPcmLK9ItJ4GJi2kRtZmP38ND2IWQb1ShLmJL5i2om+lTus1KNv4j89jn5RLDZjOA3/95aeVr/7ht3GJ2Eg90BUhKy1dtZIydiBCcWd68/uuT6I/jUeLuC+BDaZEHZchAKbzxELPg1/JRzMjgzmcGQ/O+i1FSxuinwzQoMiGjtKV0eL9IR/EitkqL2BeIwDeTMFrMJRax3s47SzCMlkyE9ysM8zJs5FS6GyAk3Xuo8JYqMrWEYwxEfhN6ifFrRhzqK+VlZamfIubhsm3oBJqyfs3MaNyIYhhCLpgiPwqQd6GLSQlUhQkfG3EUujozrkS4s9n2Cc5E+Eol+9D4Vf0hwUAzFCVc9S80kI/uJKEW0vEetu2EtE9sBK3BZGqZiR3PIcGkg5xcreNLKINR6jIJWuPw4lIgLMGah694pWBFc37zt1H6lGK26ja8d5GVnPO5bHHJ8x8GBofLKQ+GhtdWP/76Kbr3yS3dJw0kPctWH8cY3g0AO8pb5h4O0N/oIpCY7r6Ll3gQJmUML6uKDOzVHGR7cxA0C/4jQ5cF3lxB6VwGdq3yETtPugOJc7M89VMDu4wC58KLMxa+9bkYbRMvQiPXDftGi1gRYU9QWXzpqZ4zFp1yRQl+0s9QU9IBEzFARL6TeDX+dkSwx1x6aSr8mFqPoI0ELJuBtLB9hIPs8sJSjM0AM3J0j0U4ElSxQKorC1RrcRzVqaA4TZRIeVcsCtesEDZCAcX0/GrJUPjBXXSJAISl7pJshcQbEqDjwlF+p9OryM+p7UWwAtul17KZtPLmMgzXhCW5Is057hIgFOXjke92csdke4lYHaLWdiouByuhEe8e3oVLvDMBmtXI8J7tqUF1yIp47y4rKa7ZeCEw9kklnKq1cuXnTyyETWdXurLUO6hk0kBSOm7V1xmwMyDAy0buWfehDtocRxHq7htGsN/vw6JFPuwREeyZbGRgz+3cs7zeWPhVAC8X7cQkAzuXw9o2kpBLS6UkcXppuUCES2AhNHjOKi7X3EGHAoaS0sGbqeDpyZ8zCDFpltoqiYkQ8It6ZLv20psKTVVWdMNiNF6yDpc3lu6GEQfCCUXcgG57fXG5xymL8WMzD2nLkbYKycyEuJMUw4EnCvyFwmYcCzChKBGotEQoTBXV0egsI8lNxsIZEb8extqGMS8wW20kMVJEngu8MOJQFIbQ+BMNENGxKR53QtBOnrSlVxnN1RXzIqPeZo7ARbNdGilObB+6bQkmVMUVGboJuGnAcVzVK9pT72e5BDtTzsv6k3JxEYcAyWQSruZlBXh/MD/4ERSyVSiP1A3D+1S4A//LD+YXenufYABFuRyD3XsuqK495erJr/XOapgUkBSPPf9wz88+HImCamVJ+YHPbO+s2Y5KETay1IPFcz1Y+HAGKl4GFs/JQBjB7mXzOc/PNx8fuiZgc/5Obl2Sm0okT6RsxJXZV0rKKIJdqGHpKT9+74g60QuFTiQPzYy+Le0iGgw04EjIiL6zvL9UTq5IULlVZMlMRIORxUQM2mEwkfGxEF2PEOQ8AFN+TBkIadLFPloyDwsl3KDRnn4oPVWLohIULC1QByvX2lMx5hK5kiYzFfK4YUtJYih8MfBTumIi2gEgpu6SxejJ2jjhC0oT1kUBk1v9CObxxiyvKcNmIkrwMeNUSZ/+1fsoVZQz+j0ZTIS9hNfruPdd9U+5BBuszOXFRXNxScO7KKdASQMaVxY40qcw/D0eGrwBmF/hEe+hF5e4t2SwyK/m7bI7cGHNpusYg3fL9YmjY9sqH3ntER2s164UmRSQlJatuoJ57CJEvKm8Zd2bu9IjVUmSu++cDPSM5qII9qqfz+18+vh6Y+FXALysOKc5bCNWokMuSAQEENuIsFtwQa6FtR142NbVlwOBVEo5mYOw3cp/lBcZN/QSEBPqLL5bJOjwDsp4jf/P3puAW3aVZcJr7X2me2+NCRlIwmCaHxWEVIRWW/9fokIISaQxCkGQUUVEMalyQlqwSFUmhKogBEFEBodGgQYfRxyoG22wbTumAoIyZk7IVKnhnnvmvfvZ6xvX2mufs8+9p1D/7jxKVd179nj2/t71fu/7fZ973UuayAwmUhLVSZvBagBf8dU9uvi+0UqfuuxKBboGC7yPmnF4DESxHbfDOPPglb4HHpE2KvwmqXkk/oM5G2imP8jld8aBTtms5QdiDqaYwYLox5gG0dBbSzAw1GIogCTR2exR7YTqI/i4AhKRynMCA78Sfl5mUgAJg6jqGowgSMEasQHuKFhuhbmpmfFz1ZdQjQycczmdRm9Ysf8qrYRcXlUMS4R32zZXZI8a/KnJUqx4PzYyXTM2K2Zs/ueDmXny8yfQh2sxA7BaVx/6ljS3n9WP7uTu+y4bvuuHP7bYuBzf28aB5JzdSyuPMndba08Zj/ML+p89uMie+MHAKmIjpzbMzqJFPNh9W5N8aXJ/722Z3arYCAUXNWdkagW7sgPRKjwKIkrXcBkbFahrWX3r9tDy9Q6/VkQLF6oPV6WwTnGp1LVXMwhPcPfSat5ckylaCFhsdNoNs3q0AKV1aET/8NxqnJUPmZJ6eqf34CJwKz/um8UP2mPlK+P/IjRlqWW5nJvneFWggj8PtZQYQ1EuLwAlP93FYCbBWdEIcXFBYJ3i6vLqTaqYiazyvToTzWPcfggwdSdiAggM1kywBAXhG/RTXJCnBmqApMdlryGtICkurnpXLAmy3MwYBWDc1pjiitaW1Kh4T/Iv5o+2zzOTQa9kB3Z9uO7KzLk7M/NhJ7wv5OHs7F89ZI3BTufG5N3eof61z/nef9NAsrLrypdbm7wvz83nuocPfMtiTzbURo6lpig+PJE0zfatTZMM2ibvdVr3H/vW0eT0DxAbqV18WGH3xSQBz16v1dXXmy9SxFJ/Za9cUfQe1K9cR9E7zkSAoWyciSC7kWJN906WKuTdxyJ1Mn5FutouksaqYCCQ3tEMBG4evNH63dI9wCg+BIyLH8DgneQlP9q02Ppd/+XlLB/lo6YyEO9NCNM/+pcCPGp/cJZU/1GHodBupNJb6k+oQp4CqmJFum19latrQ8xE3FxeBbwGExc56bwVmCgRHZgPoYGkwTCdpMwAehJisQF8VizBmjXN0YvL7abwG+J5KDebtN7Xre3h2FRx7+50J7syOzX5E9eHq2g1318emu5RYCXdBzNjFsxK9t10WWrzj9JDVsSG7PavPHX43h/7p8XG5/LeNsxIyPKb5flPrR8++M4FnqjPRraeSM1jTklNeqRpbIr9tCbtVtbsTO5cf3uWbPseCtZaG5lZfIgJGhck8e+zUlrzubS0jlGRJhMZARZQEV0EQ4p2UUV6Z1Gay+2E/6ckrGuvr3ZmhUWSKrEHJ+WZuDBSU1GhivieOYG4gUYEPE9M00k2SCzParXuO8d8cPEZi/fwkVNsGlDohFLdJ7f6VYFgo4M07dPbxgcO/7AVv6N2xZqh4EerXF5eMEaXtyzqUU1R4BPtTYXUhhmA0l9qMRPRXLKSw0qYQtTJxfUdXtpMdJSp9SXuYxzQvap31Eem9uLStSULYSXmK83H2OcOs2GP+3Ad1UWKC2Ylf5CnnS/edJs15jH0eGUn1t4yuP7Sn6/7lG/0cxsCkvZTr/jGRpJ+3lpzYi1ZO8vc/BvrGz2B8nYV2kgxf33ScNpIO5908gceevpofNr7qxszKncWGSshfsCihoJ2LqttARIIeKqsIuegHNZ1GDPFpeWnqUr1Ih6AUZClOI15DU9c123lg7Yngh+416p0VshElLkAIAhPAO8LX6+cHxRiB5beUg+uOICIBkLpMMQ9gQafUpTud8g4yKUXPklVzIQYjavIcC42Ub4pS4JfPTMQ+hz2cC69NeXXSK2o1YnJyhpidNWOON2C0gtpKRUMpdSuxLPuOooDkx2L/SI74eNXu7pIeo4xA7go0gx0Xxi+LncR3vheZhgMutLdl80C8R5apJdI+U/g4kIIAUIH9y+W4qruxcX3HMNAcfVyXdEixbKlmmkWPH3W2Fb2C9kp44+b5ZW+Ga3BAKwd45FZPzmspLNv9ZesNdfwQ9frP9K7+qJTFhef43vaEJCsnL/7OmvsL+aZ+bXurQeuWOBJ+k6tKBtptlvZpDO5q/+OzMYmH06bwR4pPqzJRuICe7mrb8hqKDCXrL6cYsHlvipQRGURraRRh5aaaqjBRSrW4+6ssFJ9BogoxgTfsRQyqpDoV6OHaaxpGojvulJQEqatIuDh5ZUjoEGhZIEPZ3RXbr3BE/rwI/5rFWcs00AlDPYQlUSojjGUoAbF004wsHrOLr3irwEmsNAXUSfKTErnDWCiU1RwKoKULBCU9RL8VomNqLoW7TJj0JzDxeUL7wyIfI1KjEfhndkNp7h8xgSr06iD67bmY5NLh8Nx32SjgStSDFnJzTuLNNditJJr/urUTta42xrT4ef1vvsv7914+R+czFdhA0CyN1nZdfxOa83Z2dg+ff2zby2KERf0X4U2QmwkHbXbSaOdP/DA+aPR6b9tbNqYWjeCi29vYFWpRTwNq5IVd0wbKdl9dUNGWP7AosWzzVJPL4rCuE7igOy7yTD24X5UixWI4ZxSUkOpVJqLQGQjTCRSHyKF5Qi1kBSQSYm4IJ3mxuK5LmRqIg0kkirzCRlfKz9Y3rheBDX6w914mSVP2wChCF1gQkCYcJAHbu4/dSsATWxCqhEAi68XUFwVT3CYiqLYC8ss0VA8NxP17JJgBp0BytoJrdgL+HO1n6Grq7TSjqSZ4CYzIJSLFkWQLoMJAU6tbsEIPe6PIMWF+1GCOTEBoAPWlHtxkVutuHo5D61tiIAfGc3Lrea1KYC0EjnHklayI/1T054MHJicfFbyQWvNS+g9yLrrfzq49uJLFhSk4+upeXe+fP4Vz01M+od5bj7fPXzgyfNuP+Xzs9nIsNluNSedyZ3door9ebAvL0VSqhspNWZkHSLWlLGqgl2lmTCkg6uegjdZfXU01C4vxSpkMmF9XSQKInisQFeZn4nEQQS/Jw0ikboQXjOqgkK6B/zdKPCJaS2esO4DyDTwQNT1nydhJj5IqBZN6MyGGEJPEEdERvzS7xU2uCukbv94ArK7cG2Gq/2AgODaQFlgve20NTaSjoLor4KmEp9xxq97LWifYplFc3lgvZ0DTDxm4g/Kmg9MFKvQLeFlTLCkqOhCfPFdpcXCQkVER/zO5hfeCXwJqDbp4LLZPzbPSn5kmCGQaFZCDq4FspLOvpu+19r8r+ndyMfjrH/HnWea973ywQXGa29XczOSLbv2fMxY87w8z3+he/jgry7uxGawkaJuJJ90Go88/Pist/MjuWluidWNiPbBr1m8FQpqI25N6YnErI1UtkEpnmBwME7rpYVhKjJfBIMOtjrRDRRB2MYvhaIisw6XoQ9sxyyuh72zvDCptoswJvgOQ00EtB83G92rUCdXFkXhshbiMwEPhCF+0v+KGSsQ1p1/MwAVdmtRBwGUNkLGgQ1cXXEoZQelzKPIwxV9dOFP+Q/Aoerf9Hk3W5IlFd6/YwZYqY6Ns+Bz5L7CiwbKqnLvckRfU9Gooy3CwgzgeOAqqqw/ibR6p/OCnl2hq4uOS6kftWJ3sXmjzESYAyhSTGQUo+Hr8EEOdZ35XVyB8O4OK+cxn1ZSXPyU1ilTtRK4xGQle+Fka/qPzEpOpoNr796k07jgdi26T46eeP3wLd9/7eLitb+nuYBk5VuuOMM0k7tMbtN8kJ2z/s833Le4E8stjNBVVexpS5xaxEbuXvuZzOx4Fa0lpVhwWt1ITBuBKOZuADmYIv20YhXs/tjcSOEh6x1U7Ig5NgUCXtGhOwfcj3ZdOaCC85wNIjA7RYI0/R1dV7wEVlGcz6cMIrAfPC4t3UNXlu7pVdJC2FdMUVTVqzBzmMJAhF2wpZofNg0eCnDUJuVWwREXl4cKyIwcOmi0iD3h2PzA+xULs5yBgSBPX0rwqrErCCI0/Sd9pLyfBwxFawTuc/gYR7STKXNDXFCvdHTNAJOQmUR7c4XAA6caBZMZ9SUzq961fuPVlsC9FeFdgTFZoEPbMRkS3GrRZyVcA1NHK9H1LGn+ieaZdvcwSfumYCbFJEXSSpiV3Dcx5leKS/We5I3E2M7+1autMa/n52p9/a7+NRc/diP7qrPNfECCo3RzY/68e8uB59Q5QL3PTGEjlupGJp1Gb+1RkyOd/2Zs+/R62gimbVw6kwxbxZekWqHo4kPu0UXahg6wnMYqjc0VMMIwTkI6HhdCCQAd5iBCqy+CGgKOoAFPdCy6XuG95HSTVLYHdR6cutd1LRrUamsiUh9S6crSIM2aBDAniaLyYsBleEWQTkYuMRDRPHyG46If9ABTjMMHDvUi+oJ+5HEsoUmAIiFXCSmJxgFq2Y7MhVtvETMJZqwTyITBHtY2YdprarpLayd4Y2Tlz5XxZSagwYR7dW1IM4GAC/GV6jWE0VD4nj7HJFZfosGuPPO9orFjSXgvT1TUWol7LEp1IDGtZHpdSeT8qNuwzbJ0u3n2uDO+gx1cmpVwD67FdAZu7/2rJyaNxhcYSIr34M67Lui/56WLLBzn92k+INm1+xZr7a48z1/cPXzw9+qBRJ1P4byRP/qN1BQdfh+VNkxfVbGbbqfVbHayu4+8cGJOe0N53kiZjZS1EYrOwfjcGBuhpop+DYX7aWxYlTd7vU5DxkDX4I6+3uyOaZXrLrhxaq1aF5H6DH82S5XFV9J1Xq8sDSKl4kLF7CjvxsFbFxKGIInLRF59VaXK4Pnh84+yDgSOKGiUFnebWe1F3peQadC/NWtRbAXbgESZiugDjE5ep1u6FUJChLao4O8uEFB2CpjQ77AMt2JeSHn8Lq7SqYEiXC4cxyvai1Wt02cDZqJrTXiGiXaJRaveIy4uSr7BtvBF6xTX1Ip3L82GqyB/nC85uCg757GSimp3xUpsI39/44zRm4dD2zet0cD020M3/Op4Y2w61INrcZ2BO/tX/84a8x0MJmvr7+pfd/FP1onI836mNpBA7Ujyz9ba42uPHDnT3P7+RbUolgLEYt5I8f9bz2qYPvXUWmmZ0dGl5rixZfK10e/lyfITARLcipSjDzAO0QI8p5YLuxh8N6qNVFawl1f6eFPl3LRLK7TUsttLX88sECHmAzfCq3chvOQKey+9ptxf0zURJbFI+kmDCCTpOT3Ibq6w7sP7t8RwD3zhMviXROQw2JIbDhe1NC8Gi6NL4BGkzZhwVPbeqv/OiCgi6S8d3MP1mSfQF2muGFOh9Jd6FQOGUgyUlcwRf26qYA6XHQxpKjETH0yKSnS4u6Il4OUhXIBTCTQZVcdRsgXTE1kNJugW4/1qBxiukjw7balLcA3hncHE3U84lC+804/DivcQhMAtB7uorZXg9+O5u040do4vHC01H3LV7pPWwOTHZCSvz0o2s+Bx19ret/qTiTVSLN4fHO3tf/bO+g98/U/WBpLlXbtfn1h7dW7Mb3VvOfCj9Q8x65OqAHGpl/K8kRWcfFj01Go1Ovnd918wnpx2I+VL/EaK6EWp7KlFwbSiit0J4ioAkXAd/IzZiPt5TBsBYKuoGanp0vKKGCvqRXQrewJT5UFSVesQsP1riwnrlG1y1mJewqhtdadelbLjDDR/dDoLKQMIrgoQAAE8MDPhaTjuzqq0npwk/i1Mn8148NR5Tv0kpWdm7c57lTQqeLEYpw3I/F1cDYkLbAqgTE13hWmkiqr4sF8Xt2afj5mguigV/QwmgaVX9cAiMCDQiNeXVFmCVYdfz8UlVEwYSKS2hCvey6xEugOL9qQGa7ktQ60kXlci4IqBALLeqP+4J7hl3pydmb/PDId914OLOgOfODI2ZvsEOgMXrGQBzRyv/dudncnka9aYFj292e13XjL4zZf+6ayoPO/vawPJCqW1TP6s7i0H/2reA1V8vjyLvZh+2Gw0zbakWbSJNyZtt8b50uTuE2/N7NZnKumSggrlEDjIcFprIdoIi9agjagcPzwllA6iwFRTYIdMD67odfAVQIjXi9D5VNSLuJU9vlLubJULzP1YmAgOIOT75rmzNAD57d6ZoaB2IYO2dGqupIWUmBF0JnJRhYx1on3AJZD241mExbdLDFTyRMFjFgELZijsAiO7Fa5R2H6l7FlVT3sFyGjBHmHE/0PSX3A6xFRoxc9ZItRKKDWGsO2lgshNpZiKO1gR1GKuLu5HqNxT8TSXr5nookVAdHSLzQYTbenFlVYFmHB6ifpZARMofqxZEq7yfVYiKw3FkGR7BUS8UtHCOzeiLAX/uFaCDCUU3TGVpoEEn3Csgcm/1Dw7/YFhMumbfIRAMhmZyXBkdpw7Np8+lplzv7qwZo7t/Yc+khjLM9zzk5TeqgUknNYy9uja4W2nL24KYtAOpd9rmG00/TBtmSR1VezZsQcem63t/GhumiuYU5B0jksNUdoK/iRnLkUo8OHE2EhQN1JHG5mLjUwT2GMuLUlpiUvLvzZgDhUgUhQHIrUKVv6scoDor9M/1DPLE8CFxTCI4HkQSJX0EAFcv0IDLAEQSOkP5ejCGO1pWtMBRPcaCyN8PB0wU3DXJ0dReC4Goj8ceaf84jyxvwqgyNxdmLxbYiildJdybhFKSSpNAjKsptGgqnSTKczEd3Np55UPJmRfYVtwhZOrRn1J2RJc6eKCo0VdXFIlr4dgifBe6sPlgRPQ3TkcXD4r8VJYINwDaNKXTLlYm6zkl0+254fdvJKl9sAM84opiptnJa03rT4/TY1Utff6R3tXX7Tw9FYtIOG0Vp5/oHv44MsXxEbAwESWX90OZdJqmXbaMnnWaZlmJ/va0ZdNzI6fmyqys+VW1YEIr0QgiVh+padWzbqRmIA9rYIdV+JaYIfzIjBUQRb2U7L6EnlB/hMV1x2IABi414N7YUnFO7m88Pvz6kR8TQRPKQARZCDIJIplHT8JOrh7oMEgwi4uf+a8S+SR8zYKIEDdYK0QMpMSAPiFIz56Le6xFbuu//6UmEjAWPzfq+A5i6FQUKLlvBw2EOPhF3oFLzo4WpFVCozBhHBHmIlfZxIDE3I9FYRBBVEdPHG1Dg9moJcw6ATCuxfMycVVFt7pCdViussps8EgOreEdSVPK0GYLTd0VC4y3UySenCRoE+kXyYnsoONgATSW8gU0/wjzUdP9g5Ho75zcBUjebvjoVlpjA1bgV81gZXXJq3Aew9t6TTsQ9aYNr0A2R13XjR4z0s/scAXQt6IaTultFaWZz+wfviGjy/oBCCtdcEzEnNaMUYXW8UX7VDajZYZNNrt1qSTjSZbJveOfie3S98I91XNTkehGgINZ0ilAJEE+KkdfpXGsFltREVjsvvyfA9MIEHom96QUSYd6lW+tiRP10UgH6JYh0qj0R7xPAC0hDDUZCKxFicY8FVajeM4Hx8wAWOFYkaUbpPf4+c47RY8cz7z8BlHUNwYe1rjxGX6cz1rzUVRgvaisjR4xaKPULCnX9BnIwwlHIerAzW+vtVgovavmQmliYo/N8VMBEx0uxGvJxc5ukD74pJGATy4iEAv0TeP3FcSiFEr2hwrmVMrYSAhFqOq3ae3TeFrYd3Fmm7j9Mn3jJr5MZMm0IOraJsyGo9ci/kFW4GX9q3+kbHmUgaS7vo7Btde/NoFxXF+uqfur/PUn/uGNJl8xRi73n0oP83cfbC3mBNAy+/qamIKkV1bfpNh29im00by+x94+nhy+nuNSaj1KgbJXM31oCCr6iMkN8BsBOXEyLwRzSgo9TOtbkQJ4roORTQCrv+AFbf+vFu+oHYhugoVHhYgAxnxckoLPo1MBlboZAH2wKAMIlis6IOZX7E+RRPxmAi61xgRSmky0kLwGri7ckQLcdcZ6zJMDCQCWPTwhe4wAU78BFMYeNCxHZIwG2I44dPsKh3gh3Dh0T9FjKUPhPtRwFKlmShyQD5VFWAd2ri9s7OWim0YePwg5RUX+vUXtF9Oc0XBhHfHf/HrTHRvLnFCiTtKpdu0+F5VX6JSce4pgJ5D5DhGS3E4bwS/GWRd0yvelXguuonXesVnNsX95QacNepKivOlIlC43wos4LHzgF9NUOyY1zdONR/nAsX+BKzAw7NHxhxfqOjeueqTr7RJ8l5+Qk9CemvWMsusYBGiMeaja7cc+KHFgEixl72Jef6TrNl5bmKGJ1JzpNk0W/KGWW62TNJou1bxjUZncsexN2Z222VwXAjC+Hd6qzitMt3yS80ZZfldHqGLQjUFXN2YUa2qZ9eNaG3Ec2GhzbXKkpsbj43QIn9aSsthCaXbYkwkUrUerViPp7OEQQT3xn0divV4TIS/Ik5zYc6Fa18izjHZYYlhEDZ4TCLCPBTbISxmsJr25FagxdSHXVeyu7VJSEHU1gGoyG/k/fP0DWrn4S4CaQPbAf3jhB1np4IJl3tE0lxkTfLBBP2QEcGbIn7oVNJpMMmrUVqnlOJiwXwaK6FVQLRDsErnUVTX9t3q7sDxaneq6FcgRN5rL71VXP9sKzAADX0pCmiS/Obm6cNXDI3tG5v0PSvwjuXFiu7QEfh+C+UV7r/R7XddOP7Nl/zlouL5bCA5f89N1pjvzrPspd1bb/jtBR3YT2tpkb0xahdurcLymx05csbk2MpHTNI6BSVDSYeU0lqhyK4tv1O1EQg5JGArLaPYSnpq1dFGVHqHx/YiswDyEKlgrxDYpa08wpoS2Nk9VqdyPQTHoIuvqw3BqKvrREi7gBnygUDPMV8xoRAcAy2E+4VQHYimEHhvfJOV8Cf5eRQ8QKgn5oD75wfVAwn1uemMo4qJeOkpzgyj/00xGWUfjQBKCXMkGArBwaUuBX9dh6LrObSgC7sppbpCER5af9QCEzgdaGsCvblU/Qi3GBFqBStwDOhVluAqF1dV+5ToREViAO4HacjlAAAgAElEQVSS6f6hMwott8S6JI6rNBnoKcwo0B02owcXp9dkdr1iTKUCxcgERS4Iyk2y3Vza2G6+MhhqK3A2MicSsAKbJy1srntn302r1ubPoIcxX+9f37/motctKJ7P0Eie8NptK1ubDxdfSzdpnWZuvv7YYg48S2RvdlrNRie7555LJvlp11HaZ1pfLc/y6zglBfCKdiheGqp4iryVu3sfZvfUImOGnglCVfaUdvLqKsRh5mkYAECJV7fiARAEc70NMALP6utrHfABJYG4vyeKWcHv8PwCEKnBRKaCCDwnClzccavSWJpplOpQEOX0Z5B5cFuVKHgopxq/Pgt4fIO1l/tnjI1IeqwCVPRKms5LEAZ/6zu8YuyknOaaG0x0FXxFOxW3nPA681L8phW8AhNtTw5SXFHhXbESrxdXvOL9JGklwqSg+Y5ycDm7cMjUKgoUI44yL72lK92b5tcbZ4xvdOmtNC2L7r2lCdSUbL7/Vnvf6u7EmgP8JnS7X+lfe8kTFvBCKCSv2NvSeVdelibJR/M8/4vu4YPPXtBBkY2YxJz2pMSYc2Aeeyiyj/Ol7O7uW7JkKw6v1yteFawjIju82yQruzUU5Txcu/O5540wk6D96nRVrG6EnGPEQkRgxx5RFBXF7cTaSExgj4CIdmlpfYPDZwwYYcY7rlshBU/zRMJeXshE3PkSKhA2eQL9NCaCdSFu+1kggsCp8BMUCrlV7t1mrSMED89GIFZjfmhJ+1C1KXM/0AQYflpLgj1LW+LIcsdA1auU/lIpL87KqPdS0lQMOsgQUDvx6050CmVuMPE0k3Kayx3XVb4Xp4KgUTo/VV+iq91DBuK5uJi9uK/X00rgV/S4SrsSb3+QBpytlWi2hvedXF7SIoNqPVAr0UyLUmSqxXw4jpfdW/p8YDtdD8MLi8R8uflo84NDO+6z6F7df8vL68796O499Pilhr2NgSTL8v6XvnCm+e2ffGDufUU2mJraWt61+92JtUWn3SvWbjnwa4s4IDyFuTUXaJE9aZidO5umENldl9+0k504ckZ2dOmjuW3v2Gxai8VnDrgzWsW74KkBB2s+dD1EtKdWWDfCYrhDEq53KbukkI1QMNVsxKsZwYdJ0mQ0592vpYl183V2XXFzaQaiu/giUwMGpFNY9dJZcVeW3hel/0KNJa65EIZx+grycPifAh84WfW7aYARvJNe9ksJ7N4DX/WqhOASpq1UvysPUML96ZW9AhMBGAxytJ3kq0r9uFRLkOlpLq2ZUDsVPF+PmUjwjBcIElOa5eKSwAz2S4cdmIzj+wFgxekxvQ2tImJFiuWGiSx2e+k4dmvFrcDulNCuDKfHN5yXVCUr8PT0VlhTAm4z2G2yzVyWbjX/MhwWVuC0bwYrQ5OnI3MSKt2X9q0eNtacR491dv8Drxm8/QW/voi4PhVIVnbtvs1a+/hhln/L8NaDn1vEAb3akaecSE1Ryb6yo2E66y1XyT7JOq2JWcoeOHrRJDv1eklrhSK7BN3Np7V8DQDXXBRIMT2kV95z1o3M1EYEgOAqvWDrF1hSdJeavrjVV6XJ3DSNwjggHukIExHwcq9uMVqPT8Ov6KdT8BtBak1EMxGdXlMA6KOBEu79YkXpCkwAUgUeFcDB9Suxp1d79EM00Z8P2sbDDVKTBcPP+pXoEDOqAIWCKf9Zbu1OuMIJF95/FTPBnelVeGz/xAZUBTxcGzEgQUVspQJ1gtSTS9JBYgrQYKJ/j8diHcG9ZaU0FekdUTuwTjFpK7HHKEgzQqbC1tyQUcjnnOiOACI9vRAcPdsvXQ9+owwzcP+UvQ4YCGGQ1JcoUEKUKtJbp2XvHDZsz+TNgevBZczI9B4eQ6X7JzNz82Lay7f3rb45sebneRm23v+9/jUXvXgRcb0SSNrn7XliMzFfyE1+X/eWg2ct4mDwkBS1I0Va6/lYO3JKw4yPtUxn0DLJVlfJnif5Unbn2vXQEgUCa9ytRRkrLljDflbF9wiV7LwdBXNpc4LpL1zxeyJ7bPqh0AhKm/k9tebRRiQ1NkcFu2Ij2qWlgMd9osrqqwI0p/100FaGhFBc98DNCfxBN16l1XC/s1IqK6xI1+wKL0LSWGUGQveMrxcfSW3xkl3K81q3p1YVE4kCEB1b3h9ZUKsNlKbBQSUAFLAaBqmwediJHAPbP+pCR/57nJmo1T62U2GGUJxvqWARgmNxl329RLOkaS4utAxXTUTU7CsqvMP5As7N6+CKdgYWK7DXNoXAMLACi1COaTZiU7qmRMBTrMCY3lJ6kZfeOsf+0DBLeiZt9M2wOzTro2FFTcmm0lvtN33y2Uma/DkDSa9/vH/1RdsXEdsrgWTpvCtfmybJr+V5/jvdwwd5/u/mDqpaoujakS3rLdPe1jLZuNOaDJayXu+0ydGlj5q50lrThldpTWNaWgsgApozUlCi4kHOwYvA7VKhGGVRS3BH0iL2lOJD2JzqRrQ2wvNTqgV2Hcw5eLsgi+dUuLNsThMOfSEeW6mwW0sYllen4mIcP7sRZkbaT9Ary4G4qpHx96OQoMxQnP/KvZ8xBqLfI5+5iMuKWIYCFdpfUZHM+w2fZI+dxN8L2p4qm3kX9HFkLiVQUakfJgYxhsJpFFqYswsJD0VMAZezkCWGZA0EPYjR5Rni7qZ74jXXmSjWoeo4ih0V6S1YisF5QDM2F8FLle9YHQ7nIQAFm+K11hHeOa0FWMFDsGZpJRV1JfgUsPaBLCE6rwQFdXWP63YFBiDxhl7hNwRMBwHY7RnAVM90T7Zl/zldSb88NOO+KYR3rinJRgtt5Lj3j5Y76dZHrJUmjuMv3/afRu9/xf/YXFxn7lXezcquPX9irbk4z/JXdm89+L7NHgiZhbREobRW0aCxqB1pFe3i15eaiVnK7334opPn1lLq7dRKdl+HkHkYuHJ3KEAxMdZTi4EBLb/ajcRAFddGHEhQlEdK5shG2EuLgyWjXujSmqmLIBhiEiRweQW6iAdeACJlTaQGiETqT9jhJawKbq7K8nlNHBVB5NksvNSivxAYhSms4GmmrFathzwADV286AGLBhWNS2L/8VNeWpAPP+8RFh9MXIyiwE37KCIX6wlYx1BKc6m0kk5BBWDiAESBieoWnHlFfoSQBGqKPXguLrx+yJHhw11gk2ZH7sfuovkY+vfIDPyalFgPLjiAVMBH0k0OF+NWYFgNFcBIoO8VHMq+3d9irMRvR4/pM75o0ohsO7+xsdO8e5jaHrSXHw5Mc3loes2xeWh5bB4o0luLaZnS2XfokLX2An5Vjndf33/zJZsewRtfeT3hte0tWxoPGWu3TLL8nN6tB++p9Y7N/NDexG+JQmktbNA4zpZcWuuu49dkybYLEXwkjYJTBqvmjuA3i9oGubWEjYhbKzYBURiBdPmNi+x400rBW86LquLdYxz01NJ1I1obkZX/rAp298qJcM49wqiXFqy7werLc0K8epFcakew15g/T0Sq+tk5FQERdx5o8QV311QQwe+F01eMghEhXVl3y58XaNXg7NbIyDgiwEFg4RgJ1X3MfGDxA/h5t3+uWlAbqxSH93sKjvhR0cd5ZUohUzQUZBZeuguWshR4Vd0EB1yIuxD4nJsXevNinQRuD11MtQajGY/6e8hM3HWXcv7Fjgoto3qyIvSq8npxVVW80ynK+bmfgFYSFgmGkxTp/rOthq6FzpnqRxgUZL4IgRiwLY9TugdzVnqLGAcCCWAyg73c76nurS82zkouH2WjnmvkWIDJSUpvdfYd+i/W2v388K51/7533SU8/KruGxF+LgokS7t+5jtT2/hUbsy/dG858M0b3XmwXcStdWrDhGmtyWhndn/jI3nSOa2+W0v34CqeGTUFUQXQsJIdR8iR0Ountea2/FLlvFpC66JJcRQFjRld5MEUEgVwZVlWOanpFezlrr7CRmL1InhcyHhDAkPpRLpdvnszPIuxpJWka6/WRCTdh89ATRCJ6SCetsMLKX62mMFEUlqewwuvQlBozsdavypKfI+muSTVJAehYCdxxheo3aJDUY8Eq+XpuDXApMRMRO0tVVdjKkgAKmQE2P6DzilSXwK1JQQwEsynCu+cuiK0o+Cv+3DxbXCgx+ktnW6TTr8+s/LrOEQj4uBO51v0InAgxSDtChT5ZzyVEYV4BQ5sRkBO6UA+kt7icwl1I0xvqeLEdKd5dtJJ7j7Z6a3mVZ/89kaScCorH43Gffupttm7t+Snn+cFiQLJynm7d9vEHshyc+P64QM/Pc8Oqz+rihAjaa32aH0pS8ySue/Bp42zM98j+jrXZFT31sJnEYoQAyGa1rbce4uCXExkj1WyU7WZBHxPZFf1F742gplQl1TmlXO8bkSwRyrsNfAAsal0j5HAXjAQsBjA/013aWHX3erKdWEMAYhsgol4dSEAQmGl+xwMBJbzko5zJxams5jpxR9N5+qC7mdT/4xuTa8PrWNDxqKYilAPBAzt+lLiOjAaXNFiS824tuGtfCkVVGYmmDSCFBieMNU1MKHBgKtX9jMq3yMurmLt7u4+s4iY8O4OJcdj4T3u4Ir34MK1D7m1vEJJAAZMI/EFcnrL02A49VTZFbhc6V6R3nJHqnJvyX320luq7b1dyq9qbDcfiaa3XMuUBbm3nv8Haee80x+2xrDInt92+zP77335X28mzkeBZMv5uz9qjL1skuWX9W49+LHNHEC2LdJauggxktZqZJ3srmM/kZkdRe3KSXJrVae1qivZNWtQTjBxN6FbTK3yYyK7BOTKuhELgZCjqbsNUW1ENajk85CUlHT19Ysi6b5KS/7p7U/8vmKbYiI+iLhlQQ0QQS7Dz5EHFLTLWeDBmKjv7UYea3lfvDQV7UqlsjymEgKKQhXeT0mQx2OR7qHYxaw0V11mEtMuVFqGmkZyrqzCxSWNHatZiVtWVWolEGi97sByf4O6Ev8+wDer2EypuBBBS7eYZ81DdQBGMKrTf0usvUpgV6zEsZqwOFGZDsTxpkCpkf9Z48zs9aPMnPT01tK+Qx8z1j6PntrJ0aOvG77leddv5IXQT35p+5Xzd99rjX302qD/aPP5d35tMwfAbaW3Vsmt1WiZrOXcWnlilib3DN+T261PnTetJZZUydN7DIH6WEhRoQr+gVsrmtbC4F5iNpG0kAtXkXkj6GRS80a0mIy/re7uW6zgc9cTTGToUhsUbMhI5ifq7wUrdWqHoutgMjYDA3YTPcKUF7mvaLa8p4ngBsAE8ayYAeh0lhLlSSOKgUiYxgo0EAgayhCgASRgHlA/orQWeoqrGAqJG/Rn7KmPrru0diGPO9xMdlPBL2IMRWsWGBQ5VlKqKxTiZ6S5OD1D3YOpAp6ou2ImnmDO14caA9aX6CAcCO+gxWD6CXYbaDDwE/ocNLfEQEuuMN0dmCUGvi/uDDN0O+Ft5HxfPSswo5JKU8EuJDWHvbu0NRkFf0wpKKao5p7MKk7EO0LuNfiTLlKzm/xo48zkWdYM14eNTs9kk4FzbzW2D7k4cUG9t5b2re42ql1Ktt7/+OCai35gM3G+9GZ0nrL73EbDfiU3+Z3dWw4+bjM7l22DtNbklNSkWdM0Hm6b1raWmTQ7rWSwZB9+5JxRd8fv0yTEaXPZ5y9C1PZdSDtpTaB4wsIGjTO6/AYzUGawEXQguXWXbkfi6RJVVew6XafZUbkNCgzGws/HqtenubQ8EFG6CGCEuM/YdSVWY4C2eUBEW7IFwXzXGeGTAkHWRBSoMEZIjhB+FIIG/VuL8eoJn4Yh0X5aBA68jwpQKcKVLlLU/9YAo1NlxeeVVuAOoXWTupqJpM28ehWsfp9dXxKxBLslN2fJ3F9coC/pC4plsSVZ6zZ4gejgkrQPMTtKg1VYgVHfCNNFdB6Rtikl0Z1b4PP5uwQAJxfJTVYpuntAAt+RW+1A/tf9lhkMJizL6S243mQlf0m63dzigCRfG5isNTCPmJHZaUZu4BX33trc5MSl/Td9pzH5p/i1We8d61/znB2bifUlIFnZtftF1trfzfP8D7qHD16+mZ2XgKRoGf/IsMG9tQbjtmlvabVScGvl9zx44SQ77brqSYjxAVbeCh1W7LhqJauuErPZWqurtac1aJTAjTeLVte0MvbTWqzT6Ep4YhCumC8yb2Ra3Qg2w/JdU8RkvODt1o/s5sK6GurJ5XYD1wILdTVcy7PZBk4173rILaYCP6XiZoGI1wNM23oVSMASMWAc+O7z/sPPY/Zbt6/xH1pJjrn3Vbu26rq3IvNJ4BhY78oLZH3kAFRQo2CwQv2geBpUwgz2SoE0BJN5mUm8Ah4OqNxKlfUl2HiH5oQQslW0Tyn2iHwZQyZdR6rdUqKRTK0roZQU3BHRSrTdmQtn/AmMfD16HghsxxMUOb2lBPZZ6S28KqS6CKYb7L2ljsV6f1Hl/mj7bihOHMHAq6L31iQZmfTIJBh4VUWtZ4fsvYc6nYY9YY1pwJucm/7nPv9Y86Gfumv2xvFPlIBkedfuGxNrX5Nn5me7tx7gbpEbPQC8bGoSIrWMzxots5S0THvSaWVpJzej5eyutf+S2e3/mVaTUpVOjQbFWcQ1g7zCDtxaqihw824tWNpWVrJ7rAK+Gkwi0JfNKSx/3oiwGNBGlCjvlnmxupGYNqKsy1PboEihpWoNX05BeZXrCCwIQrD7wKEVNnyMMhtYt0pSTu2HT0tcaxinEVRiKSyl/bgPy61mDZNftSpDinZ6wRJS/tPsIPb0K3CB43vFHgodQpaC4UgzFM7xIziFQvy8zIRdr6U0U1mniKd4OA2nRHrI/eN1RmpLhJUgyGpAxL+ji5jpjJ5pLgFaFTVyGqhiXonXmZeYEmsXCtDmS2/NdG/p1vaz0luBewvTW3wPVJX7PzbOzn/cZrY3nCQ90x4PzGA8NLluLf+5ifnw8wtZauNAYoxZ2r/6D8aYp9OTnd97/6v677z8PRuN82VGcv7um62x3zrJs/+3d/gGpj8bPQCu2lSTxrMbJj3SNHZ706Rp2+TjTivNl7J8uDW7e/x7ebL8WDyW9JBivSGYhIhuqPlaxm/AreU1aMT0iVqB16tkD2axK+Ed4tA0bcT9GpkPV+Ipd5aJVLBTOoz/RO3UmTZjaagZles076UKRHTKTQHWLCYCWgZzIk/LcfclYCCsxfArQI8Lm5ThBxo8vGJQOl75z/AhJ2zRf2KM9OeShKDiCcK013IPrep0lwqAuITx0lx1mEkIJpBmct+SN1tcWVEpNaV1E15BFUtoauxIrjIM3PGK92qtxJ8k6DnG/CCr3GtYXzLVClyjK7Dv3pKKe4jKwtLC9Ja4txQDUQOvMKojpLj7DH8vpbe4nkS56KguJh+nZ9jvTZrjI8PmUs+sTwZmaTQwR/OROd4Ym87S2Dz4QAat5TeZ3rr6pneYPP8pejizfu/gYP9z9mw0zvtA8qTXbFlpt48UV9h9MN+2mLG6U2y/xSTEAkSytGMf+do3jLqP+pAxSYurnJWAq4N1WR+hFTmseCXVFWsZr4EEtqvj1iqltXDVDccicIF/YEIAU2CiBdSbfkhBD9JgADKqa68yC4R1H7PsvmIlYSApsZGwXoT0aqgzmVErorUTyvu4I8xiIvr7i6W28DVlpgM3hREkyjwC8PDekPJiTnq5UU47hirqZ/zmUPqGfqdBRbMUWoBqu5dvyQXpN9RSOG0WFA/Ck8viNedH1IkpUVeny7yeXNoSXOniKg6tra0xVgInMLdWoq3CM6zAbv+qs7HYiGNdgUuV7nz/oJuRWJNZ04Afu//ZWHEi7TPQSRxG+ZZkrZNAAgCeI7vFvLqx3X56OBn2eHJiM4Mq9wXagDv7V19ijfkgv0Rra//Sv+7SDdcMekDS2XXlBQ2bHMqNubl7ywGmPRtFKdgOR+q6MY/F7BFl+80mnZZpdPLmaDm/65FnTcyjri11+/WK+iBoQ1BDxyCnYbRbS2kSqAnImjcAEn+cLgrKWtOIubXCeSg6aAVpLZW7ByDRK3dtRQ4sv7PqRnLjtJbiqkvaSGlYFQAdLvyxF9g0BgEgRkTBKzosARlBHaeWKOpDoXUViJQ0FQ1SxEIIMHQaSwGI+/UU5oGnRs8vF12GTEN9oJTdgucMvza+I5KagSCB/wWgIhbg8PMqDaaDD25fG0ymWoOVIK4Fd6wPcaErcHGB24SpjCeeY4oLAyCsl5JYxTvsuHjLpteVqEBODIhFbrIC0/2g+0oTGlk/gfta6gos20l7lOJnsfQWfIFT3FuKHcZ6b/FXCwDEiwFkLtx92K8/0UAC549o08jfnZ6ZvmvUGPXM6ORVubf3/tUTk0bjCwwk43HW3/tMHsU7b8z3gGR51+7XJNbeuMBCRN/2O0kbZvupDbPTwOwRsv22m0vZHcevyMyOF8EFIFi4v0b0EQpCzoqLAVFXsyvNIjqXXQexGJBo4dZLa8EJiQxRqgYX4Z0KdjGF5XX51WN0qd8XZYNI/KHU14LYCJyOl5ZTbEQL7EXQlnRSjcp1JY7TjXVvBoKIdmd5LjNCCTme1l80rnpCuq5+ZxAh5obPPyYqVHGm/2JsJL3sk3cCD56mV85m4QZe2isAFLHhltiIYgrUEBCuAdNJGN5kaBafQMBc4ikuFPwCsAlqPcTKq/Y5peIdGc1UVsK6iQreM0V3xgB3HtJ/y7vpVITIFG4z7q3YGF7pvSXH9ft4IZsFUJAxvuxKo1QaprfUdbNOkppPNc40V9hs1GMb8GRp4M0oMQvSSfatPmysOYXejfEX7/j20Qdf9j/nBRFvLVX8Y8t5u3/dJPbVeW5e0T184P0b2WGwTdAWpdBHsqY3e6Ro0miay5PbT7w7T7Y8pbJ+hDUF1b3XcVJaWUOQwjUVTEIkVIKQBYuAWPGezECHz6hjIQPCoOcHYrd/Pr4L1GKRpcDtcg9Bl1/cDZxVXcuvrr9QjrPKuhHRRgrTDdSVBNqIFsWJ2cFQL/x84NICBxfeTc0MVBqOxut6FevFZ+cFEToO4Q19z8W/I+I7Xq4yaASPYsiYNvJ047JR2awgtvPyR1av7nQ1QyF3ljQAxDMIemiR0Oy2V8AT65FF+1dppxjYePUdsDKH09OrZLH0KkG+ZOmFWe8VWglafOvWlYjJVt1XHXQdMxM2Qp8vCvp4qcBsRgnsSutBQqlApsq9VR545ae3gEGBDVjOSSzV+vjFlzAtvYXpMwQczwVm82ONR+cXWmPW3YwSGsH7yCMj0985MuPF2YA7+1b/zFpzEb0J2X33//Tgxstv3PCbQRtu2bXnU8aa78xM/h/Xbzn4vzayw2DlF3T7Pb1hHjVpmtF6y+StTrs16WQ2X8q7J07PHux8iKchsnuJUkiShplHH2FgYSCpSmsRIGhBW1bSteaOQNyb4daS66D+WtEuv9G0FltmfaF8Vt0IrsqRkVQWHzJ4IhsBbaR4cxAEqlJawKRYDyq3PdEBnOsSkUHE0lkIViEL0e1UKG4rLNONPPX6AZAvxkAiP8Oog2lT9SgHbIR/owM9wYKXHkKQUYAST3f5YKJTWzPBhGCsUi/xUjMqu4NgojvUkvDuz+6QiwBiAhXoVQ6uGloJ6RAAwsR2eOck93iV7krTmDn0inWUedxbsd5bYRNHTLnxeasaEW4jr9OTuE9c0zJAI7DDqlWn22Db5JT8B9Mt2ZeHtrluho2+mUwGJj82MpNTRr5OsjnBvbPv0HXW2l+kxznvDfb3r372GzYS9703ZMuuPUeMNTvXkrUVc/NvrG9kh/42qI9w/Uigj7QanTwfLZv7HnraeHTGuygZXS5ElLoDrY8AIyheez3ESgOAXrk7UizuINQMpOYEA05kzocCEi+Ix9xa5Zns2q3lFeGBBsFuraDuw4VxaHcs1+lW4wwGTiOJAQkXIgK6ueMQyHkMSgEA7xXAEGMqVtLTfdTMgwRyYmIYY6K9s0gbEmYowv2En2P3l8A6zKq6aCEIQrAZjATWWEF0LwQK/De8veqXsboSEryDN4DIsNbLPVDxM1eQ9vJcwRjUef96gxrMhFxMBEyY0ubyOWQm7mNayNfb6Zbt2sXlC/+hZhDagZnRlLQScTV5kxQjVmBYiaPQXDzmrtIdvlashA+68SJzmdXIcS73lqrEJ0EcgbLW5EQWyrWgXtzvmt2AvXoSfDyWsqvTneajo4KRTLC1/EnoBty5+tCP2Nz+Nr+A3fWb+tdezC3m54n//M11dl35+IZNbsvz/Pbu4YPfMM9OKj5brh/pmGZZH1leyu988MWTfOcVUojIQYrarHIdhgckMX3EBRUsRJR2GhA+SqkdHGKlgle0mp2XtOJ2krSWMIX53VqRtJae8aEtwsh4VNCULsKcRpP7ht+JYgpczMn3kqK2sBGlcXBH4inV617QV7qIzyZ0oK9gIkQZNLsBWIHfKC2EcIK/T/iYf73hPwk4KupJamOJBhhq1AhPlvynWArGPb+yWdJRFN4JEiEUSTAVBxd1l0XsdIeEFJUCKhluVRLMcbuSiwt+oECDZ5dUD8ESzQWWOJT3l9QYsQzpwaUYDl0gs5Iq0V0L17TKpxQYTGgspbei0xNL1eV8AbI9u+tI9K4xo0TrJGIjxqeRuwHjsCw0oupUIukk8rxwmqyRfbxxVna1tfn6MMN2KSdBJ2le/Tff2sizm/nZXV8/0rvm4lM3Evv5qV3etefixJo/yfP8T7qHD166kZ2F6zf3kF2wmhjXXwvrR7Zub5q1cce0sk4L9ZHsjuNXVY/VjaS1EBU2VT8CWoB05g3rNMJ0jdIGSi3X3dOzaLeW7jrsp7Xc5EOT+fNGWJzXdRcEqPNqIzRzXTO46D6YQgAYFcfWrEuAibteeRZitAXD/cN3kJkD/kWlv4DCQXZFrMb+doxJAXgwWOBuKQ7VedDJ71GsmGk/bjsS0snxTa8TBTwiHGG6S4EJPMvVzETrBF5aLBTRCWSqUly67xcBELdCfq0AACAASURBVM0vUQEuXvFerZXE2szjyt5pJdZaf16JbptClthZ6S0NJBCAXQW9lxaD68feW/I7mVzop9AQvakHFqXv0D2F1MBWt0vh7813YwmQwPPh15NEgAQWBeL4AjLz5caZ2YtZJxmkfdPIhqY7Hi60nuTAp5eW1oececrzLO//7c1bzV/8fLfOa6E/w0Cyct6eX7SJuS7P81/tHj74C/PuqPz5KfUj+aTTbrU62ThfylO7kt3efX+ebvkPcaE9AiTkWvSEdr9+BOaN6qA0Wx9B7yOuoKm9im7noSchqoBJzqrieOTWwmA3v1srcFB5M9AlHIPnkepL9Lmo4M1VczXqRrBmBU+fWAuP7cXsGKaFXIpLQEQzB2FRbD6QtiezNBHFLKJdfskwgK+re+g8sMLzC5iH6xAQprM28oQjcPBcDL0PmkcBEUb+06zBy7HjB9nVNT+YSHqdmAzuwwMTn7VUsBLVc0oFtmlayeweXO7b0sWN+nyV5hGvtqfCPT2nRLm3YmN4UVwJtQckQSS4430ncFc6jdY5ZtWTxIBEg5b7JmoI7jEgsWaUnj25IJnk3WHeXDd21DeT1sBwPck9Y/PpuzJz832TzRYmdvavfsUacy49r9mXb7tw8P5X/OW8b4cAyfl7PmCNeeniHFsIJGF/rXTcNsnWdquYhtjOl7LjR87Mj2z53dy0tlONBQnD8M1XAAnkC1gfIS1AhN85ZrNj8AOeT1oJaQvMDDhF4zESDqjl4seSW0viXpVbS1baDE68xPZTROjWQrnPudQwrlI0ruippVf+AEa0nVv3OfBRFmC6Pm2Zdr+PWX09phCcbwWIRJmIcmWxG0trIQJiknUMGUgVeLjnSaXDwlYTHuWQ1E1ZgcdSVpptzoFDPB6lwIlfEYkBuO4VZlPBTFxQUw4mYinCZEoprtIkRAYQlRZD11ZR8QGaB67oS0WKok0wSmJqjfidu6de2xSgDF6LeRlZS1euJjiqbr+o6LNFeZZ7S4FjkRgAN1qN1vI8t0SnqTi9KOmtyL3DXDlTUFQy8RvRaTkluOuhW8ioQtCj+5lsNz+cbE3/2asnGbcHpnt0bFbM2PXduvlphcDo+ijNG/jp80v7Vv/IWMMZqOyhh352cMMPzd0aS4Bk1+5brLW7Jln+7b1bD27IS+xfjBqr2/9qw2w7rWFS2zTbmm0zmXRaBRtJGkvmoXufPO6f8V6ck4oLIwgU1K6Pskq+PgLhz5uGGNNHEBpCfaTYd61uvyJKUJBXTRp1EEbA4xQYnF60t1bVTHZ2a1WntciFVAyx4tU4gV9BwThbVEprEWDgfSMQqaobUdqI1mr4sMic3P3FwC/pQP9Y7l9U3a5Tb5AS9DQOzUTQbqwMEQgAU1iIxz4IkOg9i6S76r6BbnGJrMNto1kHFuZ5Gj0xlEi6i5xPIsTrdvMRZuIL4V5/qopVfqnqvSRAUzqJtBbSSmjBjumWqmp3DSTOwYVieVA1DqyE9BMCC0qzAUBJUFbpqqnFiXDzo+4tSW9xUKc6HKVVVeskJcFdjysmIwGnCWHtGRPcXXINBXe6P8A+sGgR0nVeSxhdmLiS/3K6Y/zn1jTXh8NR3yynfa/v1ldbY3PuV7PN9t1q71+9PjGGM1DZcPSrg6ueNXdGip/ylfP3dK0xS2uTZIv5zFvmzpEF72P1/JG01TZ51mmlRf2IXc7vO3bxJD/1jVMr2nERPa2iXepHIE5KPQFE9s3Xj+i0lsdcoO7CTUJk1deBjntFVZsTDJiBWwtODho0AhsK61jg3mq3VtDllyvZEUiACmGoK80bQabgnn78XFg3MlMbERGfCg9ZYC8WSeXRwb5wzm1glPAfrZNRriwmWgqkuHIeG1yqf/NXgeCRZcGo9mARp1NfXANLT7UGDZFGWOzmh981nVLuowowweAfuLqQdVRpJgpMSgyFzg9tT56Li9EqEPIJQGC/wEggyEGdiIjnnJ4q9eBK4fPUVdcxEl90xxgb6Qqs3WMx95YE2uLEtbVBj7Xl3lt0zVyHQtoDRm/kQMIAFlFPIm447iqM6gxoI/L9cwib1sBRA0krf396evZOa/L1YdP2zDDtu/kkk3xkhtnImO0Ts4DCxM7+Qy+zxnLNYL629rf96y797rrrK+8NWXnSa8607c59uTF3dW85QE0T592X/rwUIj6ll5qjfiFie5S7sbq5Mcv5XSdendkdL4GNqyvapcIaAu9soZ3YArAW2R6CXEJBH1M3floLA503xKqiLQqlxbQ+olbmyBykPbpmSMReiFyRTjGPW4utvnp1r9gIZupE4wjBShsFCAAISPDx1+knxYSqBXZdLyKta/wGjJ5DS7mzxGosKUSdjiMipkCDQUwzEA0ySMIgppTTAA5kEmPoz6onnwFGAUuxndf5N9Q8KjQQjO9RMOGUl2YHSIM4raXcYZibj7m4/F5cfroHaBUEVClSpPQWBmB/smFk5sisSvcgveWdK4AmkhhhYsSeGBTiY3iRlSgRnZmiKkCk+6Y1EWFhJUbkupe537NgX1mYCIfzhXIENBbZp84n4QaOfF9Vhftq46z8dU5wz2zPJI2+GRwfmrXloek8PDYPTcaLmE/S3P8339Yw2d/zI9/t3te79pKz5g3+7stbeuqe70hT83cmN/997fCB/2/enZQ/Hwjty6Zh8lP9QsTcLOdmvJzf2XtzZrf9p7jQrlb+umcWrPRx5UvzR+SzboGlhHYo+psxf8RrnV4S2nmFD7K2SmN5vcBcSo5Bw5+EiPHLPSnKrUR5nRpFiNqtVUprMfMhbcCrZJ9q+QXFAEAcJjByMA+6BM+ljSBzmJXSku9RfUchE5H0l7Z8Az7gjdXtUjLPMazBI89wYgY+tHDdUDkT/1MlsRxo0IaqISP/WAohHP3htFCxjf63pzlAPp8DunZXhWwCVumw0g3rRIp/ewyIGU65Ul1W0tLxFo4LsdtPuejRsBA65fyh0h2JCJFgYjO13Fuwvw2lt6KTE3W6TPJ+dH/DYVfSDThST0JuKmYKioFoDYZ6bIH2RteD3/50wZ0ygbQIcOGkOO0kv7txzuQFACSmZ4ZJ34xHA5MOh1CYeM/YfHZpsulOwK//qzOWlhs8BTcfDEf9fRe25sUAAJLzrrwsTZKP5nn+e93DB188704qgUQXItojTVMI7VkbGzWa5Xw82JLdPfqdPFk5G43WOmBIF13VvoPGp0rqCgKVxyg20qjRAwd6rpXQzaJvrL+W1kcUkEydhKjSYEASSJxW7fNLx+fUFxoS1CAo7YcFazM0OEG6w0wCHFdc9IkAVm7MGLIRYgKhNhLafRUbqbb6MqoCFPh1In6RIWkodBz8LGshaDl2qfYKACmYhiAA98hz3xqqLvQnfSz8uVdW6HChClQ0Q4mwExGciW5g3jxcdUMAgvNR2gEDiAYVWXXPYCUV6S0lwGMo9IEq6r5C3kTCtqp0Dzr0xt1b2gYc9J4Kem95OgKzqCk6SYzJaKbg3U9d2a8ZgrvvGxDcgzbzEZ1EpQrdQSTdhtYZJDnpmfn3WZsfTRrD3mBS1JOMB+YkCO6d/as9a0zHBdJiyNVXbt9p3v+Ko/PggHsYVnbtudJaczDP8uu6tx78pXl2EP+sEtrNsdS0kiYI7aO2mbRBaDdm2a49cvbo+LYPGtPcEjASyt2r4kIut1agUVz5tImIsM2ihPagjxPl6v22KKoYr7rbbyAwaxcUW3pVmkmzqbncWmTT1WxMazCQdkJJBdPQ0QJENhoAgQqLD4ufadZXHA8r1rm+hI0JwCPYlKCZBCmXumYFAZLuqwMFYl0KRBgsqENAcZjMHQVBASv86d+wfHYZSRcDi2x7wSGLloPQkB80Ug02AM+uhK74kwV4tyPBmjDdVXwQ2+FWM5PAaeRCDIEJ4QmusD2NpJSuKlCOkmP4J9YzQOzlluWqZT2lVlAr0S3PqcaBrcBBBb5oLJwqq3BvJWTZ9QwCkfQWAxGCU8SFhXEHtJd560m0BVpa1/MUR2WFDgoTNeOoIbjz9+S3SuH9I5eDXD2clG4pn2w3L0u2jP/JCe7NpGe644FJadDVvWPz1XMXIrh39q9+wRrzRIrl+Ze+/Mz+B37sr+fBAQKSg9aaKzNjXrN+y4Ffn2cHkc/O7vhrhsuF0G4eePCbx+Oz3kvSiLRGme7YAnAA7YMCoU4pyWo7LrQXqSlJf+m6DVq9E0engDddaIeooxgGBXt0HXEdRZU+QpMQ+bqIDeCjpa23uiXK3G4tfa2QpuK0Fgf8irQW25ypqWWs+DBkI15lOjMuAiO4L35RIoA+Yg3lJ3U6K8ZECEToO9CggklQdoa5fZNzLHx6Q47Cr5YWwmn5z6ACaXBVY1I8nYABisjo1FaY5gIwiOslGLw8EAjSWl7RIuX/+dCQstLWWw7kBCph2xQHlZRuQw1AV6er9JZKscEExdC9hcyBCx0lGEMiwRvDK06rwGXm990iBgXnUU9w5xQaMSm2TE+ZT8KgWd3AUVgj6xueTqKdW3xPwbmFIKgZiddSvnBunZp8wnUCPqmC++pfWmOeSU97du+9rx6880XvngcH3E3dsmvPx4w1z8uyyfev3/q2P55nBzOBhCrai4mIhiramyC03/u1Cybj06+tNaOdVqQsgBOQ6LQWBCC/V1dZaIe1HwrqVRXt8wjtWjTnFBXNZtcFjZDG8c6P+CT21IpOQkSxu3gk4721NuvWiojslZZf3SI+WjcyRRtRGoswFfjSvIp1TMshjrrnwwnhvkbDP2eGUhAK0ECgHoa1H2Ac3AxUPbWx/JbOa3kPuM8MQFOhXItKd/E4Wk5/MTOQdJUHJqyRcO8pOC7ZgiXF5WkU9bUS0QYQaIizaK0FV/4S6smqCj29IsWFuJdp7q06vbeQ4dHwLM0yOE2ltCEW7GGWO1WGiyYl4BupJ+GUHLoM3B48jQZhFDOLAFZsR0bdijoBi3kA17fEsHi94U6QtRDvetR5xma4t/Mb0zPzD1qLgns+GpisNYAK9wfHpnPu2Dz44cys/spkM7Uknf2r77XGvJKXTceP/3L/zc+9eh4cQEYCNST5aHJe95/e9pl5dhAHkqI1iknM41cbpmsaZmVHwzQGbZOM2u1mq5MN7XLeNMvmrmM/NMl27J7eYwv0B3TGAgvUK1SAdiW6htbf2Y4tYTiS7/c6/nLVd0wfgXfMX2UXjRq1PiEaCsxm1/oIJiZRJ2FiIykyL62USICXokBvZjoEYb5fGKTpHKNdfukeci8yHbBVjy5Oa+l0EwX9utqIZlskxOMCgGtKdJ0IaR9V6Sw/lUVKDqbrAvahpZkqVhI+0Z74jb/EuM6CawEpGBSInZRSXUxTMBVTsgbHwCSoL9GpqdqsBE+2YCW8epb0FgAJ6wG+ewuxjETn0vaaXQTurcgkQ54jotNrVGjJAj8FavyTA7jSYhSQFGcYn5rI2gebofE6VR0HihGkRbE2o3SOWRXuCpClpTw8DuLc4pocXOdqLSSoJdHCfSP/aOMc+xZrh+vDXrtnmmnvZDi3OvtX32iNeRMzkuHk4OCq75tr7C4wkvP3PGKM2bGWZzvN4RvmElnKQBI6tk5vmFxax7fSbClP8qU8m6zk93R/KjPbL4dQrOswitQWBl9PaEc31VQgCduGVAGJCNwCRPQzWoDRklgJ1Oq8ps0fidWP4HV6oDi9fsTvVgyTEINW93CKGMXDIkTVtRfTRLpBo1qxqzG6FNwx6EqqCRZtxCT4OwjqRqq1EdwhaSlaUylYjgIP7ugbWnxDTYRApNBCgIkCQyjuU1j46EIOLz7luaXr1E9yJSXBgEufhUDqNBVYiAI38lJdRapHM5MgxSVBkbUNruGgIMVaiQ7seECueA+1Ekob4co4TG9hnBbNpJze8t1bsaFXuk4C55RM671l7ex6EgrmlCJDgMaqLAEFZi3wlfjpLa2thC4zuh/awKAZCdxjxQwjgjvXMyomA/vVVmYZeqXHFCuQAbVNpQ4doEvaq2k+lZ4x+YUkaXSH2ajs3HronrF5YPOtUjr7Vl9hrfkteqrz7von+9de/H3zEAprnvDabVu2No+Z3JxYO3xg2zwbxz87ozVKki3laP01t69fNUm2PoMW6ErMRuGXUh4YEMklWMv6q8fY+u3koYZEAUmlY4tWz5oVcQK/3KiReRFVtAsYEmfyHEl8HrLCx0sknYDOE5bsNVvGg1vLO090cNV0a3lpLdbF0TGGwZ0/E1iro04t5UqrcmmRnuTpIpr5VIMISuJMAXX7Fsw6BmhB/5zFSkRMYAMVY0j4OwjknOQPmYmnmVSBidiAvUDmQpQnvEs9B1ttyQXFK3rFMoCJ8BwRT28JGACxk5J7C1Atnt5SgvuUKvf45EQxEMTrSSoEdwWE0+eTlGtQNlzhziI93Fqejhk6wryeXfK9YK6VlwdwvQwkkeaN+VfTx+QvLSzAI5uv8+jdknPrjzfVc6uz76bvtTZncT3vrt/Vv/biueoJbecpu89tNOxX8tx8vnv4wJMXAyTFMunzqalybCWNpTwZr5jb1t81Sbd8Ix5T2V6pky6BgQISLbRjePUYRV3rLwda1W+K00vwzsB5SWU4HEdSM1UV7VWNGoEvBF2Cawvtee4kArAHIWT5KShYR6OLjc+TAMWloILeWlQhjxfG5gBW9yNuraq0FmlOsboR394cF9j982QhPqyY164tR9gmyETIhUXnpxiV/jpDVsL2LFw/epqJsm3BglNrFWjnkkBVlHhHmYmnmZC7K9BIqAgO0z4S9IVR+BpA8S9iBAgyujswA4KgW/F5SL/Q5ylHj9MbxS0VuLcExKqBBO4PfgueUA+TBSH9B+ktndbT7qewniSoA6GCIOYlkupjRuKYDEmltD8CaG5KRToJUwt4WkKGgN85Ve5L6wrP5abqheT68fvUM9zZjOABMtedIJBoZpP30rMmz7bNfN2OmuvDSdIzk2MDk7aH5vj2oatsX4Bzq73vpv8nsfkXmZGs9070r3nOXKTCLj31td+Rps2/y03+t91bDs5dGl8GHt1jq9cw28YNkzVaZvuwbeyWdisfLDuhfTzYnt2TfzBPls6AtZJmDVgHwXNFxPrrvlqujohYf0VQ3YD1V8Rj7u+khWCQcBVLwBQcV8kT09mA0A5PsmJKOrjzz0F78c5DBX0Yp6saKvr6htZHQkOCFAPG2sVrt5dOt8XSWtq2jGAs2gfeP9FGxJqttZaYLoLmCkciHF5y/y5FoLzvBp7NEFB4MeA9usyGYQsSQeQzOqbx78taCdQeTGMmFJR1O5UikBPAiF7hsxIa1ctL8QgrUSfp/kqAIWA0l3tL2VO51fkmdJKp9SSkRahgzrbeGYK7exJUESR8aQAykI8l91xpYqIuD8K0VOCm0rUkpXQgjd7l5wWBJBTctXMLP0s9vZDlyHkGFuAz0ouTdv6AE9yH475JBn0zaQxMfsrInDgyNovoubX3z09ZanQeZiApDnTVhc1ybK/+iV156u6LbGr/zOT5H64dPvi8eTaOfLbcY2vp1IYbret6bDU7raXcpbbskaOPHh1b+aCxUEMiLVPJ+hvTSKguhBxbpAnICj1q/SUtnNJDc81or2odT8xAemRRMN5YRXvYqFFSRq66QdePAMYg9AiQQH02Ce1hWk3cYjBthOsooNKewZn0FgYBjLwxtxaBGkVs3A+QCwzqmmlQ8aFqg8LaCLYvpjRjVhhRSCMpXMJ4nZT7A3eWug59LlpvofuIYQVxxWkyWgrRya+SRII5c3rgNXvgGFKuOC9pJuQqLwoq3HZVlmCoA6nWSogYcSqM0yV+l2AtogMT8Nxb5UmCKu2SRGe6z9qebi+s7hWDQ6Bw1TpePYkuTNxgA0dd4c69zkIgQXTxAzcgjmMclOIjQOdWKVMswNRKXwMJghgDIz0XCGLITqENS4UFWCxYNtlhX57sTD5nB+Oem+E+GPTNuDngnluf2z4xT/7cZFPNG/fuTTrpBSMLXA6KEj/zYMN8+AU8vnQWLtiVXbtfZK393TzP39c9fJAtYLM2rPh9ACQ4zKrTapmk6Prb7LSSbCnLxivJ0SOPG62d+gFjkiZaGcj5REwiXozIK/cZNSQYGsNmjWENiZ8mKrVGQW0B61Y8LYVW6aqGBJfGfsdfCrLF5al2Lh770EWCBIra0QRIyI4ttyLHV7ZSaNe2YwiyLsOAjAVAJ5zJHmoZYVos1EdCdhRJa22KjSi25aW04DjK2FbBRPw0F+hTiqTI5MWKx1lVr2Pslrw4CKP0P5Tn4vYlJWZCdSaY2immPbn/CEx0ukdrJXoeR/FZFYBmWYFj6S0nuoesRukkDJLUyNFvLS8sSdJKmBNi4GANIihMRL7sz07xzrGiwh2dW9MEd2AkfhDn7rrllvKU2uINhL3QvSn33Kq0AAtL8yzA+KgFXYBjtSSxLsDwPdst9sr01OzTNrO9oW2vm3ztpFiAl/atPmysOYVehN4/ffWx5kOvvKsuDtiVXVdeaW1yMM/sW7u3vvXn6m5YDSRk/X1/w3QfX2n9bdx33zcNhmf/JuzHF4H5ncU4VrfrLwvVsMugUhuDqDE5wm5ZgKZuuBBlMdPkr/j1yp3PE22xlPaqbh3Pq30JZzmtxMltFhTxUeiLVbQzoMDJokYi7fdpeQHgAfUrudYUinU5/BtibJAWU/+WdCKms8y8aa3wutCmzXbo4PhcZ4IpL05pQSW8SzKiiw1+QKkxurUBiDADwUr6wuhFfRoxSebqdHRzX0cMIOmAAR/Js3L1OOKntRNhJqCZoDU4wZW3X2MS1Ilo7YIK6MhN5UBHMY+ZbVOUxbco+qMoGx16pQIrHQ+uSUCn+FtQT6IBCRkIpmiwCzK21wfq5wJqvfkkdLbE3KZVuENgLluA3ddWbt4I51lhAabzlD/FAACsBYOKx9xYIyEthRYYbAFW7jb6/ukcMA+qU1t+UaJ5Y3qa+Us7Gq4PJ6ZnbNI3k+Fg0c0bO/tXv2SNeQLF9dG/fPW7xr/zyk/XxQO7vGvPryTW7M3y7JfXD98wVxFK+SDFbf5wYp52bmKeciI1RbPGo6c2zfJ6y9BUROfYMsv2/ge+bTw8/UCsGBH7s3LDQA5ipRoSri+h5blLd2CkmdL1V5xIfCylO0i+XPQC6UQrld9YjsY7I/ApAwml5FT6JXBssX5R0TAx0YFSFT1yEHXuTES/iNAeqx8BuPVsuH6TRj7mrJYoKtWotkHSpe5PzPKrAIDAw6teL9iXrqJ3bU8QRIJzJ4hRzi/53opf4ueJzbnPF0OLgw7z/O+E6tUxhrNQjRSVRVwU4oOUE8Qyifjs5GJL8AZZCbEZSh/pP2e5t+pWuWsgIZ8BXEs1o0EtgAIp/BOFdwz4C61w9yrwyxbg0gx3rm6HxQGmuTw9RX5eus7NdQHme4frZmXzJeeW6noMgGWNXcrelp6W/j40b0QLsGn0eVpiYQHubb55Y2f/6t9bY76NYvrk9jteOPzNl/3+HECy+8bE2tcspj2KqiE5d9gwW7OGsUnTTBot05l0WlmzUxQiFhqJufvB75tkj9o7ew4JBkhw12AFdPEnBAVcG7pUT7nrLy5VKbDiTDtvBVuz6y8EXaIpkEgMGRDc9Jj1l84bgUQ0GmlTUjkRsVg4W9RIlE5Abi9aqeMMerG+ThfaUSOpqB+h+8tLfVU/QoKTt+KnxouyP2BpXhdmGW7lwpEa40t/xwp2d2MRPLQ2kql6EVevwgYN0WSqQATaprinBphHBveVxfjYKwMr0wJO3Hakk5N7i9qaiMbNbTekPUrBS3DJ4dJZtErXO6xwcFG1c8FEFKMop7eq3FvsKON2HMAy1ErfS49pTQUACXRunXrx6klKaSr3Fkbnk0yrcMcbGLaU50CPxoSw55YSv2f03JLWK153XkpNehqY9BITQRwAtJqRIGtV4OAdR9fbYAJGs72g27LHSNrmvcmjk9+y49F60jC9QW57JhsNTH95aCbJyCyuluTPrDUX0VuQ3X3vqwfvqt8mxa6cv/u/WmNfOMnMC3u3HqiNQHGkCmtITmkY1/W31TbZpNNqNTquhiSbrJh7H/n+SXbKz82qap9rDgkzFtEZ1PZuvVu/hsQHIeD5tOKHf3hAgpoMVLRTmkbSaZA8DYTsWtZf0CWiExGDina/a24VkKC2A3hAo4q9uhrMHCG30/qKnlMS0Uek7YkyAtA9w5QSu+C4pxZpY1JY6fXgKjr6SuEhayOUEmNhv/hOBFx8JlK0kCmMXgV4QIc2eX79f/HPkStwDy1MbwmYSMV7qT7DBTgtIlPgVsWKLmeSFP9XTm8FzijfCqxBJdApYu3lSYPgoFxc4TSdRNddYPdbFoVxVS2mtNnzSUrTEckCrM89tABrpoFowc6tOWa48zbcUwyX+eTMixQlKsNd2AmgWDuCSM6pt6CWRANJWN0OqxCuJQkGXIEVUc6TquRtK//95IzxO2zS6Sb5uDeYFEAS6wK82VqS1d+11ryIgeShIz8/uOGyt9RmJCu7dn/CWnthntsLu4ffOvfQd/9ACCSuE9s50vW3k7ZMq9lpjSZLuRkt543mcn7Hwz+SmR0/Pp2RuAQ0VoJDMPHnkLAVF8Tk2BwSVmRBQ2Bbr6SHpPcVfhbSl5ImUi3XgXIAjsQZSV5YfxFIvK69kR5bCDoIUiol54MYVLSHFfukZ8A9Ar48y7oL25SEds22ImkxEOpZqBZTBIMR3A9IZaHgzr8LgATvu1Syi0YEbeCL75kAVzEUTG9BWssdTh2PAFulIul8M9h/CURct19lJS+9MRQUitsLQnkR87OCoTg0wdW7Cw9eEBBLKWsnEPxhNnpubbG9uIvKDi5Lc00qRPeZxYlCkcQ9BdoA3D5Kb5U1GUn5wPWBBBQI7p4mpOtZivugKtxnTEwseBgwCQESeAmUHVpXurO2Qfdf5rw7Yo6aVLmuo8ICmT/TdgAAIABJREFU7KW2qDDQBzE4H2onH1TAl4oSqxgJXRNuT+49vq9kMhCtjdutNPJPpI82+4vUlhPci1oSO+yb5vLQPJSOzMoDC5nfvrT/prcbk/80vQb5ev+N/Wsu2lcbSLbs2vMpY813Zvnk29YPv+0f6m5YzUiwGJHntG9vmm0PS/v4IrWV2ZX87hOvzvJtL4D9oPDqBeiwGHFWexQFOmxm1e1RYP1dZiS0OqUVOoGNH8wh2GNaR7emR1pCqa9pxYhsiVVghAJ3Ccy86nTP+ivnqVujwGlstqJduaSUJsNtUVhH8tJKgc4SARLNVBBXAEhIH3HwoNgRVbEDk3DxDFNT8BWE2ojWWQhQAT6KyA8qCD5oyEdUHc3MR163uiB3lgcmXudeSZfEWIkltxZpB0xxqgoUiRWE7q0pOgkK2wIKRaCaIrgHq2wKnFSAKfMziJFQAA8YkRbcAcFAW2JrLfxMBHdagWv2Rmk05SSD5R8OjIo3b/TapEwrStQpJ8CIyqJEfCkVkMxiJIrpILPxn535GYlp5H+Xnm1/sagjsSOzPkxGfdNP+9JOPllILUln3+pV1po38IsyHO3tX/Us7r816yUpUls3W2O/dTENGwvH1mpqlnqpaZyemm3bGyY7BsWIWavTKnpsFcWIxf/fvfazWb71EnzKIEwzkKigvaHJiKo9imYkMGOCLbDuORIPKcNPtBjRBdagGJHEbQ9kNlKMWCzBcXKfFFtS+sUxHGYkCsx0ry/QPBSQsJxDqSmfSTmW7oFP4NjSQMKivBRs+qCl60d0PYgS4aldfLTLrzo2udjc8yBprTxDtxmdl/sTAUUBkjAnARFJZ0EaSxcfOlByTJbBRiYNitROKIRpKNROksLFRIENOLEwAF+ghvUyMBfuxeWltxzzEfHd0y5wnojWDHQBIzEE2p6rxykFQ+dJIOfVk6j5IghW1RXu5CaIC+66e3AFkADDCXtuUXoPVvSu/oaYyGYYidM0KEepeokRg0THFDwRulHjrKJEz9XFDi5IXhPIhvsLUlsu+Ph1Myiwgx5D6cQ0/2x6dvLTjpG4LsBJz2QnBlCUmI3MiYUByRusNVcxkGT5/v4bv4eBpQ6Q3GqNfepwPPzm4Wff8S+zNpj+e6xqL4BkkjbM9lMbZqdpmqTRNqP1pVZqlvJmy4nt+e3HX5fZbc+qz0ggEOrUFvJ0YQp126OotEsIJPjYKacRRGTAHwESDtrESKiGxEsTMT7m83X91StuCN6O6aDQEqshKTES1g5866/nkvME61lpMa2PhOc3T/2Ixxho8QBsit1ayHgKFlJcmEprldlIcY+1NqK0F4dpjo8Q21EgUvyUGZgQFlro04PugqrUk0AeW6rTE7AIu5/5I3NpRU2RTNJbpmQFRgAqop7bX5mdKJ2koiNwDcFdAZFX4a5E67ATMD78uGoX/WRmz625GAlQA8w1qsaHSsPAWhJ4IHxQIM2CLcA1ihKFKYjzbtZcEqWRIAxI+q+qTQpWvQa1JPCQCVhSWk0YkgKSL6aPSV9ViO1uwNVk1DNJ2jf9ydA0tg8XVd2+tG/15401b6bHPhuNbhi86Vm76+KB3bJrzxeMNU8cj/P/0P/swa/W3TDyuXIx4tJIqtoLjaRgJAWITOxKfufxX87s1gtqMRLn2MK6EGIGtSYj+t1zCxjQjETSVRjwKX/vtVmheofZjASklRmMBK8FcQG0DenxwayoqGWnlXS0669O7+BslQgjIfblAihpCygBwQJIp5jIJKAtyFzISGCh01G4UGfhm9JaWjOh+ybbe+eJw8nYpUXnQ24tTIv5ll+u85H0GBna3PbARgREwK8lTESDCBO/IoADM/E1AI+hQGU31FMkJnHzMBIRzHVjRAy+kbqSknuLgplqn4IpGM7Pc/B0R/ZWwdxKRDOR2LArDSSyf3W9CvxQpBeNhLWiqRbgwhEG0EopLZU+ohnuyEhAI1HMDTUQj5G4NBWltihLFmpAFJjDuhGtWcQYiZfawgTFNI2E3WsIA7R/AX494RCDDSa5NshIkvy29Jz8lXZs1p0F+CRVt7f3HboisfYGBpLB4DcG+579E3XxoKhsv81a+/jJZPSY3mfefnfdDWsBSXqkaSatltnabLcnWSdPcKBVMlkxt3f3TszW74KMFqVZtIgdadjIqaggRREFACCa5AZ13zwBSSn/TwGRVDBc/UvxdMBIwvYokoqLVrW7p0sF2ZJGQkJ60KeK5fcII3ErdRL1EWTLqS0fqFRrdXA1VdWQ+I4qqIiPObZqAImkxZg5bk4foe80SGuB/RkSg2z1FaYkmkgIIlIgT18LrIxxhc9ShDCTOCsJpxyKcCp5eC4uFMHdZXUUgJR7WVG6DEHK3XPFijbm3JrLAqwqt/2eW1M0EgISTyMJa0nE/RRnJCrQL5iRYJ5aNBLot+PVvGBg8jWSCHuDVAlTWa9x4zRGUkptAaji+pY0pvzu9GzzUpvkXTtqrQ8bo54pBlylO/vm6LHRogZctfet/mRizTsprufrvQ/1r3nOD9fFA7ty/p57rDFnmUlyxtpn3vJA3Q3nBhJbzCBpdLLMrpiGWTa3Hb16Yrd9G2SWVT1Aad4GOrWYkVCuf/Oz2j1GwqxAVdljmsorRvTSYuX2KMUKn5thEBCgQOxV6Ls0DuysXIxYYw6J9Npy929a199YMSJoLtBmBgV/SecBU8H/iRUjqroP0iqqrL/8cz6OriFBoC/E9FhvLRHhhZGQW4vSUmFaCwAmyyYuHUhCu6rMRwoC14c9zGAAI1W6uxHr6MxlvYCcRDT/vDgMaA+J0kogJVEI21p0J0EXgKQQ3N3yiWpKZgEJsAMfSCLpLwEYKlAk0EGHmRLVPctytOcWrMxdFZPXYJAEd1XQ510rBEBckiFz4vQRdUe20vo90JLC+RybZCTUz2rKpERx2XGTRxH6xbUFQANYozUSbV2mBhL69wQyWKzpMbVAI2EgUVpLkt+Xnm1e7DQSV5RoeyYZ9hc9KbGz79CPWmux04gx2fr6xwbXXHxZXTwoUluux8oChlpJauspvdQcLfpsZU3TSVomGbTbNl/KxsBITGJWstuPX58nW86fi5HoFvIYpLWbyu9oW2Yk7NraCCPxxPZIw0YMyNXtUUJGogXmOoyEcjfIRAA7yKOAnRuk5b0UTyqg0oxEB3hOTWEaioXnOWpItCCvwBa4msd80Eo8zbEVVrMDWBTtXLwuxUA/4CaAaziS1spUjzHnBiulwxyaBP/lrrFiACaQLpIVI2kliauAZ+0CghaxDEqVFKCjGQnsHSJurJ6EW5XIilj3jGIg0ayAAKQCSFhchmNHdQ5MaXlWYbcdCdAIJCXmJMI+N3Z0WkXYJqVYvuhrYwdYRCPRqScMziGgKnCcOilRgyVuA0xCAF/mlOC1Ut2HSiuWq9tjjRsFSFg4R4ZbbiVPQINia8hIbP5w+lj7AmtH63aUrw9Na90kjb6rJXEjdxtjM35gAtXtF2x45G7nTasvsan5IDOSte5f9K+75Nn1geT83ceMsdvW7l9bMff+xnrdDacyksffPrXPlpnYlezOtbfmydZviTMSJWzjmlk0koCRqADvt6KfktpygU7P9dAusTkYSeDaqtBIEPJoTgguLomRkIsJU3wAAMBIWCNRwCcWZAx+OFlSKtXRrgW/9hgP1HHrtjI1uv5y5f9E2Aun0KB3FyW4gjkjyHRQ6JZ0ng8k9P0xI1FCO35PlBMDjYfAkoJ/cSPZh5CbCVWw67QWPjPuvNFajFqMgIjGElxIJ4W7qFAknCYi8z9cPYikl9gKzEGAVuD6Txe8IWoVwnzilHWsJ0FXVcFkdH0JMhFOJ0WBBKMhfZaCHhdEcpGbP153VlEiXjEwEnRTcd2ErpvxW42ApkJzSTh1hSBBTMw6RkJ1OSzwK8Di4jxiJG5XqFF494EEeajYRwaBqSZY2cP5+xMkldjOaCLprjgjcdZlTrEpO7Jih6KRwBMjaa9pjAQeCwQ2YHTi/jqePs7+ANt/i4JEO5J+W8ceHpt0otukKPth/Wi+9KZDl5vUfkgByd/0r7vkGXX3YFd27RlYa1prt9zVMObDtdsGx4HkDxLztEcS85RW6jdsbLTbab6U2cZSno1XTG6Wszu7b8uTLd+0GUbi99VSAECFhbU1ElqJb1QjEeA76YyEUnDESLQRQQ3hmslIiCnoKnICH16gb5CRKBDj6nnVGLKskRAoKtBR/bV4eFWUkYRFiIHQrkX2fEJsBK8+N9axEWJHED3hf7ibCZR+OGttmN6Szr3g3lI6Ca3sOTiSBReEetjpvIxEB+1pbVU2y0hC0Jy/TYoDBwLFWv22CHR1HclGGAl/fWx2wHQUrA5cePcCN/9slkbiVmZemxRJ/8WLIDEVxhZxrEPxChKFFQmQwHnCeefr6TnJc22ad539txcASefhsXlo80DSetPqD6Sp+W8c19e6/9C77hLuvTULUOyW8/e481+75QDd6FnbVPyeGjYWQPJEbNjYaJrlpjRsJCBJ7Ep2e/cduV15wiyNROsKvqYx51Ar7AZc6dpagEbi1j26bcmiNBKnB1dMRpyDkej+ZKKREMOjgEr/1toDMY+wgnxORoIkyQOSaYykZP0tHj3NSLSOM01oJ/uvgAZpI8BIvDSbuJhc9ap18zMAJIg5lBlJ8TQmMxkJgAfMeNcV7nUYSXGWYc8tcQIA9mkthOtbeJqfpKuKz81okxJhJJo5AGPQbIhX8e5escgM5+WlrYoTAo1Ep4BIW2IrLJx3jJGUNB04E2YkWrPBeowNMRIvtQU35OvOSGw+Sh+XX2yztOs0EmvWTW9tYIyF6vZeCUjYgTNPIG9f/clLkjz5Y97mxNrh3vWXnl93HwtkJGHn39Mb5ugEO/+2Ou1W2snyoStGNAWQ3LZ2w2YZSVhHMksjCWeRIOxTTgMbQrpbp/Lo7nEXUdhLi6mhVl8vjURauyBMkTUagyGBVyS1xVoFC/ykXWhrb1B0qO2/AraYTiIBnVJk06raw2FWoUZCqTPch9fx1xHlPK+qaPeKHL1qdpfKEuZaMBIHRrA3KFMJGAkGxw0xElVPUmIk1I7k3ycj2bhG4oznygo9TSOhdJCkq5TjDV/3cpqKaOS/jkYyfUriNI1EUl9hassFIALfXvq4/LkMJNQBuD0amKw9WBiQ7LvpuYnN/1AByT/2rr/0afWB5PzdXWvs8uY1Et3596sNc9qT0yiQJHbFZJOV7I71X/13r5FgWgmhh+dj+K4tStv8X40E7hOxNgI+TCvW0UhcyN+IRqKZVB2NBFafILgXTINAgCzB82ok1ALk/3SNhGe3/1+NhBlfLLWlNBKbn0gfl15miu6/SaPrKtvTUb/UAXiTreRb+w79UGrthwk48hNrn+5ff+l31QYSdm09ku00t99wtO6G5c9VAEmr3+YW8kVrlML6W1iA7zh+7STZuuv/XI1EF+3N4dpijQTdW5UaCUZtbS+urCNZACPRrq25NZKwz1Zd1xalulBi3YBry3Eydm05UINHG+QL1EcoNRMHksKZBIoFLCGUtVbVJWiNpEhrQXppPtfWAjUSl17DVa/SDdjFxHU087aST2Vo1EnVSHRaDL60OCMJpg/+m9RI4Huo0EiOpI9LLy+ApEhtjTLTM81IK/lNAsnSVTe9yCT57zKQdLt/2b/2kgvr4kFRR3KfNebMtcn6GeYz79pEHUkESB481jIrOIuk0YQW8sUskqJp4x0n9mXJlqfP1kgwJVKnjsSrSA9cW18HjYTqMf7/WUdS5doSl9l019bXs47E5BkWJVIPrVJ6C51wOCjRFJ+3SVHPUozQBAbB03C5h1UBKAQW2rUlPbe4jgQyZFRMiKmdf091JJRmmruORGkk011bvkYiOgoGVV8jQbdUSThXlmbRSAggqy3DpRYpEDGVywrTTawD/avVkTyQnmN+xKBGkmSj3uAkAEnnqkMvt4l9HwPHWvdPetddcukcQLL7DmvsYzdf2R4AydazGuZE0qwCEnPn8TdM7NbvxBOlluyqPXuksl033MPaBxHgQ9tu2f67qToSp41I23qoJSwXJMI8Ekp2aTfYv5fKdmYH0wsSSUbymEikRYr8nly8QR0JWa+1zoJpr7DzL9mgySLNCwdwbnFlO/btwmJEXydBfYTcyKS88L8hnkh3LQaRgI04DuK622JD31K/LaQ2SmxGay7ky6iPSI3KdhSmfcFY1al4jAJbrJfqJihQizANgRxdaiRQx+pIKivbUU9StRyAxpiuCetIsBZF6kgYaHADckFFNJJ/I5XtLqqgOxwNDgp8CIzmqSORGh3NSJgtJubuokXKyQeST77KJsm7mZHMW9m+uF5b8wFJfufxX8rs1u9Gbg8ZAcjGYA8oilRhZTsF5zqV7XP02tLi9L+LXluYunJgVppHgmCGQjKK0VCHgfNIaKb9Se21Rek7l3iA75gDfii2+9qFKU1GhPQfCO7xXltiisiKSvW8mGs4s2EjLAag55iFcSjYh1FNyhMQgYOD1pFY6rVFgQMbN2qhna2fxe5whnuplbxOnaHKH7SCLw23AryjqmyZVOjpOV5A86YZzqxsx2twbxvXQwh4VTVthPLCepXt/zZ7ban7SteNCwDXtJHdcdTdd57KdtVGHr8/qTMhgIJngZs2Jua29JzkJ0xmnGsraYxwSmJ7YPqZTEncZGqrfdWhn04S+3YGksHgt/r7nv2j9RnJrj2fs9Y8aTSZfNPgM2/7Qt0Ny5+bE0juOv5zmdn6fQgexVelgESv5CW1BdxTgGS2a8sHEp+R6GI9xDGuP+HlNg+40swHkstYv/Bvovvv9F5bELxl1jyAt7L0eit9zaYAXXkeCbu2dKU6Va6rP3FBgLZamTXiAYkDF3GecfdfclHFh1rx4CywEpMLi/cjrMSNRMSJ7GD/hZ5hZNKLNW7UTzURihBEMNBjoPW7/6KFFVbkSh/xHVvQdQSLEd3uis/680KkLkHNI4G6guCzxCiquv+GBYklRkLFghjaAguxtgmrZpYzu/9q6y73sALg8+aREHtx9C5kJMRMpGkjBNnNd/+VNBYzta9vr634hMRyr600/1J6tvkpZiQMJMG43U0DySf3JEnyVnoDsuHo7YOrnvUzdfFA5pGM86d2P3vws3U3nAkkhWtrikZi7jx6xcRuv2geRhICSakgkXt2/WvNIyliG3TtVatm/HtkQiKyAW6KqLYq9oP3ePo8EldHUsArpXYgwkK8lFW/9JoiRhKbRxICKAJJSUgPgIQaOrpj1p1HQgW4zJoQDOS6qX18wbji80gISKjdjE5vYYV7hrPZsQLfm0VCQ3dj80hgvSLKO9zNYB6Jn0YqzSPRgd9VOYAQPVtoL4MCV3rTOWhGEoLWhueRhKCjJyS6KkpO11UzEuz+S0J+MNgKGM4C55GgRuKeyNKERKzAdy/Sv1b3XwL/DXb/bZjPpWflu09+auvQ62xir6W4ns87j2TL+Xv+zhjzHdl4/PT1z/7azV8vIMnvfuTHsnzHD1LMFVDA1BavXuszEtVFGAPp/BMS8U2RBoaY8pqfkUTavHDNQlAEyG1I3GERQPSQKtX9F2I9szcCm9I8Elmwo0YQYyQINMBI9HwOmjsfMBJkg2r+B4AWAQsWMQKAsSYi1e3YE4s7DkTSW9wDrCARCBRYmMi9UKaktyC++jNJQCtRNS+gDBBQU9ot8ujjksADEYhKMiGRtBHNFHTdBIIN6SPzTkhEkCgBSUS3gAkXBbMhuzG7vFQgBTD05pE4dsW9tNRnQfzwJyQioHJBod8iBTqwwj0CzFvkhETYb15qkR+4tujeOOJddkPhz1DpkO8KiihFs5ClBI3aLU9IxLwyphnx/CBXSsfGswlapNSc2W5S8/fpY5JfNthG/qSJ7Vff9Cs2z/cykOT53v4bvmeOCYk4s31s8gv6txy8aaFAogoSW2nG89qLOhJ7b/cF42zbKzBNRMtn0UgQSBY6s92bR4Kr70gQL09IFMeRzs/jI4pBXYJ7fGY7BjihCjwLBN881ZsKUCCBvowBI6FgLqvw6Mx2r3iQ0lPSYwxgrtiXbg/PxYgysx5BYe6Z7doC7IENgIzfJkUJ7jVmtuMtxPulWAkClGglRUd5mutCzKR4CEA5wWinAKX89PsuLAER6MHlik0QlbgRYURkhwDvwotrtUVpLXR7VQyzktbqYW+rmNCuK8gBADiYywRFBIzYzPZSJTy6r0gjof27b4+q2pEXEYOCtBNoJLrJI5+K0xiKD7hOADyPhJiedEVmoNvMhERqMwKExCuK9IHZc3epBpXo4ippJGISABYqukp5QiIlKeswEvre1P1r5p9Mz06vPdl1JO39Nx1MTH4lA8m8M9tXzt/9X62xL5xk+WW9Ww9+7GQBCVe2F7NIMrti7z1+0Xiy40pvYh+uipkVeLl9WGqyRoIBUJiC/r0EJtEGYDVcntmuAzOEF1mtCiuA40jaSCqieWUL+9erbcnJu79J51nchoImu9EqGEkh72pNQFrIc/orYCQAzNHqdkglyX1TQCIDthSoUeAvriCwALvvy1vp08haxZj0NVUJ7nRvgzRXcaJU4a7ntpOmI5k4ZJCSctPCu7sXopeoRcus/nbISFCGgFW769RbrhsR3TvQRkBzwFiOdjBdP+K3BgF7sR/U5xPaJeBDeNOaBwbAqe1R8ELYMBAyEgI1iM64f16Bx9uj+EBSTotpwZoYBJ0H/snsQs+uh1Og63TaC6a6XBwTRlI6T6kcly8OHlrFSGJiu+dQQ71GAwkBKHIUaSUTAEldRtIyH0/Pym404xwLEkc9M0z6pqhs7w+HZnLKyDx0j27aiOmA+SJ5Z9/qB6w1L+Wtjhx9Xe/A866vuxe7fN7uX08S++osz358/fAN3I++7g7kc2GvLd0iZdJpt1qdrKgjwRYpyT0PPGM0Oe31FIjiqS14HMRqiw4uJ/8qzcGlPsK5JmUBGolrEOR0s0d0P7kFAQZ+MPMEgRlcPlFG4oK+EozZHID5e7djrrRmBubPZJdjF0dyXYDduF2qkmc2Rc8+uaEi6Sn4rMwkgdShdAuOtUnRM8yrBHc6FwJX6bYraSS6DwQ4Yn5wXYtwUwewdJ9ovK5LR8XTW+78vQaOKnXF90jrJcX9BO2lqBdx95O/U4gdMBkRBhoTdZCwC5P8inQWrKTJAIqzzwuhHOKqYiMkvJM2Qo0a3RONaR9iFtQMUgf9gAFwgETbsRewagjtKsBOH2pV6nKMri1hPAAECCRuvzqVg7Ppw2JETvWAew3vv+pIDCWdxFgkqCNb4ZnqCmQZA4DhsIutNGRKMyidcqIVgtZSVDpQ5rCAk8q9RsQ+4E+XdCZOoplYKbVFpgkEONwPNmYkNxjsiRtDWmM75oPJo7LftknYa2tr3zSzWK+tWaujaGhf2nfoj4y1XDeSfe3+nxy84/J31cUBu2XX7quNta/P8+wXu4dv4Jm9dXcQB5JWapYf3zDrOxqmMWgXM9vD7r/J1x78j6PxaVeXGEnRnJCTRfg4kSZQYiS6JTp+A5S0wFy7MBLQCICRyAo4llaKMBJgKQoUoLWpBgXO/0vjRr3CJ6cXraIR/NCGFhlu5U93LNJc7FKq6LeFTEOYSJSRQNAFcHaRGoBtoc6tIBXojdOt6rk1I73F7MfN0MX/C84d30IBJq2XOBiBh8T9QSOv9JNOKKJ/BqwEZk9RyKCixNClhR8hZxUFW4hjio3gdq7wkUBIBWdtH4Ycv7Luel1/g5RNoI9QrGfmAEG5rI/gtUVqSLgfFAAGBNTKWSQAhFUNG4tt47NISoxEUmdBg0avloaDOoDZbEYiIFHNSLgZZWlei5rZzuksByTqPCSlR6RfmluSeU2YEqX/sFElXasHJNm7ktPSj9i00bVZrze0zXUzXHwb+c6+m/67tTm3RJncfscLh7/5st+viwN2ZdeVV1qbHMyNub57y4HX1d0w8jkZbFVjHkn60IPfOOyf/muwH80KtNiuwAHecVx5U9EcBkQXlOHXsIyFoITw7jdcxBW+BE5KZSEoYDdd3hWmkSobN1JQU2me6lbytELniOdcXnK+WqDX9RJw3bBexiJImmcSjNst5nUwgwLAJC2BLb8FuAIjgWFRyho8Q3Av9keCuh4yFVqJI4WJbCKIpbcIXZXgr0V3tgYX7i239uRuyEVdDH8FYmZQoOteXzVymRdsyFBoMmIGjKNgLO5PPTGRVtxafK8AEVU3QhoHOGG1NlLsLzbMaqpbK5jVTihBjEC7kshuTLl/31rsAYla1Ze6B+PcFZpHAi1gpgHJlGJEvC9i/dWitugMGGwxUJOugS3pI3NFyCQgExeJmUB4RwGdoA9TX6hBcJoqxkiYuQiAei3kPUbCTJSBxEttaQ2Jwh2+yZhK8yr2NZCsmDcnjzKfKM0jKYZbPWJGxptHsonBVvtWP2+t+WaK6/mXbn9m/wMv/+u6eFAAycutTd5ncvOetcMHXlV3w9pAUkxIzI532s1Wx01ILOaRJNlK49gjjx2cOPWdxiRND0jQccPt4yGfD2HIMRIKwjAmltNemC6q7gCMaSu0yxKQeBoLrvRhjg9hEjiAykBC/bE4UY9nSamt/03bm0Bbcl1VgudGxJtz1GRZsqtANBQYDylMsShWNbgNFNhmLtvFAmwwM25jS4nBzMjOlCzAZJpixowNrAJULKAZmqYNSkG53BQtlPIEhY1sa5YylZk//3/zi7i97pnuufHi/f/+y7RYODP/jxcvhnvPPmfvMwg8yPWG1WHAIUZGKfWk0UH4XJx4SBGJOuOxHiIY0vC71UWJqs1oHYXScmZGvEY5UXiwGgvH25vrJCaikNhDa3HwYQsgsJPQJLqTOWbdhBeKUJDxsk2tiGZvsdOo1GBDppYkG+lWYuPA/9Y+WpIRxdqtiK0Eb9xvS/7O0QaCSDh0KnufAAAgAElEQVRPXRthQFme0x6NV8L7pzRK1ECEjlqhj1jdQCOSOtjIudOkgXrGVgSSqE1YUZ+2J6PTUsYWVvMkhZG2NT0V+tQpKiakm9rB1+i6lA6jd7AEJDykiy4xUlvMN0d6DI2LfDdnf62cRcKRRZJk0BCRoEcRs+Ni9NIUkdD1u0PuB7KD8HcOQq+t+oTEwzO4vLWAbm8B556urmRCYu/kmScB4Fmy+scPfvgWuOfbProuHrj+C9/0FVme/3FVwR+MHjz1ynU/uCuQJKN2R23IWp1O6LU1r3o4sz0rB27r0k3l1oGf89AaMDHNVJFQW9E7V4+ZDTw5eHHeeAQDG9kQFERjFemWTOtNDEgITWU1ETROkhUkWo2ehyvwG1rJRw84esIaIZk6iSRi0AhqiXLC2eM2ItHPScRBP4ieOl63oawoRVeeI/YWZcE9nUtiUnY1sotGXutdkowwtdv8TmpV5wqAVoup01sMmnQbdN2NM9w5KkVJgyIp83pSuosD00gHsonTNVHTQhDkWT1BrYQ1E17o9PqExmDy02oidRCxkwW1QSMbkWRGuxih2qAqNnRr0VqS7qv1I1GziIK4GDYrkC+n7hIMcPaVTEZED45pLeb+2RAL2Iqnv1bqb6i/jJGJBeYVQ60+ce1RyESE+4y8U9RtNAJSbkMqi0zxpH1vmuXFgMRRhzTAxO9pAhI7HZHegACyO+LemB3M3+9gscfM9isDku7JMzMH0BLTMnnfuQLuefXagw5d74Xf/bl53nqv93Dv8Oypl14VIOmNc7ju5gJ68wLG0w4UrU6nXXV91upVISIpXN+P50f8k/4XvOtel0Yk2kZDM4IskETQoBROTdXl7KG9Z5LwPjEgocV6hgJZTgE2GonxfjGLTKML+kVW00bYJqcJAtFQKzUT70WsoKkl4e9cKbhztBKBUyKiGMlYwZ3es4jwm+gk4fOW3rL1JOE7G+gtiSyTdinyXFdFJZwthuCiEm3M5lIwsbUiikjKdJJuwkGdLnJJ2Ghe9Ql4qITBllY/Uo9E+PfC1jTWjeyqjbBxk1b1Yqu5GHCX6CWpH1HKKo0AjNAuGU5qTJOiPaS1bAbTKn0kBa1GfYS/AdMfltq6iD5iIgg5Jkn9tUbZfie9GO38a+trkvG1ZKCba0hSmomlMAYNfX5LQ63IQBkgwYhFWa4Iqg3z2lV74qiIvF6u2+GMg3D+7FnZN7h29ZjLiqFzbjQL80j8fApb7SlkYWb7uQV0b1nAuXsqOPNjm81sv+PeA73CbcuS9ot5Obnji4v9YIFrv+ANn94u2v/oPTw4PHvq2H4+XDs2aiQWSOajNuTtTqfd6vrM93y5GHjf6vusHPiPjk/5bPAp4vSJPY41Brs1btRaAI4MxLpLxbZ4xiuKEpeEaDYyGjksG3Mb+bBUgR6xtndhIEICI5Y3iMvOUFfL9mpKAVaDa7KZKBtMtQG6u+WIKWZjsdVsFNzJ0LLkVNOSalGJEfmJ3uNsKk1ttpRU+Oyq7K34fGsgY6LGvbQSAROh8iqUmCQykYgs1Ux0e8gyi8kWRDXssuTVKHDQrPUZ/JkGOksjEcrSIkbWzGYPEtZS3chyyi95JzbVtSayo1G0n6vRWiqOhwvg41bSWnWdZaminYwweUymr5dQQxTFrEz9VfCQSCRqBppSHY18pJeM+ExwIRqMJD1Eek2Fds0WW12MGGks1mBoGZi0bTovbYxYjGg2ehqBLWWJkb7Coq55TzEiMYCK92uBRLUdB/PsufA1DqodxwWJs8KNIZ9O4HJrCqWfE5CMF3DuQ5sDycn3/OsezD+mO2U83pnc+bKD+8ECB897/Y0HOt0nvPdPDc+evnE/H94dSPICetcGVGuFrC3Iyl47m/a8b2Mree/cAD62/QMVHPh36Bkr3UR0DW/hKK4bz3+9flu2TYr2WNq4lkQjHTXMcp2Jm6terwruqzK3JAVYtQBTNLgEJPikWXBnyydZX5FmwmM0CJfrTDQEpv4UHOy/V9STWG1m12mJco02SSAK/arvKBjFe4r6U0NUkmgrQnsxmLFeookDeKxEJkKTmX8r3aVbRhU3VvDJGSXrH/2b2AvY/EJyl0QHsZ61SfXVnlq5MGNm9rsyQ6bOgQDCZBWxJy2pwtG48cXWq9nV867TWqvH64o3bACFFR/6jpg+29waBcFqdddfpsP2n7HFxr2xhkQ0qhWpv/uqIVEt5QqKEU1UY1KdbZTI3DO9dAUPBWijiwkF6p/InpN/q8tg6HAeSWs0a4U6knwCk3IGxeEZbF9YwEPtBdzyUAX3vCrg6W6eUaN5L07e++9b4P5WV/zO8InJ3a+4aT9YgKtkcOvx0Fmyt7M978JHfma6nxOkx96RwUu+IIPrb8hgMi7g0OECqq02HJ51oGp32yEiCcOtwjySUJj42OhbqurgV5JJMZ59TQyO1FYUzOmBkfGLkQKdSSIbSW9tTgGOnnct0kiznlQEtkZXQEq0hhSo0JfUokEjXtN9SuotOSySfSXjYo1WQ3dT77lVn93OD6+x51bUIsT1vrr1JOG7m7K3RE6v01vheNG2EjrNzLq3vbr4HSeRVwOYwKrIJCZvaZqzLtj97DdFFSOokzWg/5if4NB0KRKRFF+kuaxgbkEhBYjde2tF3orOJxSUFdDD+eyMd5ppzsBgwMZGGCZyYfiw2UT0eb3v1NNmXkYBsCaaEzbTrPalrr+GQtMCvsARSWsvzr4Kn+fNycZY+MN66q/N8tKizGi85cXp84iaBL3S5chrOfVXIjC6MVkINuuM+0qjV4FmitL38OjoKLDQTq8/PU/uz+bPyX4QynKEdSQORrPZzgSywQTK2RT8NfOrASTtt/311+VZpkOtqu2df5juY8yurogDtx7/RwD49LlffNr07H/+8OZAEjoAh3XyoRwmDxVw6PoCqnEbrj3chrIkIAnRSAASD/3s8a2vXlSHvzXWkrDLWItI0E0QCsLWkrD3GWsiWP9IaCUruNvqdjEypm5FvV8GNfHmNQio6yQmcsJLjwkCq1OAjXFd1klqIBhBIkYklv6Jz4vfmSYsGMpmRYX7hvUkGi01VbkT9DXSW3TZogdx/Yocb1N0JSoxwjuWpYetFxMfEBjkUSITI/+22Vy1aESxw/58ndUuvoXQRLLf0ygETbUaP9PdF1N9WRcRfxS/tlaIuCSw76WlcG+tWAlvAEJoG6bfGmktRoV160fUZNYq2plGSzK2kuJMQpWk668UMWK0R0DYmPq7JLTba7b6CJuzlcWIQl0tp/5acdsk4Rm6iYsR7bvbtRjRgAVRcnhxGpE0AYmh/zSbq1X9ZX5jfhoyjyDi/Hw8CxMSJ/kE8sUMfDWH7eyKI5Lenfe9Bby/W3aCH09+bXLnl67dQl6BZHDr8f/LAXypL+GLhu87tXbu8PIW5FbyR2/J4OKsgIPXFLDYakM3b0Pue+2F7/ms6PlsMfBQ9PPHn/r8+eK679+rKDGJOJZSgOsRicncYqNWj0g4J0U1huT8Yuz0e9iwrUgBJsF6WXAPkQfn+FiRd1fBHbd8Mo8lBZL1K9zTSIZF5lo9CUqfWk+SFiTWs7csCMjzjfUg0duX4ySbzGgmdCsmbTlclRXIBUykzkNSdTkCUYE+rQNJWqjgbdOcGmGnKDBsoLf0AD3f8nJeyt6yABKcltDNV9kwTPFNNBGNRCRTRzx+cezrEUIDpWXFXHGXl7QRzSgTT125fQmbkvkjVufgQEi1ACy7x9r92DNrz/oR7mosWUmY9iv3JvUYu1W0k3Gn75VnZWktcuStx86SDVbIU9df69ELeNZ0pqXUXxsBSGRBn62n/pIUJ+GYAJ/VehigNBKT5AC6sJgUJtqN3KdGJBqxsDYDrut/O3uW+20IGVsLT9RWmY3BzSbQ6s/gfD6HwdMLeP/BEu5/qAJ4NXO+6zhH8ZjeyTM/BwCvVyAZjX50ctfLT+znLPhoDtx6+y8AuO/0lf/m4YOn47jF/ZyJnEsHr7onAwsk7kIriO1Qld12u6Bxu1U5gDzv5089+RmzybO4B75N3d2rKBGXkaYAE5VVSxdWD9hGJM21JOQuKIHOugx7y3TuWEvCPrcIunvPJYnXJYTPUp+uRsF9dbX5yswtqyNp25F6TUz6nOkVm+wtFNEtSPABVnSXYkFJ1ZVnZN7BCtGdvoyRjf5INBUrvHNIIs+PDb4WKvKpNJtLBHjsg6J7QkWQ+F3GAdXDIhzomrd0Fq9t/B2XuAuNxbUKsU5EohfRRFaASNKnKtIvDem+uDzpsuq9reKIX77s2FtL2S+i09IixMjGxV5Ve9BaCj7M/dgaDMk2SuskauI10VpR14mREploNPqJRsG7XO9JDKx01pXncvUzthRItMIe26M0AYnJEmuuajfFiCtqSBKQTIsRT2VH/f8NbjFyZT7Mitl4WnbHUC2msOhMYXhpAQNgIPnTEuAONoT7M9y9k2f+TwD4cvlU9eS5N05/9lU65Gqds+GjGbzo+FtcBndXHt46OntKWwmvc4L0GDvcKkQkVQEua0HJc9sz6HnXQnoLGzdeOv+cxfbhnwEoukweGiODHrNJATZFiWrMreYgnms9IkmoLbIISRdgqzkop04OTmL0EqFarNhuPbewey/7qEl7FQMk0bAaTcXet21hslRPIhoLnkX5PI6gRYvh56LiO3v+RphOsrfixMRIRbHQH0EAV3usG0FEsJrHrpXuNTCxAMHvijQRc1wNTBLB3mom/BGcXxJmsHM5SC1CIXtn6kb2WOgh1ECMVvAgaS7QWFRuIrEnm5osp8chqb+aNZVqKpRNVQMRCwDyewIRJpbYkC9pI9qDilHCVHgLR88Ui/bGYirNABRlmcUsIj1XbD4Y02HlonZtHW8q2mP9iGCjaBxcga4+v7nHPXtsSSRi7jdJw61HRkJxxQdNnkUKYuSAUJIB9diK4j5lbwmtSSBP/WVVQlpO/ZVokk+rmokUWjak/rqj8H3ZoDwLVUbTEdt+NJ3PJpAdmlzN6Yi9E2fOgoMXKZB89OGvmP7qa/9kP/afIpIX3v61kLv/4gF+bfjAqX1xY0tAAvdk8OJbMnjBdg5927ix3e20y7Rx42RyZPGE/2mf9Z5VAxIjSnMUIRXfSVEichkEDgouTUBijZzVSYzgbr1rjk4aem7x91jj3NxzK9zPsk5C361AQjwIO81E+6gYbsHSRhdJnYqJdkxlHj3LNDV4md5KCwcj/beqG3DUlHAv2BYmS6nAuCpqc0r4Zwp6NoqsCe8C4LuBycrIJIIJrU3VTvCGqT2M/Bf/plengUgakaD/jPQL/1y7pYgWwsYRQYWjEBXW5d9inMQz3wVEas0ALeDo3JGV2oiJONJoxABXzaCKTsLpBM3ZWvb6hejBe2norxXBD1ejrR/hq6DoLhrwWEUvVnsFRZUY/XV6bEkUZUVuRQY2+gZIGlJ/tT4kAj/TabIgpB1LpPJipwOOcBCN6E0yUMW/14X2UENyo/t6V1RPAdQ6/y7mU+h1pjBuLa5G59/eyTMXAOCo7IrxBz74r+B3//dH9g0kvRce/9w8h/d68O8ePnD6i/dzgtqxDuD3M3jxxQxe8Gk5DKGAgWnc2Cq71cz1fQv6UFaDrMj7i48O3+rdgRei8WtKAdb01ji7nQyZGHOZ3S7EUVMX4FgFn0Yklsu3lA+DV2yVonQXme4Y/SSpynXB3Xryer2ymlZVuC8DoTQhDGUJlafutbs1cKRC3eUkA4qOyI7unb0llJ4a22TYFbtgpm18PSoRgGyoK0mEd3mWG4BJApZ8nZVScxRA6ZwlinwwgpA4kZeMgEvt5yQHM3WOf1oNhF6BuqDSW35PEMGHn2ZXxcmKbGaSRoBskNHk7FY3IuBRa0GyRGulnjXd3l60Vn3+iEQMBBA0f0R+ZiMEEtDD/1X4LaF7stRYGF1Hh0/VwG1JaGdgUVrNFCIqONEzbNZUloV2zayKulHNuFPtRy0RoFbjY/SRK0395QgMnL+c/Sv/Glf5ocs5Y6ty46RhY/eZBZwvbQv5XQS/FVa9Xow4n1WTt/4H7e2zLhYQtfW819/oOt0nwPt/3jl7+t+s++GG42JRorZJudCCbpvapMynvSprYwowVreHdimP7Hxr5Q9y+2KhXYSyYj/xqs4lWdEFGA2DZBUtAUmqkyxFL82C++oKdxOVsGCgWUm2Wn+XrrxLDRzJsDE1WB+jG5+j0FMRSEz21tL3NRUnRhCLs9wNsMboiZ+oTQFO0oHp90bLWtZLbNW7aCsShYWPs7YoHdjk3+LwqVbCIKOgIp/lFWxZLu6SkpSO4GE1+kpsvvwcs7LCf9LN10YhaNsi9WG0jpgiauicxCjWNAmZDhinIPLRFBkwBaboszLlNzrkRlcx3rJGKJIKW78HMfq7TUSkZ9BcP1KjtZi4Syg8pouIBuLoRYGIkKtZH2nusUUAY6M1erbMYzPCNvXYqk9GDJ+Rdjmi7+j7jum9ePo1MrYSepPPU/gHs5vcDzvvkdYK/z9zMIpV7Venz1b7jnufnxcujlgfji6M3/7ya/eLAUrahloS8JAPzx4aANyx2O+J+PhadTsXJXJ1O7RbMQW4dAOfQz975JkvWVRH37D+XBKmgxRcjCFEzUDZIqaM6kV62isL9tVzS1tspDSaUFUbV7gLvbXvehKpl9mN3kIXXEIKyR7bNXsL74Prcwh+TKbVJlqJajGx0wBBttVABMRNRpamXNvsLRXqY08umSyCz68WjaAQLy20NBssLu0EWFaseI061DbHAxMay4BNTEGNKb4S0hjPN07XEwpnqaW8BQkmXGyFe71uRIGEKRSZl1I/LoIA4yEaRipz0AgjCs27tI3H+D/tIaUhj1A4yzPaLejZrCXkC9apH9HnsnlFOwHK/ntsCdimnQbW7vrLVy6aTBo5mcimA3+cXe/f5ULqr61qn04nsGhNtRjxaHsBFzcvRmyfuPeVuXP3yKLepIYk2RkHjh3/n+Dg02YL9xmz9//UP20IJABQK0rsQguOhur2WlFiKEx0bpCfO//8+fg6HjpvaR07lwQtGonfbHiZZEwzt0ykcGU9t2Iaa11wj7M8xBBK9GS98pgptXk9Cd2znEnoLSnETCcmimdvjC5rL6b3VpqGXBt2Re87SSgQKisV3QlcahSZjQzi7yJYxHY2sfK8Lqg3gYl570sCvFxCA3jgq6kDB4MK3medAahpJWxdl/cAjUbUBgJ6nBQZNkUhss1sZMFePv4q6gAyd5G+Nz0+6Sys0YhkhDVFI0mmlgGkVNuI3y+9vfi7k1nx9etJgQj1g5iRpJ69tAkJtFZ6P0JrbVA/YvSRxtbxUWhfMRXRUG+xO3DMFmvSR2pC+149tnjnKmVItF98V7t3/eVX1at+PrsB/hRKMMWIiwlk+QTK3hR8flWKEbsnz/yoA9DZ7NVk8q7pyS/ddxd4VRQPHDv+h+Dgq0qAV44fOPUHmwOJKUqErRzaWQty14JD8w6UnS7WkgQQKagwMdu5dGN56cBPX1kXYLKCeDNWU6nRJo1jd41nHMGJDDg/HLYy7JknNJtJ0bUzVfg6KBtqj3oSk7Ir3j8uO/z+GpBEh7x5PgkZeY1ASOIxlfSNEUUU++l6hRYTzaKWCpx0/qULJdCupwzL82KEktYlWteh36uIKUcaQ6/gFxta6u1xxCn/toDCAxGXIhS7qvltL9FaMogkNgOmYsLks2zrRTSpA4itL1gywsSvrw0igipmMiK3tGelOtZXGO0gtkORL1qljdDv0Q3SbC2pqmyitRKjGLOTgrG0beNNtpYASkzbjRlP9PZMYWbSqFE0Dc1sEOqOtrrUj5Chp99pllfaE0zITX7uCmz6c8btenaazGCPn6d6lkiH0RlF+YypzELHidDOkZdtKtnYY4uv8Kj7nuxA+UHAivb5yLnWaLaYT7QYsXN4Buc+WMJDtyyohmSz9ijdk/f9rgP/n2R1+8vbPzj5iS9nx359FIhA8qLveStk/kcr8D82euD029Y/Rf3IXWpJsrzTziqqbg86iSsH2cIfXDwyCc0bb95X5tYmgrtqABtVuKtOgmu4SXBPQIGsfmzgmNaT0EpU2ojW6a71JHyAEHZrZ2/VPhcDKUkgEKqL90ZTFLSOVoLfY4C8lg5s0o0pUlmhl+BxCSjsAiZGNyHLwvvdRhxWU+Fr1CXbFInU17PFEDVo6reyp80fEtFaefj4F66hSHto1bO7JAOonuobTtNQM7Kkc8SUMlM3QkiW1H0wuNjq8rRYj+s6YvPB9Bzxemredkw+YMOeVLMreAoFV6O18H5ikSCR1CtmtFt9RBo1chRHC9mch++df87IbvSRvYR2C9DSWp6fKi47FaZMxpaJGiliq2VspdfEPrAmG/jsJvha5/wlyING0hplzo2m88WkuYbkxdL1d50FnSzw7sl73+/APV9+WH78kf80e9drfn+/9j8CSUwB/r3hA6e+dr8nisfXakmuP5zDdKuNtSR50WnnVc/DvO8L1wco+lnlBtXDl99SuoOfg+e4qj23+DVzquhyhbttqVKvJ4lGKqXJhGIzVBaDArNJYuolklljhjvdOd+/CtD0ctjyC/DgXJJ1s7dkEqIZ22ubSCq9JZFFrHTfn1Zi0oEtwNaFd7wdARgddWAjC6kjYkASQJDIj55H2uRRHpIJHGUhJYvYYEzoL6hbbg2lHZ1w9FyioUzOLRGI/BCpJjZYmqUVDQ7703RMMs9Cggz2mNn7RxCpGcclo0xH4BNSI2q1EQEtY6xl7giF87tXsuPZTXGd9tay9xkBQrO1sJ1jU7bWLrRWEllYIIkpurgypFeWePm2fkQTGsyMdvsZfqIxsmBgibeDT6SSLCoBCyygskI7PXeb1XXFPbYyeCJ7jv+uoI8AVrTDaN5pjyBEJNV8CpP+DMpsfsWpv3f4rJvfN3YO2mR6PUz+4YPXwR++4Zn92n8FEtNO/gPDs6desN8TxePDgg21JOulAPsi72ePbL1qUR75OjrHqswt+iXTPeisxKjATEtkwT2JbrQuJJ2DroWJKb2lANBIb/GxtGMZTFgzICBhMV8969UTE3XYlICFvE3GsFSf4S+MVRBr01ua9ptAXBTRm1OB65X1tahE718uqF6kSO9Soy6NpARMtCeXHFgrQqxrJg1golSfoEK8Fl5K/D5WZUWu48DVWC1d6Cb6UKOutlyFak79sJ66HtQIIiaDp1kXYcAwdR8x2gi/q1exG0rLUkAmGjEz2NWTjxX2bFlrXvletSPhStbr9ruqmp0tQS1CkUYly7QWm45kxr1cu0QN+9NHeIlvWNEuiwJTpNkcmeiFW8HYRpixxxa8J7up+ondU3+Xakj2nfrbvuPeT88LF/os0nYZT8eTO7+kv4ntN7vkJcXg2GcNw0mububWzQXkJgW4rA24qtwgf+r8rfPpdXcs99yi7B4R2RPNgN8PkVT7HbvLoJRUuKtgzZy/qaqv1ZOwJUhnwWuPLNN3izUJM58kEbwJcprmk5j7FnBSG2m7AQc2LPhHIrIrAlFXYQYojmyieJ5QfALc6tHTnBJtlJnUd5jZ51bj4NoUvB1ezxr52M9H8562ULE/F+5N8TylqzSWoB9zyYyW1ciekACPStI13tNsz2XBfZ3tswo8DIAYUFEtxDBWFDXUPVrFmVokYgv2jE4QWZtEM0AQ0fRYca1thbsY1qa6EYw49ELWqWTXbK2VvbW4xbvwfyalmKK7RINZ7qUlRUACek31I3vRWkSXmedihH+hpeKjkkJBnpoo9SMSGW5a0b6L0C6Og22N0oNfddeUf+SybIgDrarFeOY6I/A7PNCqnvp7XwVwx/6B5MR9X5M7H/XwnZ37x3d/2WevsxPqxyTu1uDY7Q84547N5tXzZh94pyLVPk+8OgW4c6gN1aLbhlnfg+t7oAFX2c7OjYuL/dPAY3eXqSTbKoU904YKd61EZyMWzxNnk+/SUh6951Rw31c9CX++3sCR/BqeuU7et4lkltulcIzJQvsqeksNZhOQCA3Gjga5Q3tVumtaNEf7VtORSC6JSsy9NEQl/Fsy6A16iRmVrOAT6T36tPBPCh4mPZiPkGPMdEmLGvEcBqsirbWPlZ3sFPmHpXUUTAjeVDyxEUE4phFEkghm10jE6iI2m6gJRBRw6hoJUm90E0mVNVFTS2DUoBFQESIbyGQ2u1Joq3trceZVrcgvgqgK5nVai654Fa1FgMFIrndXz5CLD5A9FG3MsjyjvV4/wpoNPzdegkmWmmpGyVREAZK9Ktr54o/C97mD8AGMSICbNWbDCUzdVU397d553w8570/KLqim03dOT3zJ7fvYFXpoCiS3Hv9NB/DaK8/cuiODV/2YW9lOXjK38nLgfdHPMzdYfGznLp8d+BQ0ehtXuIsxJCOUnqe5niTQY/G4NWa4KxBIllikt7AGVs5ntA1cfraFidI84TJl3Kt44hFI0A9ayt6KRnmtWe57zinhZyXGGiPA+kx3A24McCIacCqw8Hy1LK4aGBGmGvrPdByQSGYlmHCdSDxOoUrxktx90ZgUa83GqAGLoBH3C6Y0VrKx8meyq3S7iJnixxCBJQqvUbGIgvwqELHAZIrvGosO2VDGP/jDezZmJPBg757qRggMFBSauvzi98S2L4GKEabGpLRa6o6LEEN8I63jBWQteJlIKcm6ku64dU0ojay0fsToIwwkpvAzAih5RzFb7grrR/iGDJhqRbuQb7VCRAva2qQyUm2SHQbOT1s3uddWWXmZMrZM+/id+RQ6xVWbQ9I9ee/vOnCasVWdP/8903e+8tSVA8mLbv9+l7m3g/d37Zw9/UObnJA39XIXYGknb7sAS+ZW5QblozvfUvmDXypGIUYXK6Yl0otp1kkM/REnG5Jlr880V53EeOxRiq3Xk7AlZAc8ir7Rm1ftRJwjjo5W0VvkuppUWdR4JKpZp7bpVuIAACAASURBVPcWGWelt+TzdKkqHtDlsGaRaiUKAvVqd9WZJMsqPteU4opfw2c2KcEJFSUUXB1M8K1HWmwJTMTgy3HhzySSt5QhuXUmnIkRyEpNpOkXzeKICUJordroQwymgEjMouJDzTmFZqqD0wo6S4HDpg7vlaVVrzORQITO0ayNrGqHEj+rnnxjyi+6TUbwF2Oe1o7Q5uXrrxUhbpat1VDNLhnBKpRLNNIwEXGv+hGNolYUIvK9JJQg3eNqfcToYRrd5f5D2c3uh0M0ohlbfjGelo66/o76M5jb9vFXkrF15l8cwC1i56uPfPQ/TH/jdf/PJnY/2Sz9Y8dfnjn4M+/9u4dnr6TnVkPm1rmtNgxM5hZPSwxdgLMwv/3Jy//bYnHku/eucE8LE5M6Bm4eSLtEqBGuizD0SGM9ifG06/UkS4aJq9yXgYSs9/6zt0wqbDSiaQV6opUQ1cTdPDwy4xq5GCMdwq14al7Tgb4TUFEBmz11AS4CIdoDTUWKNkIR454K3grGMsNdrXkTmIgAL12D8YmbyMJEa6vpLn3r4ozYDWEck6iZcMiXRCD1iGRFZGJ6NClqSM7UcgTSUKiowCC4F05j26us0kSUlWqKRGipWkqLvoe1FIlAsPiQ60Zsym1T3Yhcn62f4HqNRBuJNFnzJEQBEhtxSEosX5+myNbTfvfO1pJ7TtKFl+aP1GitpAV8re7Edh3Gy1xVP8LWQaOMWD9ClfNKazHdabPV+EUZfQQ68EfZs/xvIJBws0bXysbTq52xddffXN+rqqdlj3hf+cnf3n8Q/vJ7USff73+p1/X8Nz1rUGRPOHA7O2dPHdrvyczxq5s3tgftjhv1qgVQz60sG/gKBsWlZz5ptnPNOwBCD25b4S7Cs9VJYoU7vx32hBsaOGoWVcwCatZJxDGv0VsWnCJvry0+NAJh6IpAsk72FhvIJnrLahoCEiqSJwI21atYXSSm+Cb9t3bRSsgIJ9XuBIpCYRH4JMK7AesETJQ+ipGd1Jfw12hygI1MLJiY74oApE9Ygw285FohokURjTOaI5EYtey+0lPQkGPrwYVEB/J7O/0w+QzTYmychHFdBSIKOGtGIoluonV3SmmRIG+KD9lALgnfEZDs9a4uQFTxXMDIRly7VLI30lq13lp6jPTWssZbPH77veghkGAehX4Vq2ItjwC8rf+gL0vnjwhIptRkY/2I9gXbreOvFCfWgCTMaD7of9wdLt/jqnzoWvORm/vRrIQxuIzG6+70Z3AVmjV2Ttz7ZZlzsVX8zvDJ8d2vePamNn8pfNdWKeA+c/bAT31owxPXBPebC+jNC5hnbcjzDrQXpudW0EncIC/nhxeP+3d4172Bv1PHzpK+YLUIEdxZDFfevWGGu9Us9qonYeMdIxq1r0yLqQCcDr+yvP962VvWCDNUrZjlrvlTCJLWmKrHvrlWIgBgQCOp3JdsrKaKd45qkvb1ypItg8mukQlfB15GPcuL/62RSEN0kjyXpeQVVaTS7C1cT1aYb1jq8vvaNok/rv1CDM1SBEKWT2kxMXTh6xsr1vl4Ob0FkXju5noRvI3E+McIpVbBnoCIFB8qcu1SN6KUGV9gLKDE8SyojURjTloKUUL01E1b+eAz7j2bXZ8fphQjcen5c/RQEw3E3H9MYxaeq140SNdOiyTSeslERKMrxep8o49YWgtPQ5qSFiLa0boR4FSzcXnbtftHYbJzDoob4JurTvUUiuwVZ2wVbgzTfAKhfXzp53D53AK6tyzg3NMVnHmJFCPuy1R3T9x30jmv8oUfjX9jctfLXrevk5iDl4BkcOz4bzoHr62q6ltGD77z1zY8cQokxQ05HFoUSG21s1Cc2G0vJkmrlDyrBuXHR2+q3MHPE6dylU4S+13topOot2qimxX1JOHQMKOInXL2zI23HKMSdm2j1rAWvRWjlYYZJQSKKEvG6Im+Z89Kd62LUW1iKRWYMEJ5p6iVmMaJ0TaviErYX7XZU6v0EsEkiToYCFXTsNFSEpk0gInidg1M9OeR5zLrtFZs2LiCV4DLCiyhS4tGMzlMvVQ+xm4pRQ5NkmLwYtNjO9qaqvmEnmqKRGzRIUY2BjisLhLnndhjYq8n4cCMXpGcKwWk9bSRSB+JbY5diZtSflXIiE0ik2p2Q2tp9pgR3rVDcE2cT6MRBlcDOhbYEyBJ2sbHz0khYlL8qL9mH0+dBYpqyOGI3YBZZ9HoL8uh3Tvi2r1Dbj4d+cno6Udbz/W3VYHWCiJ7ABPnR7OqO4ad7asstJ/5SwegI0Oq88/cPn3nf3znhva+Ho4D9F90/DuyDH4RAH5p54FT37npiXHjhbG72Ff7OXkyv10F9zmmAYNzg6yqBv6J7ZcuFkde3zTDXSmsROgWIEmNUMzckfRd0QKM0dZhTM3tUiJlZiMh+R6hpOjPSG/ts/eWGl26huZUYK4b0d5f8t38YVOgmGglBkjN9ERjEY3Ab2g5oY2s8E7zOjixMV6HqUtRUMLz01MSdKLIhSYqSsQRkSCly2pgQhvRfs6CLfsbNkKJXx8jWFnB+06zb1j6rErFFF7t7ZQeLLQOPw2qn4hgZFvB4/KyvaQiLqQAEffqUiSC9kzOT3UTUSuhn9ssLdVwZCqf8cSNxmKiDYlkmPNfpY045ygSaYhGGBw5tBfg4+/g4WBa72EA1tBaa/bWMvdei1R27fYbtaRlWqsh7ZcBzFBoCk2xWDMCcX0iYt4ZuPbgWpdlOYLOePtpv8jGf5pdu/g154LQHqYitkZZk9AOV6PH1pktB6DyxeLDH/7s+W9+2/2b2vvliOT5b3qha+UPeg8PDs+eOrbpiRVIHrolg1tmBYRWKSi4T9uQH+7QtEQGkiC450XfXbr43Nnlwz8JkLVTnUTqO3arJxGDT+oyuwg1T3y1TsJ+XTK86apmb7FJxIjBGP9ocAN87iK6kwlNKL6aEcZ75fG+4nGbWowYldCztUAUwVK0kgRIWcNJhfeaXoL3J4/bgsluNSZi+E3EQZbGXLf8TsDJtE1J6S6LIisoK1k/9VVt26TI75IIIernKyMT3UomOiCbptGMAoZ42fjG5Avrn7P/VoNLPbTkvE2UV6SZIrjQd+xewc5olAj1DQJ7uJ/muhEcXsUPKp29wqZ9SYdJGjTSQcu9tfickkq8RGtp0aC8ACnSNOK2XNde2Vp0DQmtxVFEvS3Ksj4ioFGjtfjemToDV7Rcq380K9p9akrDiaE7Fx8GdwhOuCPV36M+Eho1Qms0q+ZjmGVEa+WzGZTXUGuUpx+p4P5v36jHVvvEfZ+RO6+yhZ9Mx5OTm1W0p4s32Vd3ZAeOXb7kne8Py/wwvO8dG6n4tIO8gxf/cg6f99IMLo0KyKsWdEc45ArKMJsk9N0KXYDLgc/cIF8sDi4enb3NZ4NPRmO3Vz0JaRroANiJiUp9YSosL186IbggamY5TVEIun6o5g0bPDC7DfMpNLopSx86XPmqqly1CH968GUFi7l3VVkl9RHkJO+RvUV7m2whrSY17vpDobdqQrj5pG1B0qyVCGUXs6XCfUqEkcwrYWyJYLLcrkbAJPbiMkkFK8FEANBEJslQKsV7W4S4AlCEXbSAYjAE14PVkmRxK8jVUARBVEKHhj/roGP/vQo8dgEQNecCIEZP0ahC6DKOLPgrGyMRQ5ckjRnVgNHgeNwl0jtQ247Us7Tkuq0nHQ629RLLFBIa3yvURugWQxM0E12ZQkgaYMXXt1ZvrRrFxwJVEhGllfVazR4LGxXEat1+k+dRG2RFtTq8rdkZCAF5Bq3e4azoHAy/p7thx2IxG/nJ8Py8dRO8rgTYwhkkIEDixpDNJlC1p3AR5ldDaO++7d5vcpn7dd0ZO8P3TO5+xb/fbaXv9buliCR8YHDr7X/lwL10UcFLJw+eunevk6z4/d4V7pwCjECSF/3cV4Pq0eE3lGtMTOQlRYYY60nYMGOHnwJc0YYsKxzkucuyAlz4e1YYrjt8IMwwbDYwiCm0+5Q74Uosgkhe1Lhkqgp8tSjdfF5BNa9gPi99OS/dfFrBYhai/SRCSDoC1zoSk1YirrZ69iqsx/5bSe8pMyiKPPdd60rI2PKeqkdI+vWpXkIg05ASbMcYS92NiUz06dUjk3DCejuViGQMrikKaDGiTQ22lJWJZOyp4gKtvexV4NIIFs0/jB48/95EILhIrQ6CxnL5PHqOxFiqVY/9s+RHiW6i1pVtpRX1KTBPWpcbXcTqBFGXSSgtWg1yT2mqsLQ5iT21dFPwNdmamAS0+JsZ2Rgv99/pVzSXeu0LbV26Gkl95lpZC7wqfPMFcLouz2fXiDC2/adzUj6KPiYmP+LI4trzgqzdy4r+Eecc0VikSGXakWayfd4v/PjB1rP9ycr7IRYihqmI1Xw8a4XxuvkEJuXsag2z6p6471ec89+im2tneMfk7lfoTJJN7H0jkPRfdPtbs8yFlvInRw+c/pFNTkyfMRXu9dkk0Oq0577ns1YvAAnkeT/oJPDUM581n1/3AxHSa8V+hvuXNN6s1QaXtyHLWy5kQLgsJ+dLn1T4K9Va0Doy9kmMk41GcN8QQvFqWrY4cfPz/pVzRiEQU9F96d18tvDzSQnzyQKm47lbTCutdE97R2FRnhZRakSGkZeCEUcutMc5+llZV6JHiSefCu/8SCKgWhEdPxuvhx5LCiZLXYI5ujKPn687hl64v+ttT9LnIC/A9tAy70AGZdUpMH0H5tg6dtR7b+1jdeOq4sr35GNN4CFGP5rxPWkskUHU8BPwLLWEZ3sthhxtJtlCQ4dRphSu4sY5I7tkaakuIR4Qf8HSvBH6vUxADHE9ty9hh42qu8nxSirTlaqL80Mk5Vdvzmw/rpCXEyF7tFsFPEcMVpzndi5sAIT+2j1bawWtRcs3rcyP44Dj/BHX6kDRPZRneTsmV2AkwuGVC+5eBaOtJ7zrVr/lrnd/6NxiBIHaAhhlrj2azsoJlIsp5IsZXD48g6uhj5w487Bz8FxZwuXHH3nl7F2vuYIZVIb5tfuif+yNL89c8Wfg/Xt3zp7mLKp9bLhowdMKd9VJpDBxQkAS6kmqEnUSP9m+rny685Me2odTnUQ84uAfFD5rdV1edMEVBYfeZDEjRYSeMttaLsKLRqAGMrhmVxsfnGxkDVJ02ozCxs3hJJo1fYjUQODm9hBosvlkDtPRAiY7MzcdL9jwKjCY7xNDbAr0uAtyjGbI8Jo0ZO7tpYWGUuiZCu+RlorZZ4Zuk7BAh1cJ86S0XRTD7XjeNcEkivASmaBZivRWUrdiQULehU5ebKDB7Hrd7d3ud12L7yVaBX/e6h+ElNFYxq+IjtsaUQiuaK7PUO1B8UIosdUgQp+P6CQtQkxKbA18IqVFgrEYdWSdMFVMf8Tn3bXDrxri1OjGIVQGZJJMLb0s/D6dy66wRNfFSt8ekxAF0HWDx4htk2wtS/MtVbMzcGY5ZJ0DWd7pZ04ac4RoBx9faE3DTftdDvPJtp+NLzl3fXa768O/uAqoLUqY0d7KxtQ6vjOFSTWD4aUFnIMFbB8s4f7NKto7J+771Mz5f5YlGSj6yX/bvBBRd2XjNnre6w8MOt2LYeUMtxfXwEd+5vJ+txsdHxZ7Q0t5o5O0YNaHrOiF5o1hYmJeVYPq4eGby+zQrXQKDCx9luM4E8iKDriMknVxrWNEEUV4MqasncjkPnGGjeZiGkOK85y6rlp/wnDG6zEN4eQydLHyPkO3Q0JYlhXUe4tZNbJPA7BMd2YwGc7c6PLUVSXfgPJCnAosWgmVrHNMzdfd2IPLePaiUxAg8/uRlxS7EGvcg7/i/6HLkWfGAiF3CWamDw+tFx7ulc1Fp6fIchWY8CKgxZDEmcmaTHpw2UhFJJDdsrYs0Niz1sBCdw2qUSbbSuwr+xsxCyvdZ+TXmAwrq4XY2hPp4ivriqkXjTwS/n+NSITcYPEbDbiYCCYFHI40TGW2BRESrcP/RW0kqZMRb2rPuhF6QE3aCN0jrnIR5ZNKdOkRZho7atPGGq2lJERMJY7ZVvH8+8vWoi2uYIuPOHdZu5/l7QNOp2ribXC4GCIQCUhQSskwW6vy82daz4HXlzhWN+gjDCRV0EeKCUwvz1YUIrKxW986d06c+a7Mwc8rkOwMPzy5+xWftv4Zmo9spLbCoYNbj9/nAD6/WvivGr3/9B9v+EXr6yQywz38+eSlL1zMDn9HeP95qwut9gBcnpMx1d4nAhZqK8kjJyDRCIKafsTnbUca1dtwpGK7zfDB1y87jSyTGAXc69iGxWaq4O8zKsLC4yvZspIKShQbFS1xsZbqibPxHEbbs2x0eQLzcZgAReu1sa4kElwxKmGrS21UrIBtoprdsrjk86vBRMCI4dFoTTUwSepGVPPh5ZQAGqcI7xtQ9CJ1jS6Bim6bdBmr67ALyCyBgt0yBmjwx7VMLxvxL0UgDBJicvXKLJUlQMILjjwHXnzGwNIatHSSMXKprpFEKKqLyGdNlpbVRRooLTLytk5F1j8XHxotwvSf2lAb0WdFTyvSWrs1aLQPODX4DE70+qWRJW4v5bJpjy8PsWqsZg95O+1elncGQfhA86NLS9hGvHMuPqVMH6jK0k92ngZo+79oPdv/SlXlXD/C+gj215pPYdGqFSLeU8GZ8Pj33zq+d+LMH4CDr9EdMR6fnNz5siuQL+hMK4Gkf+y2H8pcdrIC+NnRA6e+e0MgWa2TdPM2hHqSPOgkoV2K60MeJibCwG1dfPbs0sGfAMh77d4RyIqQDcyRRxC2kQKVdNmgNghQEL1DtYVEkwj1bgBEqKKaR8+HR2sk7ETidNjnYOkws154OaozFnso4b4jA4AJpwwq2FGVeGTmbjHThkiN2XThRlsTt3NhAuW8lLnuNkIgxUGCjKZ5JQ3RiGou3FVX60QEhJlmSupBjLbBc2Io3ML/pdeCO23tyCRGTGIh6uNyl7QTtCQxelxOlqhFltQnllxBhWSmwgSD6gfUtwUDhj0Mr7cOHOGA4DJIhGI1FTGwZts1aiF2WzaJ6pb2Md/D1eMc8MRIwNSINIOIsQMuT7sBx/uQL2KyDCMF6e4bL1jBLGRDavGh1Tr4PE11I3IdiZZCYIXayD4q2W0Uw3YOF4WmJ0t7ePbypCeW7c2F56jNZre9sxhEXbubZZ1BFp6GqIdqIxSWKCKkrycwCTt+Pt3x8+m2c0f8j7mBf59zGTVqrNw4czCaBpH9KusjvRNnLoKDI3KN1cc//uXTd33jn25u3/cAkt6Lbv+cPHN/573/x+HZ08/b/ItqM9yDTnKpbEHftcHPu1hPMpv3fafoQekGPqsGOeT96uPb31u6gy8q2gPIWx3akcS0KHAgOCB2MFvq2YjGKnWyFFx7p2ZEjldvnayRmg+0hpLRJTQJWRGMH+h3YTVEo8VGRqIKmW3AQW1UG5GnC98lQqREJCQ24lkRTzDvinYVrkEHMBvO3OWLEze6OIZAf2kPLrbC/HzSeg4KQnateOcUarpII+wr6WcoLjLBglpKk6mmk4joSTRYz5CLqc90+eac4lCbSKERUEyNSUp7qcO1+7rVrLHUpRLQST68FG3Ib5udsV0jkJTGwrtXLURXosSw6fdYAVm/I4LUPjO0aiAghpMNNxtTNRW2n5atGcGz2IhIvPndtZHw0PfO1OJLbEr5rc1lN5la+qHoMVhaS3zEmO21v95aDhBA2r08ZIOyEUrXAbdF4TxfjnwERLCFvwu0lofqUus5/vWl90PnpH4ERrMKqH6kE0brSv1IfwFPb1Wb6iOtt7373xZZ8T90c0yns8k/bfXhnlfr3OtN7fzKiCTc+eDW4087gOuq0ezm0f/82cc3+xL05mr1JHFiIpRVt40RCfS9d+H/B3kOff/Y5S9aLA5/axCn273D/NVEWzGmYO1IyHoQL53dMOOd8/Ho0UiRomgJyEhpdGJ9Vf0yWZmB2qwIOIjlDP+FNoms5tOGS6kvDJkoh5+sFB8jfXfwePaIsNcQeS0UlEi4zS2riVvlqdoBiSrvhpfG7vKFEcyG85ReqveqCrhlugPT5fAERaOXNM4tYYCKdl5pstjdF8GHc9wkG5uiRIpMVtaZMMjTH/EFy99FO5Ff2VTh5DN8gAUVxqUkAtHVm0Ys+1vUK0DDah9qVeOZJYcwiUDCewjwXqNEl+iwep0J00kJ25pmZ1HdhzGSVnBXOkoXpiSJEBTsQWlRxLNrBTt7ARR9azuWcOKmnloWhBSMVmsjQu3FhAELVqsq2fleo8xjsrUaWqLodfMcFv5ceKZZq5u57iCjm2HzAVxGFgUw2mW0lxlkic5Cm+CcKxezILIDdOAvW9f7Xykx5XcxcnkxdNPFeBb6a/n59GrWj/RO3PcWcP5u3WzD8V9M3v6yl+1vCzQfvRuQhHqS/+LAfa0v4RuH7zv1f2z4halO8twbcrh4sQVHj7Ygm3XAtTrtMOgq1JRkbhAortzBwF3aumm2dfDtgd4KIntetBkvxDtm+kSqwREzQiBsGjpSJBIzrtDOIfDoszQPgOgytWpE7dDvCTMEeBgcGEgMHaoPSNgNgQphBkJIz5XBAgxRM6EPZbJ4MQcfFx96mVSPgJoKbR0Cl2w+nsPl88Ns++I4FhdaMNH06RiV2OQEAolovXlz1Oe20GNYLzIRUoweRx3YlmpNGgDF8lX1IkaLOfLs69hQAxUTQG24hg0oyF/t1rG0Ve33SaQRfidV5qKvyHnYqUhxKFJKGtou6yEkGQgnWNNEIrHEjgrZOA3Aaf3hD1aDCJlF3GJGUxCySJ0gNp96Lo0inAbg0ntq02hEi/1q0YhGHjZiQy9GnDgFZN7U/AxW1I5o1hruPQeu6GWu08sDhSVEBjqxPGhByY3wnNhJxPcSfEneuwokmXPT4SVflVOXH4W3+gPVgy7Lh7CAkWvJIKtuYB2mMLk0g+I5M9i+sICj7QVcfKiCez7kN9FHuifvfbcD94WyQqsLl753euqr3nHFe8KyOU0nGxy77Zucy37de/jt4dlTr9n8C2v1JAevKcBdaEHe7kA277RDS/mQBpz5HgQwqcpBnhX96mPbbyndgeeHNVO0+iF9jrJ7xKD5ElUQNYWh5kE8YJPRpT+T7CCpNmQTpsCgWov05CJDmCk4ibAd4wx2DFNqzOxT2uGSyS92Qb0UdlxU8JMqe8Iw9GDShUh6CoMLE22UPlNVbvvCyG0/PXTzWaloqc+KmjwQJyegIFWXJkJBqNM6zxVtTyKPlEYmcv56ZBJRKDJYqdBuaUezzkyaFoGF2kstZpS6kFWgotsmshx2IROtF+tD5N8iqui/FcAMgjRpJLKrLH3Fn9UIJNrxZaOOzyoK6mqcZc3I7xmQcIRUzAj07GmgoV4rEqHQJYJIwDpM0TBaT+zaGwV2m6XFQJpMXDS/FxqMGWgCg9Wt4sPvd9VGTLS1W7v4CC4q9nBkz2htNA+jgjFoZihiuvYgy1rdnKoHQ6AtdCtR6ky38zZgTpR0ENY7w9/CuwoyCkUk4XPT4fmwmC+3bqpeX+bZjswfCRlb8wLGMM8nNMhqPoP5Yg4DWMD7Q9rvQxXAq8Lj2V9k/eP/7WB3tjjvHLTFYFb//JHnzX7r2zYdqZ7Awa4RSf/WN9zkfOtRB7C1c/bw9QB3LDYDEzPo6gXbOfShgEtFC/qtdgCSjm93qwx6mgbs835IA/ZPbn3xYn74m8NDC+m/WVZwRFGxvm7mj4RXmmQ1mZRgrbEg+Z0sEi2B+mwSszL4GDFgcnzyBKT1UbIPiR3wWrlKURICQqDjyDvDzcT0lijtJgzGyJk9GQET7OHiQnuXsIooRMa2GeJVSrCyc3GcbT21DSH7y0RfUrQYQaZBhCcDaupmapXvEROWaS49nSTPS2wia36T6MSAED56+tqY6FDPuLLZdnz8novW9tqqNWbc87PiHNQjDPmgTeVdASBqsy34qB1ngyRbtUkP4fM2tj4Ro6nfzV6QjUR4R8gfSTuSCGr7yNLiOEhoJ752zbaqFx9qUIQHrqobiZs2ClAKSkwdM4eMN8s7V4V/be1uxPhALSbFheHUWeFcZ5Bn7Q5utiC9ksEhJzYm95ggnZwRjnZC2yVJrAm7NCQfhB+EpK7MLaZDv5iNQrbWu1s3uneVZTlyWWjSaNJ+A4jo/JHW4or7a73tr78uz7Lf0eU8Gp0b3/VyGdmx5yrf64BdgSR8eHDr8Q86gOd58F88fOD0u/c64YrfU9+tl5zJoDfO4bq8gN61BcxHbegcakPF80kCveWhj323qmrgdrafPbtA9Fa40KzVrUUkIgwbugS5/iCGC73Bx1iBnchgQ3mRZ57SOdi/i5w17l6b0GDkGBKw8X/MPqinoMudsqrE4HN8Ej4rPXco/CbPJYbG5NWERcgxcoabA3uEkR9Ki1MWKXmg9LNwEdloa5JdfOIyFj6G4VehLeSqlGCy13ztEUzIx9onmPC5+DGj0deEiCaqSxIi0sXDBHTieC1FKCmooBmqnaUesciv2XuM+swuS5vuROULchRs6mnts6voq5oxj46yiUKsUTURbJKVRR49XZWlsuj8y5HIMohQHGYr15uKDlMQ4RnsEQ1tlpa2G4mEl9RPMGGMq5OdJ+GMDajRw2jsqcVFgHXtR5N1BTSWZrIzMjZqI3QbScpv0XFZZ5C7VhuH64U1i836kMHS0J7RIzSnkI2v/SEoBsT+fegI0i5Fulp6+oGbDi8E++Tyo/5EdgjOUtrvgtvGt0az2WLSnPYb5o/ct1Hab/fkfb/rwOt8dj+e/OLkzi/9rg3t+dLH9gaSY8d/0jl4c+XhF0ZnT71+wy8mneRVP+YAPpSDbZciacDtoutDN2BX9LDKHYo+uHJQPTz67hIO/NvwvVlospjlAiaxvxRFIiabiNRlzN7j2pPYo4otR1hBso84I0jbltBTwc8irSWeNtWLkE2p6wVJw0cEGEkTAEHalAAAIABJREFUSRlEjU4QEUSwVyDhbC/O3GKPTjhWyINyztQWclzYDI5Y3JxAJaAFhdVRRxldHmUXH9sO7VnozlbUl6wAE3rne4NJkpLMjCN/lqzEUlsUW8XepJ1YtWUVoNCJ+Y2ZSKUBVJYWb40dMFgRD91zi0Tdw5hwq5nTuaJbgb+LpzVfsJTlxGvHO5+1nS9aBeR55rMig7wIYTo1bEK3ugzr1UM191AuSihDM1E0k6kmYr1xvjD9w0YiWhdl60XYMOvtpDUjiWdvvoduVkHJaBS29oQeg0YjNt1Xx96ygC0XzHoIUQtyo/Rdy9pIc8pv2D+u3c1DBOLyInigvE6DgB5sSoxAJBKxmfOxgwG/VLwOAhCfhT9RJHE4+NVlUC4msJjuhFydp1rPheOlB4xEYOFHLiuGWVZOprMZTUPMOzPoHJ7BuStsG3/H77e7xQ3nHcBBWdf+scdfM/mFr/vtDe350sf23CW9Fx7/3DyH93oPjw/Pnrp58y+2acAPFXD99TlcurYF/dANuOh0WkW3WoRuwPM+FK4vVe7+/NZnLybX3C7bweVtjAKw51Oil+DSoRnlyCZEY8/GH5EmARjJdrRFc0x8Ri6eGxxiCi2J9RQzIwhQtM1OMDPVGoGzceOJzCh68E4UBJOSRH4N1IaCI5NgPIT6ykhmkfCYuD5Mg1EhHtduaArHmy3Dzyig4I9HF8fZM49tw3yKlNfexYqEBtEf3yeYEP7w55n9w+jfUF24502gwaSzLRXhNdcUoehLjusyBYf4HuWI3Src91rdKe2lt6K7qL6dohVXLFGwWsrGQg+26h5oQ/9Qp2z3O65o51WrVUARKBZ0azkXJCZzSAQbvX72X4LHUS1KmI3mbjadB5ozo+4JcxNfGfonuu2iO6DHrl19qWy2oZcW84wUHyudVMvSEtufpvta+g47sJjr4c2idBiChTxgjWSWmjPyFxG4JCGfABheqA/9+NqD3HW6hRgMCxpkY4IdCZEHMw/4F/WGwtOIrS2kfQzuUaSygueLughmeDGtNR1d9L4qwfXgnuJ6+K9JNXvlxrNQhOjmE5iWs6vVNr5z59+8IvOV1or42Ww2+cf/fhDuuWO214pf9/d7Akl4HYNjtz/knPuksoR/N37fqf933ZOnx5k04BtemsF1Ix6/O2qT6F502tINOKQC59DPKzfws/nh8vHybT7r3oiBMeokYT8FvjLk5HLYSSuHoweMUEQ/0zoSomjYvItKFmUCPoMtdmNdJAax+GU4H12iGEwNZnuGEQtekN46K3SSAiiREv8+JseTHkKGKnCqTFww9yUVscq9IkigM0quD3s8lC6CLWRwBjihjw+chAqA4NzOxWH2zKOXYT4rtb6ELruh8j3SXHTRK8GEb5zB2qKD0oyEsWRLbffiBu3EXk9tIek/G4sRa1FG7X3oP8WayrU0LGrt7E9GqfZf09apAQehh9jQlL4KP81bWdU/3K36Bzu+c6DjO/02i7r8XQywxvLryUS45qpzWnj0P5QdRDqaOhZkpEPioYfZeOamw1k22p648eUphGgmEdcJ5KiPVjwv3Y5EF9LeJQrx6imFxctfvW6W1mqBXaILiUb4+200kkQ/zdGI0g+tfu66/dzlgb6SJV/Rwg9aCP6Qs7EwIiHv1HtiGNhD5W3OeiduVk6GwCrjACK5C0kLYS/jRs1CJfsc5uPLWEld3ABvcl3/RKS1Cur2K9Xs4/kMst4MBucWcFHG6m5Ma/2Kg9jttxqO75m+/WWvbljyG/9oHSCBwbHjp52D27yHnxiePfWWDb8tpgFff0OW0FvFvBNmlLQtvQXQzyo3QHrrse1XleXhL2dDRmBi6kco+hAtQ3kO2hpU4RBmh5DzRvuCowiuVdBwNvySu92abCfWsBmCquDrmcwxPp81jrjWBch4T1Nor1bOcFpqbIymQk3yJFrGXkQBC/BnRG2hvYjUFu5wnq/C8gmpfTJzBYtgmLvFXeUh23py2114YjvzVazMk6y3GjW1ZmRiwETc50g7yUOzYJJqJ8JKrBOhGNqLnnfTsqxZ4hWHEPUiNFLtz91WexNwsLFNaTL1oKv+kW7VP9zz3YMd3+23MSkM11/4GzehtFmF9avCZWUcc83qkwaNkiIV3n2sP6J1E07MIKOf85BNR1M33Jpkl8+PoJzxBB+KMMJuCOsd+0nsBiLq/xuBvTFLy6CruVTN0mLoY8DnFkKMYPwUBRR0Q9WTDARt5fUEyqrdz7NOvwhRAhqLQAPiY+eOGfQPXkZUWuADPc1MlzLZXI4mq4I0S9qXUrwOriCdJJl75BBEAphAGx5oPdu/Y09a61w1h87jCzh6C6f9bpCtdccdWa/4gqcB3LV6zY8/9o2Tn//6Tcs5GjfEWkDSe/4bPy9vFe8B7z+8c/b0FTT4CmnAz3Nw9JYMZpK9tYLeahU9XwGK7rB16ZPmlw+/NcjtGJW4PNIcWM0umTom/ZdRh29QmwLGLrec4ms1kEhdRaskkYf0/6AVTlGJiie40Lk9i1VvpelO5G5CNzfUT0zaP9e+UDGAboJwHMqLQQcJmc+U5oURWfiTuFcvwp6JOmhloyExYIKxdoiyE8rLlYsyO//IVrbzzEiAOhYRRpGRDe2KbC5j1IWaSvDccFc1gGLbkPbqIltTq4SnD+rpk+XM3292t40KV0CBQZ61QGT3vWIlENUDQpCZu2pwTa8aHO6VvUM9l+c0URn/x1gp/Rn9KkIbBgtyrWJKGV6MJyw6AuEFi7vcy41oJhLX0WPmdcFUKfePQrOeTYYTt31hDDvPjAnckghAQpKENmrspUVvi2gkThRQZpdxQTyoVQJ71Dp2iUZWaSN5nrlOP4d2twiRnziaxFzz8xfaymNEwixHlF4jfSEUFq8TehvEmqpGycUjSGsxiCD9zIBeVTAbXyR382D5zuJo/t6lbK15NiFaa2sGeZunIV5ZNXv3bX/9BS7LzujWmM3nk398z4GrSWsR9q/3X6C3HnHO3QyVf/7Og6c/uN7H6ketSW9J9hYU/dyVg1DtXn58+83eHfxMyfvAFiYoWcSZ5uLRSTfZ2ISRgEaHRjEI4M1TnYBmZpEBoopsdUcEM7ieJA6mMnSQodXM9yqhGquY2MniFNbg9RC1zNGyfSmZiPGmhkC1kvAzTC5BUOHMLUk7ZBARg0GhNYovstBRqMd1jplhbrI9y84/cjGbDucRmCUyWCubq27obSiStlWh555qJxzRrRmhEKQ0RiJqcxXq04CjMXJZbzlTiifXndgXtZz6W/WPdKpD1x4IEQj1DifGnVKByOPNoEJ9nCySZBmW5D7I7amkg11A8b8goVPPBApO4uREyu6jWiP2krlpOWIHRbYIKto9Iepq+ln66spnw0tDt/X0CGYTTvtntNTIROpBxP0xOgulZ/FdCEUmUCL0GO9IU3MhflScU0JBOL8gqc0gdTIBkUAVFhmEqKPVzV3RzjRNV9ooSVu+0K+P977WhQQwYV8F9RF1E9E5ZQ+Pq7Do0RMwh/sMOQ/4XMP9BcmFU30DZYCMQGgXH6KRWXiHW8VN/k0V+B2czR4q2v1i7FxDttYyrYUIuN5ipaM6J8/8dAbwRvlMNRr9wfSul79yP+dY59h1gUTpLfBw587ZUz+8zskbjtmb3oKii1XuYUZJAf3MQx+wZcrF/3UxO/KdooNQVEKUABkfoQeIHiH3nUBC6S0LEGr2yJtVAVgikJoWQARzTUMQUyX0BAXHMXOoKqlDNl4fA59QbeLSsOvJW4r3kQCLJGkS5uPXUUEiMlvKyyIghHCaiFrkyDEaoQiExwmz8chw4RNPRmo+RjVkYMBdPreTnX9sKwvZP9reZNfIJGordPXRgO8jOol0Fz3EdGHaVG67qhSrEtBaXnd27+2zkGvpZKvqRQB8u1eUB68dVAeu7UNR5Jw/6sFj9nVYh9zVsqJ4NPAr5ByTvECecexcbYshZZni9bBmJpEPAhwbVo5QCTAwxuB3TR4z1x0R5Sl0l6wRzvSjBSyJGg7cZDjLLj89hOHWhNYc0Wu0HsUD2kUXoXUbNSJT7b9qhK5qGolOQ/RaIrAXXaw4961O4fJWBA8mpzgxhzuHC1ZwPQjjOt0JY7yCSc2PpADL5sskUSHqkvgcCUjQZ+PIxFeVm40v0mV34c9a1/vfKcPMkcoPATzOZs+KbDydh7TfUITYn8E8n+MQqyuite4terl7AhxcJ8vYP/nkN09+9mt1zO6GdnzpY2sDSfcFb/r8osjv8x4+Pjx76pM2v4AavTWEAlpSnFh0Or6MxYlYU1JiE0c/GR4tn8ze5l2XHgqmy9OEMUp/jD4EmwrVQyjyEANnJhBG0LAGkK2O1UpipXsEE/rCCFJCr6nRYoOq5a/koKlmoxXVsdIcQceEieRxcTxNWgsmMaJGgnnA4pVy3jpljEhaMGd5NQCKLHoc/UnRCuktBERVWWUXHtvKtp4axoFYeCnWIteyscywq0Roj+9FYMakYse72zNCCZ8W91za4Fj/LHHU5Dnv14Hb97L2oWnfwWv65YFr+77b6yh4VAEshEcpwQXMoKUQImMijRBIlMbiLETD6oX1QAF3zNbiKETddPInzJAnrjsizp5mfWgEggK8qT0KS4mjFNTT2PlQQDEFr2HZldMFXD43zLYvjJn1UiaWnRglDCgg4TbsCYjw7kVYMVlaSXff1QK7L9q5C5XmrU6grUK7YvEMYvsjUj84/gh/5VReBouojVCafswxMWsovD7cj6KTGHqNB1NhRgwG9Nj6CJ+fJLpotlaWY7pvSPsNUlNxA7zZdeHR0nNvLQQUN56F2SNLRYhXRmt1Ttz3FZnzOgLEf4JoLV6ga+8dN7j19sccuGdf2Sx3S289N1sqTnShZQr33ipafWyXEgDFw8A/cfkry/LwV4vji1EJ2jZOt5DsIB7CJBEJrm6NBAxtpdoK15xEBod37/I8cxqpFSmfBKSE8yYHTFPSdaWmHL/13AkIw77SCIX2B1eNMWpF3FcQQTPCEYoIqNQcjvgNFALZQKixCDUniYaimoqmDAcNZjqaZecevpiNd2YaUce+XCktSCgh4KkOkP1xoilx7p28Szqu1s1X2aO6XlIDFX0f9bVcBxc+YbMwv8dGiDYznKXqDFrl4esHvn+kh88yPJeqpPzQ0OHTh47/ZLmwngPdnUCTRGqL6SsaUoaaLybbapErXr1gpzQ8xOAlAH8olKN6hRgCh79zloZEpWHp58HhQhvnMALAtYHDpKQWiUBEaS+lQmPUKuCCjsaigtCOZ3hxDIsZelzW/eEHKcJ+tDNKRdHCXm6DYnQVNNDtHFqtLKRBBwAJlBUabgrjWGaSbRZ/RuDM6bsKHhx14DONEQguO5HwaDZ2jP5pTUr0xcWGhglgrVKEdmICJFuLMycxSe4SPZKW//vWs91Pl6GC3cEIKmoZ7wo3xiLEjGezl34Ol88toHtl2Vqdk/f+1wzcf5SFXe0M/3h69yu+am2Lv48D145Iwjlj9pb/zeHZ09+0j++xhy4XJ4beW4tH29A90obZvNNut4jeCr23fEFRSeUGbufys2bP9E+AK/oUaDIFhDgiqcAccfO8DPZ/xNOPmTFcHxHTwk0GFxv8tHttTC3W3luMKBIBkTGMVo3AhD3yGkixK86/Z5yg4EOtn51IyPeBfDoOyaLgmVmgOECLAUJoCymKkh5eTHOF+kUCFyy51LCcIxRJGcaeS5nLts8P8/OPXIJyTmaNBjQyBhiNiQkC1Z4sSihlwE9JqF47xpeeH+u7TRrKMu2lkyJlhaF1Fi2jKSDRL9j/8s1yVx64plcdvHbg271WI3gE0IhRhw8aHjLplBhH1Cf23CCHhtNJRSWzTgpeX/g0ByZxr+J7kaZaZP+j3iV6GmshKLBzWhGDRUjrxUhE6oyUBhVNjVPHOTFDkzdYd4lNRAFgNl646XgGs9ECe7yVszLc61J7eMIaThYwRY5BCM9beSiwROAosNgy9+Hn0mBXp6DKDiO5iaM/etkmZVcYVYr/SgyMmC0Vx5P8yoRE0PTe+Jw560w1KImstHURN1mVLhO4jwLWxZRfikZCuYZ3+TXuZHaw+kAZ2sWXi5FzgdYKLeM7Y8iLCVTVFC5fnie9tW4JTRo3ydb679d0i/kTDjz21sLF9wmitdAk7Gc3DY7ddsy57AHwsL2T79wI9/8yZ/rs5yx4S3GWe8jeCvTW4EgB3awN2bSDreV90fUt6Ps515TwBMXq4e3XVv7AS8RGpVGJZGQIFcXah9C5jVFJNP618bt7RCXigAvFpZZR4w6JStib1ywkobhq0xs5j0sElxjrUGRFRbdh1iLxHBlPXeSUfXybXFeC1Lh0D8Y6EuJr8f8xfT6DMHGSvVP0ovTvrKmESnmT4eV8VWXPIN21o2/blvhKwgI/zkjjxaMFQvR5JJhitCXzKGPKcGQn48JtilTQ/NYWpGE/ErBab91W7V5RHbp2UA2O9MM4VZoFQ9QV0lSYSooFsiHq0KhEi2bD78kzxv/JzFhhLG/F4lA8RjIuTChl033p1WHWn6SHV2FFBNMulBaL0yRx2CiDW3cEN4AqrqswwlNrjgJXqpQnlrwGvp+FexHnWXPhGhXWOjAgi+I34PMJTkcV0FMjORpaHmggzhpDgJMgljkq01qXJG+pGguAENwaPh6hiiI+Pk6iDKQMlcuOgju9eBtQUyzC7AIzASxWUVTC0hXn4osGCVgNTzluvIeIHna4j4haxjZGPuDsBTKzOXy0uMnfEXpqVVCOIIzVDfpIoLVWtYx/+pEK7v/2kp3LJLzea+V2Tp55Ywbw0woi09lw8ucfPQr3fwd1t7jK/+0LSMJ3D269/X4H7rN8Vb12+OA7f2vD60l7b4XW8sNFAYOiDe2sDWXZbVdlFzsCw6IfopLMlwPIoA8XL33yfPvIj4TOakzIYg5LKIUwPaE0C0tFdHTa6loJW6y160qatBKhupKIhrnwaDotmChgxTQRyQYljxWNsnIaXFCJyb54X5Sxo9IJRzHM1+JNSut5GvdLHilV2mIEkksKKAuxkiYcUlMlNVS8VBJv1Xt1i8k8u/D4VuDJ6e5iqMVroVYJL5a7Dii6L/gv8kftOepOiLQX3b1NkRWWLfb0sk+HTrG/ivbQHLMaHOlVB67p++4g9IMLKd/eY4TBggdGH+gNK4WFkTFSJ/Sz8OsMfy/rpN4DTm4wlvJIUIp3aAV3TlPCT3CRBzZyCNjG4QXVxiGdyWDAiRdk0UMtkfSCQnpLqC7uDxUdCmk0KE4HaS5RdxGdgPT2mPhBt8ORR4wIoxWUvwk9bJKlcE3Lz0MDa9mxGoHo76vQlVsILi+Zj9Qlhl63iKKooUZPQsu7DIXFFer8vNHxovlDnLcT+t3xI6fiNM7KinVdRA0m0YjRRsITOux/vjgC7yFtpBxBiEami3HWbo2mgdLyiylMFzPw18yxZTwcLuHcFYzUPXnm7wHgs3V17ez87PTuL7uCSbe7W/p9A0n/Rce/I8vgFz34dw8fOP3FGwIJj+B9ngP4TOq9dbAqwGUt6BRtmM47ne6gk7RMCR2BQ1RSVYPy4eEbvDtwjFZsWBCaESWZXAoZmKhCbg1FGHtFJdIy3oDOUtPCEA8IQlGMXDt3jJn5AUcrabwsNsTR0loPX/aB3mQ4E/mvvFfxT56pSLGKju9lrxQXPY3trXDRcxRCWSWxxoRqC4J3ykYGPVOaP01RjBRbRUCZT2fZRQSUSermCT1Hl8kuNl91DTxW0V36RPYGFXoW0UxZiKXMBH09ay3VqtNvVYOj/WpwuEvah2RbBcsUIhGOPBhEgv6h2geDB2dnId0SMAWBRHRdQAPJ1pLoFHP50qMt3pbsUG33QQG9ZFloBTmPbybvmX8vUYlJr6Xu0SHaYAeDs/diNhfqI5xrzGuAZmpozRK6NBE/+Psom4tSl+XNSxlK+ujFCeBEAssG07sMHlNVUpkUrxGNLIQtxp8zKFchJgufCc+TwhS8GvYmTOt3zpfmx8tZ/5LKgICjIBKzJHm/Uf8sbqxK3QM4UYUiEAISbhdPDQSobgQy/0xxc/a9zi2GZZUNgz6CnX5DJXvBtNalnRnk/RkMLy3gHCxge/OW8e0T931G7vyH5KmHayn/5WOfM/+N1wVw+YT8t28ggWO3HRm47HEH0Cvn8K/GHzj1yGZXFt71PRm8+GIG0jIlv9ACl/OcEm6ZojUlri+iOzyz9cLF+PBxJtNjtiI5fkneXtimNiqRUJmumfL5k0hF03fZIMqkPy2QE62EwUSFW5nzYSkuXqmS26rkrW61mMUVNQPy6NETjRX4UqyIdIkaTwLQOBVDaAShomUziCgbKheQIE9rTyQiQcDgepOgoUiGj4AKGRiOULgocjKeh5b12eVnRnGwFj27NHIgfy9N/LKFiqsiFAKK2Da+FuHrfAj5PlkVtYhFpBejt5OU4kOrElcduKbnDxzpV0WnwPuoCDAAuBmi9BLHbCymsEj7YHChxIzwmyx0UVCngDuKGjqLzZgBEPbEkwiEmS68rdrcE4QlelW8kjjiFDqGW+LUAQUjkmDq0THAtEeekUEtdyALDgfXFmnqeHhiGdE5VHuEWYNSvxSlmii4E3rzkw5ZUVEeidSSpMSHXlbqfJCqaJYFfVGkpJSKSuaCsLMgSW7ivVHTRd7eZgGoEIkbjMV0+pP+v9IaFQIO0nfsfXPrM0yxxh53WUFlWtxNYjHZhjJUsYdPD/zvFde6P1GRPfND5904/L92+tWWKMUCLvYWcC50+n2JzB2pLfrdLW7nxJmfyBx8rwLJaPSByV0vf8Fmdnq9T+0fSJDeuu03HWSvrbz/odHZ03et91VLR0V6K7RMmTxUwKHrC8h3Wii6Z3mH6K1QU0L0VqgtwTG8i/Jg+ej8Ld71PplsKreOJ3BgKkhcGUpqWT8qoTMu15XYsbExukEaSikqzUWM8TsDTaqXxJ5ftMqNF0+XHVOCg21Ax4vTAmiTpS3w+S2GaSexG2nI5AqbQ/t04Zqmf2NtIqeFMrcuOglWv/P/YwhPWSiU0RO2DVfuEs3BRWwQZodWWahBufT0DizmPAM63ldcaHLvyd6gf6QRCv/EHMe/Xwkqeg6b/VVfdxLQOah6hztB96h6BzvU8HMRLHQlkQfqIMhixT8pI4uiENI7REgP4BPugEc/xxEDlEIqIGruVDpEy9vFg2hB0PJTg8yvTlJkq9jnSiMSMlloCVFFw5fM+gq+M86WpD5u+O5QXZM6IopKw0nwHeMxWoNEOhunu5peXkx1cSYZ3hqfgvclG+e4HQTmTRTG9J28f2zGIlSvUlksrvPLtAGuaBz4Hbg7yNfScASjFd1S9CZ4BomAh0gx/Ow5oKNUaYruKZlZIj2aKyL96yhZpWCsyaHyFcwxUwvfwaS4yX+Py/JnyjBKFzO2/Aiq+XhetcfgZIBVU+3IBpMQf+n/a/We3nkUHOiskerixdumP/XVqpdsaK93/dhGQNI9dttLCpfd68E/PHzg8CdvMvaRrqqhpqRJdJdmjlU1yPMcAQWe2nrxYnroDUtRCTp3DCZKOZmCw0athF0gGwFokaLQVEkPLlpxWqQoYNAkvGtuIXvVGqvLi4mgodXxAiYGYBhMJFDRnUEGJBJeSgcE9pulSaZFbP0JZd7wkCykr+jfaDw08rCAwqmNwpVrERuPrxbxMVzg+PI42z4/yoaXxpytxDs0+qlxZ1tAaYxQlgFFwZceYUySEE/YrHlxjEMtQZY73zvYwarzzqCDBiAIw+FdhtTdQFOhQxxwItJYlJ0V6CkS1kNqr6uoOiHD1F6sVcDKEMkeas7W4/jBAOayqyniutL66lFzlgVVWqPRJkAhq4jxBZlPn6NPjSxNjEqY8w9WETl/Lu6T7C50FlBFprWA1FeGihyOJmDKjCq6+bPSuw3b+DAMRmZN34KI1jjWIVyZ0U7MEqfjI9JKThvhCm0A0VD4KAYMScSQCINZr/A8kFvEzGrdBRL4xUDJ9isyRY9EY0nSggjrQVSnH8oeCJQWtiwip4uikZCp5SDr+T/Jr/f3QAWjqpUPUWSvFuNPlMjePXnf1zvw2h7ezxbzyb88eR38zjdc/kQAiJxzIyAJT+jArcc/DACfUlb+a8YPnv7DzS6yVlNSF90n80679D3fKrq+gD6ERo6h0h2g7/zs4Pzj8zf7bPApRH1QBM5ebW0AlolKaAvVqt1xicoK5r3NVAytbf7ZXkWKIqia89GPyF3ajeJSkVGpM0oYYNOgOoBci9Fm+NnLt7BVESNL+49uAAsPpawRWzfgtueWDtS3izmTJEKRmhPRWLjmgCMSFmFJ5dVBW8GKVZUbXhxlOxfHbrw1jUoovy8yHPzcl0xq/IHSh8bSWJdWj2RDbZtjdvpF1Q2ddQft0CSRPFOu+QiKLaWOUhZWVaI6TkCCmggTmhSRhEiEwEOpK213wmBC9yPOseSY6rsN129EdVqzjK6ocPGrlL+bCnKGTAIMWsT0NLhWCAV+FNj5FyGqkChEKE8tVqTfMThwMYrOtqFRuy4LUQhJzgwYEslQ01Dhq9I6C3bh1R6kFoZqFBEGqWORl878Da82cn8keXD9iObHk49A54pEJn2zTGLh7SsPAO2/gpBEHjqkTEFEepVZEKEdrMEc7QXVRvAhhmhkge1QOBoZFTe7N7vcXSRaq6S5I5UbZ4Ub49yRTuvqiuwnzvwPcIDzm/Ded4a/Pbn7FVcwJn09y74pkMDgRcff4jK42wP81fCBU1+03tctHcU1JTXRfXKo0Dklvuz6ouiGKMT7BdFb4Po+ZHA9ufVZi+mRNCphrwXpCLJTGvOqPWWDHo201Uqii2RoK9VSUk9asrgk04pz29k+Gk8ZN4FsfX7FvMbtz01iO0kkrBcaFxaNkvHcNU1FrlsAJLa0p+81OmOwC4iJQaoPTAb2IAlkAAAgAElEQVTTFsR8sahqQIMoLuTDlOaSgkYFD9RMJHtHCHymxcKtVN5NdqZudHnixttTF1qZc7M8ur49AEUjiwRwzD/CA8vBt/ut0I7dd8KfvdCWnYZkC2BIxTlHIkpjqfYhKb2ok+A7wIJCOQfWg0jEG1wEqg9RelLAQyvWa8BhWZSlqQM02ZIHYFgNhNhONnzyhrUuQ7j9pPUIVhmRgSWGhqhI/AIBHBSP+Z1J8hU7E5LaitK8pPcmx8rnuHCH6TSGHt7pvPQoy1eoO4QnvI4A2UIvYUIvezyI9di4gppxcx8siWSYnrJgxexynJcSJctlEJHPm5ntvEXkjRhKWMQoSrHGvAUcWBWdK5dzc0aXw2yyBb4KrckwGvnD7Dr4o0BnYUuUkO67YJE973Ale3sK3s2hzObwyIXySkT21sm/+pwC8r9TEAk+zccefdn0V1/zFxva57U/tjGQ9D/jtme7jvuoc64zm1fPm33gnRsOka+L7g/RGF6AFmSzDrhWp13lsf+Wh34WqK0M+q6cHZw/Mj/uXf9/EeMcGyCKVsKuDhcostHCRZxmcK2KSsRoi0e0THGFTVHP4mI+QqMbMf7LYEIebIyITKxP+MFAGDPPyPuNon/0gutgwr5xuqtpA0ufJmrmaFM4JZszzIfXVuSUI0+tVKQdhGgkTItRbQNP4FKKhHl4+rcxbuG+cODScJ7NpwsXdJXFvHRY0LagboaYJcXcBMdKqtEUrdwXoWgt/FnkVatXQOi3xA8mRBBEl3O9B9dwkJDOEQX+joVzrgVB9AjRR1USOoTmikqVInAYTUz0EM0riJyNtISX6EgJKspSV5pGQB5ftfSrYuCn16/GWAFEYgGi+1VZEWcB54iw48B/RmNKAhlJ7RLBUKNH/FLKIqaSEu7Dg+8NeTtJ/+UsMIpKAijwbBy9VhaooxnSZc/6RzDKIZGBvRs6OwUWKArq9Up8JfXGdErOdguenjxKivU0TFMVkQg95j81aSGeP3ZqFuqPnqeh/zjrWmtEqKVQzmBCIBLorlB4uJiFMit8hMPixuotLi8ulK5EbQRTfpHWgvEscxOoWlOYlDMIlewDK7Lj3BEMtda25ADQPXHvbznnvkGBZDT+2OSul5GO/An+b2MgCdc1OHb8152Db6o8/Nzo7Kk3bHity40cV6QCg2RwhaFXi3KAUcm5rRcuJkffKO6M9ptjO9IkhEtEyxELawwk0NZF9rhLOSqQRFsTdxNU8VheK7zjz2UxrJkSrMFHBAqKTJgRkAtESl7yF8lkMq1H98Nfi1qq6JHs4bEW65HXxt4Z7E1iNg53jtWaAWxdHyunbcYXtdQIacWERJgiygxX+LsZcEQFXESVGOFSIC5mjUbsZN+A3ws+F5kTwRaWn7UPgIM6h0QHAQy4BxsuAPy31nyQgI5VzySmh8KPkuqQAvCggC6RBgJSaEci5+YLjHQb9siiHS/zRLDixGCFGEbZIca1xuQlFDOU2UIzz3UMahvRzJO1p//EiDNnSh4++yTsLkklth7PKx/FFqWmpFBRqRsSnYQ/oxeG98cRp1atx+P46sL3czRBP4m6CW0SW/HOnCu2QeYIxZpOZnb5bqkPK49goHE6+DzwreD/MnimWVopYIiOI49RRHd6nBFyOCGFw49IaWExpWgj6eCqsNSDwC5aTtb3f5BdA3/ichhpX62QqYXDqzpj6JRT2J5PoaxiJXv7YAkXQyX7BiL7XX9zfbeqHnVh2gn/V1249Kbpqa/6zxva5X197AqB5LZjAO4fANxoeHnnZnjol7f29e16MIvuD92SwQu2cyivyQFTgQ+3IJ/R9ERfcduUogchKuECRefdYP7w8DbvDvwb1Uq04QQbASZFKV2jJrzr78IiRmlSfqLRxLoV77iNds3iWlcvkUAkjTpwt5EHJp6Kgoe0tpdGHHUwkU/QRCvce9xVnG+YBlUgJjCLYtqqED2CDQBVF6HaglikxkO0iELh/5HCSAQqsmLo3aqgnNjJZO1wcJWmDFM0gPUh+CzI4ItAzvQTauIUyVAlOWsgcjxrIOFjC2RNsDbEVaiAZBzJMB8fNRBxTGLuhII1vxO2k4Rpy1EHG3+yp5yua+MSNsC6I/kvFBmkAIKnkmdI74/6wuhjNl9mohYRj6O+QYsJz8W0DV0SnYsjTB4AGMx14DYJsLhRJEEFpwGgF68xBH2xXn49siLdIzZ6Dp81gGvuGT8pWgpKfHT/scSUs6vw2dqGj/IYuD+ZAAa/A7oibgWvxYfhsmIyAk0updRfqhsJizuUvFEKPaW/5bBYjKGchxpdfLWXi5vh+13ut3CULkYj4c/WyC3GkxlkE6jmU1i0psvRyGYpv92TZ37QAdwpe8iHSva/few6OPO6yWY2eX+fuiIgCV81OHb7vc65l3jvbxuePb1pilmaCnx0XMDiQA6LrTYccC2YFp1Ou+xWzvd8WfQAFjSKF3WTvA/nLr1gMTn0JorPpeaAvT7itjkyoL/GdOCocZDhtQ0dJZqoaRuNwju5W8tZXPTFkUKL5+Q9n+YxMr+ejqEVYOPeU5jqbLObYsRj56SQdBK75CKAct2EMtFUfKUdICiC4KoytCXawytqHzgWPsdbVa6dNxluNprESJYNJ/RJNTQzaIiC7E2L/bG2kj15UUT53anWxaQ5AwWCP0YVdJxoIeHv1ECRWu7GCIWyrwL3zhFKWUGWEZ2FL5F6Y5GpEfCgX+gepbcdWUsyuxyN0C/5WLO98HmkjncMw8T41rZjPQLhZSaYEV4BGXcOaKgRYgQRDWCYxqKbEnE8gjo78+A5TZjCRxLcOXBJIslgxINKrumw/J0swTBRa8btmvvDz8S021i+zpEPBS2RsqLaQpkDpxEG0U/Ss0vwy2RfcQRMMEfak9WU4nOQ88s9MGDgPyk9mscyEEqjPMLFh9wqPpxbiw/Dp/r+97Pr4c9RGwlAogWIbjxziwnk2QRm1QxG8xnsuEU6BXGDaOSOe4te4R4GgGfLIq0ubf3k9B1f+X37g4PNj75iIOkfu/0rM+f+CMB/ZOeB05+6+aXUUoExKqla4DxFJb7qtlu+64teN/TfgnzRzyDvh+jE+SpEJd8h1e41MFmaV1KPSlKNgnx6JgdUi6gL77QuuV5BjLb0C5LQIdE4liku3vHGIkV6KoJJkhJL+wGN7d5ggslJmu1idBgmFey7wvvlDrPEGhAYYOokN2WhrRhShDnVk+kv7NtEQq7Lwmxq7fsktAjTXQIg6F5KHrbQH2x/DV1Hxto+Y2LwKDcvRiRs1WOW1VIUwqI4pvGGk5bU24p0E4loOGKJFCb7+qaIUoMQfmd18EiBg7lytez0ITnGeO5JwGHpK3N8LQIJdlI1gfiReAFKK5liRsEH/j4m3zgsCh42fx/Zeivus27G70qNdIg4ayDFXj5pO+KINEQm+FUK2Rph8TPiFGGNLgwI0PakWhk+iYKn4oyJzqSVvYng0NfUsJ4xk3+vWYe8/qnIkGg9/GuY+0PRN+b/uozaxHO6L+RwrrjZ/Yhz1Xbpq7GrsiFGI7bLb9BGimoGFy/OoVst4Hy5AO2rRXLUfuxo7233vRoy/3vyGb9YlJOPPfIc+I3XPbmf81zJsVcMJKEW5MCxrX8C5z618vCK0dlTf77hBcWopDfOQVKBc9fCqKQK/bcCkBRdjEqqcuBbWS+HEqMSt3X5X8+3Bt8PkLWZ/9GImzN2alGJAQumo4jCUuPAWV8RAOoUF4MNU2ExAkBuIIKJRESRNtMICTeFqYNAT1dpK1rhfF69jP1FJmRwUVIWM6aLVGkjMjrRYWPbI7EY1h0k8yIwQyvAhpgNKlijHUagwlnFaDlDuQantqJWL9Y0buZkydDVBMAw70M0C+KRSAPB7DvRMMIvwrtjMTwI5tLsCiOLMlDxPvQRzGQuoRQPEijRlwp4UTxjGEKt66BrxevhWEAeVF3rEGxULtKChwGJVfQVfZEaPY6x0QpKOxy+CtYKFIzZF9I6CPWN+C3TzajRFw2kbpyt5hIkCkE8Oo6S/2zKMS+xJMLkzzBFRLkBQgwIcEknFP6gdnmhrvu4MPHPWKvC959maSWaDEW9PKNe75aaTdM/lWKVccA8NpfoqXAQFR0SU0s9y3TeCGcyhgytxXSbd6eD7LD/pexI/l7n52OMRrL20IFDkZ2ikcEEZkOKRrpuAduPhxSvEs59qIIzYUHeERm7NQ1pr57yOxz9zuTtL1fRfc3TXNFhVwFIAEz/rb8ePnD6Cze/Io5KAmE7uD4jraRqQXfUhtaBNoyGMSqZLgbQgp5EJRmU/fmjw1dX1cGX8k4nA818TliQdviVRCG6psTTX0lxLRl9zrZKPGY6aM9eXHSY1peIcbSUCt/EbmBCm2uNyETARHewci+SQsTYi4Jq4C3iugiaOcX00fDQPmS6i3/O4IGBiQjISFJoRhCaRLVF/HFZK3b3oPmL1BHpvggZOM+Dn7E8v5CBJf9HxYLUF1ZSukkEQfYKeTwDUDwmRAsJAzjxcDHWSGpLOQYi/AbJJiUdTGxUIim7chrzO7KJDftPvX4TvdADb4hAIhoJKEg2VvxKddP56tmQihGPL4IqwuVwMbRYe8KMcDNQ0TRGBPgIYPhX9sVI3OcoIYKNHG8eQ/x+7dEgz0POLYdETQhLf+pRmU0E0DuO4BFBhO/NCuwCeljkz24hjs2V1kLUUyvslfl4y/nQEifcew4fKZ7jfxwpLY1GipGryrFzi8msDMOrJBqBOXSfWcD5Wxbw9FYF9z9UAey/XXznzjMvyzyo8459tR5+7HPm7/qGT1hfrSb7flWABF787f1BOQgz3a8pF9Xnjd//zvduBia48By8+JdzuOG5mUYlR1wL5nkbsnkniUqCRpL7vkQl2Xh43ezp4ofAtQ8RSS8V3ywOmGiDtIs1K97ZEGukE+1wBJOYG6URSNMQLAQ0zaqK3YQjsR4NpThvu4EJnm8FmNBe9ljzJdcuBlqbtERzpdeNxpSAlTc/SSJ84cR3KTsv2T8hQmFvjxo6UfsmKv+TAVuhCs0YqyQOYruiTyKK2QQspCcldRuiY3CrV5yTQpRXyKQKzxnBg2rgaCpF+CfPzuOgkb5HAowygAlRaDECIKzCf4sowfZQ1zmmu0kA2QAcCDhcar6068R429YoZOjpe9MIJBps/p4mGovBnsw70zjGoAptqcDBURW9+AgI+Mjt5xInQowwbdvYkoUD3PiHAS+ileTKTZzMa8QGx2z4I2ZwWJiCSKRJJfoRwFAKdun7JCrmgkuj90g0EsaKhEici2yRxeJMLW7MuFhMfTkdSbq8z6/xd7sD/z97bwJt2VWVC8+19j7NbaoqlViVBIlAEANRkoqgiAKiKAqIhCY0QxFRHiB2VESGPoe/gQQRhRTdA+EfKCKKvgj+iPKUJlWhE0VMJRAIPFoTYlKVVHubc85u1j9ms9q9z7nnnnsrqQpVYyT33nP2Xrtbe37rm99s4EvK1MJG9DIJ7A02Mj+C/rESjmup8ot1tSjkd91spH/Vvk8qgB+2F2iWV/918OonuL9ns8Pr32tzgARF94t3v1pp9TsGzD8vX7/nCes/FbtHwkpcr5IWVoJaCZTzOgPSSrTK5qpbj/xYWW19jvVJROHA7Bd3TIAt3KQ6XHYxZnkGG+SporjYARO6uNwy2xc0YbcTj+msvbWkgW/elmAK3FyivziQGQMmZL+cu8y63zyw2K+c3uO+su8sVgaRCK/Ql+8MDu0QJHBZ7HEJFLK2FC7CEBNesKylfWdAvhOBm1ggxH9u9RFxSVFRMUxaYxbCbK9mLYUinKnvGT87QgLuZOFuOTVi4jgBBlx7fAslvLqOXpZxYJBO/EgwD7+0A6SJhpYcSmhrdJ9p/2Blbw0+PWU/eLQCl3287ebpFmXHe3cPT0inbdDxGGPpDgcgYJMU5ZSce8+ih9XALHMNzj0EHXtr7fkEriefpc9TxEZZMTZKgUqntXkQcdfAp8ZXHjAcJ7TbOxm5tIQqOi1QUtl950NEGCw1DAUmH8pl6a75pD4X3ukEdhuphdrICWIj/Sv3PlYptTecVdVttz999JZnvy+dhif6700DEkpQ7KuvKFDzdWF+YOXze/5jtpOfkpX0+j0zYiChCK4K2Uk2p0eDrcW36pcZPXdfaxBoxc4RQgZpKBtfa3AYSMSaCcOwBntMW15ngUKAaanFJQapERLsjs+/2OiqcWByYpiJPba4jaxjwmXABecma/PGktst2e2KOljDB6tO3o8L1to5QVctHWqb88Q3rHJxSNbw24SayMXFIIH/o6ZRCrUQzm2T7HSJNLXMg3R5dmNxfoj8ExwJ8IRskWhIvFHLK+PDpri41di3ahzzcODRGoXF0drBv5ZoLDk1ewCeVVa1bYCIm2kOlPjhNEGEx7WA5Z8zxb7Z87C1SknrsaK129G7xuz9c8Uk5a3z99WuXgIe1A4i9tUSrcetXuyiJvo80EPCqDV+UmH0GQ7jyqCwwE5RWx2eBJLBjsmHWAYF9RGJQBxmZ6vfV73qgAI9JlLLaiNj2YibxNPazf6V+z6sFLiqImZ18PXBq376/Gn338ztNg1I8KRsK14w5v1L+/dsoDfwFFpJP+8ZGw5s80pUNqc1zFd3HL64HG77lTgc2LpRbMa7TwhYK7dEltyR8N0WxSVWJGYSjcKODGAezMRgnwhmErnkQmZCUygMPeb30jnRA91H3uPI2MYLWDbi1Gu8ISaTY8BzC3ovJcDXfirRqAEBcQ6vpIc77yiJgbIO4IPL+dKvPBCVqwz9URKbJTZLjoaJhgGIhLZ63Fs2VttIdwhfrVArSV+5QPsIbK+M5jcObe5YHYSBLjaiAn5tLMThYuAKctBizyAGEXTgOXcU7+/PMY2GaugWyWRybI2P4WiqG1U+DyO05D6Q99LLO/asCRjGgYi8afzq2fNuZLBL06pQYJckXO41kmGElqlGy+4+6Hnzfn0WfEBBtsJZ7NkKmGqV80aqwQhKzmKnSK3N0UY6V+z9oTxXkYRgDtz5i4M3PuMvNhMgph1rU4EkZCWmqC5e/vwbbpz2ROLtxrASG8Fl80rqrO+y3aHkGlxKz+m6XihvWfnFWi0+3LoqJH8qYCLWxWVDSMQK2vfQRUtNiOJqaYIVg0naUdG5bGYCE1nvi4IZuLkEBuj7VDNpyYD3ThDrWpNXLAgVZi0iWZpbIVpwiBuKWQ81WSrOwPc17+WUZXkcLtUFTvwK3wFLGDnXiFpzaMVuLMtE6Bc+G+mFzv44dndR1VmuAutwx+FHmIHOH7ZJ4JPncfIaWenNMZnQ1rKVbMv/COoXenPO1M2tZfg8bDRWyPAkYjZxPzXcWHKJ9gev0JvRXf5GMMPg3PFxIGKTKW1IrQ0d5lGCm+oXFdOCiAMLH47cDiLMJnhCNkN9QxDxwQO2vD5eYhDuSxnsFKnFtV+oLTVGb3GUImWw20vL4L+796mvqkEtRTW1KIu9JW+EIrUa2si62cjcVXv/EUA9yU3je5CN+Ic8m7Vv3cuyEmPgmuX9Vz9zxqGDYo5JBJfNK7HZ7nnWp34lKpszhpMUtTJz9ZFj55ZH519uoLPoNQgRjclr7gGCOw9ykyi74OH52ObimlIvoZkbu61ctCt9zuv/KFkxiuSiOyfWVSym1w3GgokbM/T3O2YiQ1JVCmu47TkGh/Mqkk3y84/RjSsYQS1PMMzLdVlypkpYl/OyUxqzjQBidZtPgu9TMFXse4UqR+x6YkvhlPBgfz5/LgiTaJYWSMJbmvweL/3T82mbxQn7moA+PFqgedBDaqzh4g8i9xXuEIaGNbQKMXzhedpQ2uA1j5yLKQsJwSoQzm294tDwu1BwGVuq58qMisR0trcNJiI78iW7cPBIOwkTBdcAEdnPtXiboIswiFj3m62GbEV5jlALG79xpJZ0PlQaiuFxqKUoI557dmZ9tVrMbsLKvhVkKyi0c00tAZK6Gno2YvNGMFLr2ho+u32mSK3OKz98Sa47/xk+7XuSjQQzrO1Fme2zkJWMytFDRp97882zjSSs5LH7NGDjK8x2x77ujpUUvZ7Oe5RXovM5Y4p5U2Ljq4pZiVHz9W1HfrQstz07Et55ZouBtM2q2PDYqlQWTHx2Nc52XqG7NCbnsw+jpsIoLLH6U4FJYNWCvBGxLA0wmZqZ8KUG+1uZn1kYJeX5f4lRlv2CVb7DtWhcO0Bwt+gEpRMGs5oIJezaOZ4XgQcsYhqsl5PHijDCmauArbC8buV6jYqCHSO8QnebPVFyds5iR+tPCcdaEyxCraOmciJBtglV1wj/bggu0fgBU3C3ONGYrO8/2i+ooeVDODzD4bFk5e7ASZ6P/eFX9A0mMhFEEiYiL5I7XgAqEgVolwRW0XERfZI9ImeLF8jiundn2XMM8kV4XgbX4srLu/18DlNYBkVO1HY4lOKknMGOTISTD9GlVQ4xLYQPpHvmU51z9F/Uplrl6r6wAlW+ojrALq1CD6imls1ij9iI68e+fjZy5b73goKn2WlxT2ojfmrOZuUn7uVZiXn38v49G6iF35btLu14sbc7VQau+sYgmGRzYMvMIzvJqnldlIvFt4pfM5BWB5Z3idwe1CZbIn3aorhCI9+e9R4BjKzm46x3GUMK+LpwXbu6PlHMxOoIvjYXnkikjfiILv7KlVVx9sa5/my2XhBRZfNYZDow1rLptraa/tS2FVOERcQgSFsJixp6od1DGVt3zARxdpBZXXAgS1RwOwyooJpe4u7yJrvBAzYw/1uZRjpeAxxSN5i9WXT/5csoMSXWIaLkRh9JLYp2HI3FjzTOGxknqKd6Aye3Bycr7iupfiCLsSBDfCp3llzsJCYiE88d2ZfYoVQwprlhCLktMBndJxuvLrPa7iWAGrq0JMeF2ilQxQUpg2I7IDKI4DgcpSVzTsHx7Fx4hcrhLmyZS/1GEEhMydqIGQyjCr+rx8o4i31GNvKqj31/burPhtPsnmYj4QzewOvU3NWyEgDoqRouXrphz02zHaCFlZQDbEfWgcUtHVgd9sCs9rtqrscteWHeqGwuMxX3LUEX113Hzy+Wt+wG0B1rKF10Pi9kfVazuIAmR3EFIcHOtrEBDux1S37JOsHERiV5G7heZsK8S8q2BIUe2QDbskQSIevJiQUTCywWdG1eRRydRidl7wM5+S1jcCKI89Cx0B4mLIhbK8z3oRc1ohHhdfM0ErYh+REu/4XzOKzl9GO4oCpbk2riT8zVTpjEuO1dqTJFufKWcdi53oi2sl80wAW/SMAj0jo8HpBbJmVGNjLZGfkmgLBX0QnR8bufRmW1gUigO7hodV9by63SbSa+R3z7m6UnjAG+PU/MIug8W8alZMmkrInNa+J7F90XJ4Q3Qn3pyl3fHL4PKLhLAWu6t1QAW+ppEbBkWB7emKqwtFnprfDnejt80oGIqVa5FAqINoKFGcshDLFMvFT4hYMYK8j/cYXfdbOR/pX7rlMKHmOn0snARk4YkODAgVbyweX9VztRaP2AElQG3nI8g/POzGCu4H4lpeYkRaildIqZgy66ucx8VlXU/EormKu+efzSCrZJmFyYB0LLZsktiaO4Ir3EtQIR/3uYyBjkI7Tnl7RnvhNYWb3BhiILHwispeMP49xccj/HaCZkdZ2tj8XzGExwfK5HYS114Aajzyxr4y183kmQNxgiqQ2usqViAgAghuIRIZgS4TmFQIa/Wzdk/HmTYVgACVxl6aRzRCYArNjbxX59p91w6N0a/yZv0NA82sAjNKoOdSysJmHFoQYSvMo29Mm7lUQTCCsTWOZjF/ZxRrvv65GykBCgUmGdbqBUO3ATRiaLvfhxTMSdv+vvyGG4/Hl75jofb5IuYiPBbFptFOprQ5Uph0SEdDxNKsooukjg0qqGyz6PpQM3d88xb6g1rLq8kQzzRWAFympQ1LAK3XIIpjOEJVO4Cr+3HKg2UlOrd+Xen9FKfSCchycDGzmhQBJFcJnq8cv73/Dhtd7EMd/HlYHhaAbYr6Rncig6XejqLgyzXreDYJJxQUdl5qj5lQjvZjA4Y3QH/Bao/tleeHcaH1sTChcVUOEAfG+Ao1pc1qg1kwSFN4tl9UaRe4o6e+BW0K4ZlhPZfQSZuxdTMBPZNgCTwEqH7rM2V1cEhGEmvBhs52Z2Rlful/Ve2fT3EIMCSuE1jYhZ+Mxxfj8bTMW62QLnFd9fcW8RGMhTkvWAc6e1TiTvBpPkOjcy1eAK9omjp7hkJacsrgEmFoxaGccY4OC30A0s7jI5WhTiKmcoGggXm/Jn7drFivFlE9xILvQ7NAX1ZlRWADACCcH5RcmJrYxARHbZdSITCWuKOdS2SYcNJhJmrjcZjcxM0kXkJZZXk6v5iqLustapbg8DivRhx8KMVKGRSC/ljLj8GFNkO8yrVE9h7w/ufIjAYQszYvKhzgZgCmmhWxVQnVlAdqiCjfQbuex/Z/2Ld35OATzEPsOThY2cUCDBwed3Xf4HWsEVxpj9y/u3PWyWEgB80wJWsnObhvOOZnD4cAd2bs2j0imq34vCgVErQTABQBfXBeXy4ksAMLso7BvCa3EW0yUkWLwyDkzWCgl2riK3HLTLdA8flvnQ9fjVfSuYbAoziY8TMRO2BsFyPA0DRuG6xb0kLiULXH4EcXcF+GUtYWTTI1CJD+/0mWSMeGHdihAeXNy9TbaLr2XcIOv73Pvwg/3SPJrUXeVMQNM9FT+QlqTGligsHC5iIBZEwpBe+5rbdbk98RgkvB4i3zfyQ4IlGAeheWAL3Eo+AouA3g3GpxoI4Y57CLMYkyvCcMgPlv8/homERRiDY3F1YtxHQIRdV+Ir1AAZ9xRhIJEyKBZEdGbK1WOqtrW0sK7+IvxN5yx9LQrsoDKuqYUtdMNwX5OzwJ6VIzB1EYf7ztZvpHfV3hdrUG91MwjXvHccfMrwzc/8h+9UGqcAACAASURBVPVN3BOz9Zp8fUOHpRpci19WCr7TVNXzlm98w7tmHC9mJQvzGpZXcugc6kCmO9DDOlzS/ApZSWXmoGPmKIoLdZMc5nQNc9Wtx59Y1Vue6KK4XB4I3QZJJLRGNdACJKmQ57BoCI0qwfbzqLlVwETSzPdxYGKjvQItxjIJASB5aOEKPyp1HvcziV1SknrM15GGCDsexkOH/U28EO+mcvyLS8eYgqHYJX/o9rL8wEX2JkwlnTgu2XASuATcItpsgttr4gRNgcJuPA4wnK0d854xmgsjawUXnwfibSmNGkpB1i66rh32fKy7yZ5H4H6S4WpKGbXXMU5Qjw7XGt4r1yHRYAH889WFyYZRZFVDExGwaNdEpmEiAWDZqr6uQrHNYucoMGJ0pIdwC2luJ237r2uoyoGpioFzsamOualzrvpfNcAq1dOicN9qFSBfUejawkitMNwXoIDVTgl3znNhxvNn7H54xd7FuRy+AqDOdi/d8urewaufIAVqZ7Sqm7jbiQUSbnz1PKXUO40xty4fOfwg+MY7Z+zYhS/xNRoedlhHBR37W3LoLXdhWEgnRSw1j7klXngHDAfGcvNVtVB8q/w1A3PSxzjVS6z4Lv0rWEJ35cRtEUh5/SeXnF8zWZHemKaby7my2Jj7ulxsPXzFYDEn/kcTTGgXD3DBprEbrDWqy1qrUDuRc0gAJ9VPXFJmeIr2XGxOm/3OBWI5tPTT2zGgwHWejhm+DI7/rfcNsUG5dr/073WMF4rSjd34dRNCGGZmB1umjCB5RadiIDx1/KAuyMl/ZptChZtG554mGVqXkBvVMQRZ0QSMoS0EV07pRDCRyK3n3YG8trHg4bokSpFFqv1G4b1UHp7cWDn12qGcH1OZarDkdRFtlrKz1R+qrjnoQAQ1EcxgtwI7iutqYQD50giO1QWXiQ+TD2djI/0r916llPo9ByJ1XVffvOXhxTued/06ZuYJ3fSEAwlO6IVLdv+HAvX9xsD/XN5/9atnvCKfpLj9fA2jsCVv1oGFxQ4MEuEd80sw4x1dXKybzJljx+9bHJnfDZDN8Vsd5oFwUqItQc7nKUlutJ04nkMDHWSAW17j9psKTMRBFJaeb2gmFgxiYJjMTMYzGrlu1iZs+EwMJgGTkmgtV0XYTecA5qybKsiEn8RQ2KZEvjOXeU6xCe2gIit3W2bFruRFYoiHc3MsWPI7DYUHmv6f3d7/lP4Y41+fWOuw4GHzN9JDB+CRah8yBWNosExGQu84K7uZAe+1Gnei7RnqiRbiwCoQ1GNoCkAkFuoZwDzF8bfZajJ2oDAKS050giYytoZWBCL+/vo8FJulLtnr1i0nTal8kypbGoXaRxsM9eW2vXy++gzzNr3VXA9araoKy8TDKuWLGLXKAntvFbr1EEyZCOzbqo2UiYdXfezcvqm/qgDYXuHUPbb0jsEf/8wLpp/AJ37LuwNIoH/J7h/NQe0DA8eXVPFAuP5NB2e7tCQc+L5HMzg6RninHu9A/d0pJBjrcmEtrtrM1bcfeVQ52vos61SIoq0cS7AuLpxKXIacnLwWTHiGyf/HJCuOqRTcVpPLjuY0kwYzCcCkoclYs2hfW18knhPJXfCWZ0H+swnspKGdBJWE7eWHnCkBFGdFwuREf9v4zJJcFHsjJjEV90aFZsp3Z/Vzaz1oMduMDBf+HrPousIVesvg4o/Cb9K8QHd9aQFIy2hSDSSGGW/Lx+kgASqkakxQfVeMaLhFdE0uQ5yGs+6sNhAJi7PxuXonYRyd1dBECJdaorNkDWgju5z7zGaukw6S5ItIQUbURVjBwe/RpWUbWKGvS3Oob116EOmZT+Xnqr+qUQ8hXQT7i+QrUFUD1/lwUA+hGwjsy1DCApSwvLMGuLCCa14xW7jvVfv+XAH8opsS2Iv9m1++H7zr1+6adcaeiP3uFiDBE5/fdfnfawWX1sa8ZWX/nl+d/WKScODv2aIj4b2ju7266td13QeT9Sm/BEunKJjzLq56vrht+AvGLOzi8whdXDzPo8ZKwhDsQtm1gE7AJMmTECuWjO3cL81qwQ0wCZmJQIBfSwuw+IB8dzy5tz6/wl6kA4+YOXghXgBnrHZi71Ua3WXPPAQsuY8BxvGCvkWYD7BlIlNh+5dep7s6m0cSLBAYcp07yTGDQJuwWzutQmqFpZ+3/R30CLe22aJJ6wQfE7LrtsXva3a9yDie2TTyQKy6Ermr5GY4VsAEJykMyYkcvv+HewXGaSF0B4NckVA4b4rqfqoKwFmMYSEyzhMREBqnibQzEclDceMm7iw6XRbX6f6h+4peQ3ZzEXAQQAmIUOtodG9lUJarxhRD79LKzIHuOfCaOodjkS6C4nomOSNaDwC6Q+p8iOI6/pcfruCWbEPhvv2rPvoYBdl14VSqDh35ndHVl75mdvt5Yva824Ckt+s3HpRD/nmloFuD+YGV62ctM09vgQIqnXJQUydF27OkWunCwkIHRkWva6q+wR7v2Ja3n/WNKeezOnBxrSx/R3mw8+tGdXfYRXuDmVhWwKHBdGBrMj2YBExBmi65m7pGjkmTmYyN5nIWulmby4OC126cZQ4rEQfnP4452JZ28v3kyC66Fe2Z8XayhowgzUPBbVoKQ04CFXvzw1jd9BwnvSdjCUrIJULYCQZb95sSMA66UXasZKCo7Hp48pPYhxj2EIBo8zRcl9qIOb8Z374EQCyoRG2PEwE+SvYL+6gHCNHqzkrLRLsILKYwsrsNrZ0cnRVcW9I90XrifI3lNMxXtBBpLcJJhxLqq6UgI2hV1wU1quLzoHtcZmep1+UL9der0KWFwropV6HurmpdDYbozhpVI8iLEcAWFtgx3PdzW6oNCOx5P1M3KhWE+w6Gtwy+dPQBcM0zManxpPq37tdjI2e/sOvy1ygFLzcGrl/ef8sPAFwz4w25QgNcqCLhvVzMQB3qQDXswvx3dGA44twSYSVUPsW5uDiKqz60fH65NPcSgKwXBDc6/xCrDJJZRx4uBo2ImUTJiriNXXG7hfNmMRMPJmxsg5V5wKCizpDOco5pkkUvjGMuspqdrJ24asLe4nMtLJcaJlPEMqYGqIQ8jr6MmUpi7YNLsMVd4zkoIGCr+84KMuua2AnYWEsWptC7K2sZOBTMIwaTaB++ym87CkVJjsGr3MZA+EbH73tDC5ksqHN6VXAqIUhFmecpg0nzYWbVRMYwEYLQAGiQcTAVkenFEVqUaCiZ61JDS3qyMwWn3uuu3bBRehv8Zb5NfYqjtNRqpROXFuaMGCzKmPkM9jPOLODg0QpgWwUHsfPhrAL7vt9VCv4wnD3V7QefOXrzZdesa6reTRvfrUACF75kcaHX/4ICOM/U5vLlG/bsmfE624X3wYEctm/vUNa7Lno9lfciF5eUT8GERaM7fV1Xc/XtRx9ZjrZiYUd2cYUCuX1vImYSuGaCXiNjI7mcnsGGty37fTZmwutLMf72h3vPHXvym02I6goAxY0aZMTTSxm4w+yYQZkV+1FcCDJgPvRrgxK0gEpQTyu8xHCi2LGiCLC2mSTHSyolzjjneLdpwcIeJOyDLmYtPj6HtFpoCkrEt4OH07KD7HTZku5cWh+LH20ogPs1U0SaWlgIj2efQuhCi1lOFN7bFNV9oUVZ6k9iIg1NJDx3G/4bn5PcPYE1LMaYRGjhQ5OkQwr1dbqIhPqCgmJ03Jja8jcqyPjJ/Gz4G8peN7BaoSsLQ31DlxaCCOWMHB9BtnMEJisgX6rAZbBjPS0qhZKUo548A/uv3nt/qBTaSS+wL63sG/zRE39sQ3P3BO589wIJaSW7n6KV+v/AmKWqLh+yeuObbp3t+hLhHTPeYVsGC6McrItLFb3uoOqbXtaj3BKM4lJGhHdDrASwhMqtS8+o6i3S5zg29r5OXFjqRMR3so026su6720ZlTRqylbHHddjfXyeiS+n4kgJsQj2ZkwEkxRs2l1dLkgq1U74Cz5Om7tLamslIb1kFCdGeU0LKlZTsUDXsl/olXImb9Y8kdlmIh/WGryAYjS8ZHHeCNe+CkKN3dvY4rpyIJQI6OM0EN4+eb/jkF45vWZyIV2Q1MSKCiQmriyubcbp39Hx/IXI54ErizdcryYiCz2Xj9LsdIjDWhCxSYdS8BHBlar4clFGlUlBRkJJDVWxbOqq9BpQx3y9e65+U63NkqrrAYIHZbCjJmKjtFAXcS6t/ghrOjqXVpzBTr6M9cys/lX7PqQAftKtRYpiZG795vcO3/GCr6xnnLtz27sdSPDiFnbt/lul1DPBmL9f2r/HlUNe/4WHGe8HNJy3M4OxLi6J4tK6b8rKhwTj34PhlvJ28yID/Zb8ksCI2VBf0kt8Tse6wWQGZuLBxNW2cr9M1k2sdQ2NsI/q8iwpFMqbYrxbAzqSEb4clhhZA+7fm1hDca+GBDSEf0dP3w8QvYIc/cWmOgSLMe/pGALUmGdtzMbmVTY3jj9pgEX4tb1rLYzDAYPbvmn0I/Bo7tCozutu5zgdRIw4bxfWxYqF+3YW4vfhKcWl3e0xUy0mjcyiveV+YFhtGprcyFifxETk2DxcwkQERNiHRZnrXGRaBHWMPLDRWkqLuD4K80WOZ2eb12a5OsBsBF1alGy4CpgvgvrIsBqO+tkAimrkijK25oxQSOK6QKT7yo89O9P1e8JZVN116HdHe572R+u3j3ffHvcMkFz4knNUt/dFUOqMujI/u3LjnqgQ2Tou37u4vna+BlvUkVxceQdgSwc6uguge93hgBMVlSEWQnpJjSHBzEzM8ZVzysO9XzMq38rvScIcRBsRL5fv7d7oSzIlM5kaTAQIJC8jbo7lGYNUvfWursBpJA85doORPXa1vVx0k68CnIBCWvNrEkNJOim2M5RpQQVPGxtctXQydFFgHlw8H2hQlcnTKtx8IjikQME7+t09aLhqu97Yyok6R9YE8LDGOgaQOA8kHHgSA2mJxgqIk6BIWJgytn5JqZMkKitgPsKkWoV720+EvW+O3zqA4ZDmmNnY8/YCfzsTCXNFKGLLaiF0bhTmSwBC6euSdIj9RYamHg18KLKCWm+Ht+Rb1RfrusYvVinUN89WAP9GIEFdpOgPoNcdwsqdRatL6/zttVT3XZdLC6744Na5bP5LoOAc+2TrwXD/8Kqf+v71spp12NBN2fQeARI88/ldl/8PreDtBuCW5Uo/BG587fJsVzTBxaWOdwD7lpQL3a4ueiaXkGDq9Y4uLqBaXBmyEmP69cGjF5arW37Jl5y3K1+3DCehXfR3Mm6xpsKhpm71zs1ObKxkYOS9kZ6smZAx8Ra3HUyCiC4BnejHxKguPoCrRWXdepPYCaPsZIYi5+00FH8ddH9cleHwift77E9/7GIu/mLsZiGD8aG/610lBg/AaRkOCtwlNHqIJNM5dVc1QEBW+TFwuGO7Nrfpfk2thJ2qPo/F3541dZD44GnRRT50CDKNXidBqfdGZJbXSngc/j/fl0YVX54yQQSVDzl20V00gmuLG9wYKnnCiMWVfRlQqAQKi+51XZlqtCKVkflM9CK8Lz9TX1srAREU19GVhcmHqI1gCRTVH1DiYVGPAI4XUZTW8kEEjtlLxF+1960K1IvdM6+quvrWbT9QvP25UTfE2ezkid3rHgMSvKyFXZdfqxT8mAHzuuXr97xs9ksd4+LqjXIoVrhCcKm7XaV7phrNITOBzIYEw5zROQnvoFW/vu3II8ty22WuKSwJ6s4YS8IsgYms6FvAhJfggftlI2ASWsmxPeC95U+jyHitzKAnkoot9cL3m8Yfo520AIpbenM4tFvYjmMo7vjeHIemsKmlJNu56sPN/ZP5wjAbMpfE2qfGn//2GkX73/4oDfBoMJdxTCO64qQkfRqyy9tOZB70xFL3FRtea6Ljriw2SspdS2DE7Sxoy1D39p6O5/uEiKAdfC8hwjxbfVQWn2pbZ0PeLO4Z7zUdXqP5S2owEbqCIOHQxhLjT3RjEYgQaMTiusLyJ7Wphthi3S7TuNthfrb6WwYRIFGdstcp1FetgqoGqtRcSytHl1Z/BEYVMN8tm1Fa63dp9V617wnawAfDOV0fPvqG4eue8tLZ7eLdt+c9CiS9i37zglzrG0BBXlfqUas3Xv3pGS+9xcU1ymCgc5jbmsOi4t4lqux1VdYjF1dVzFH0VoVZ7wgmuo9Z76BNv7rl+E9X9ZbH+/4dUdMqDoPhivOuZLwrlIjmzDL0wL00GzNB09jSz8QtC6OeJvJeyKvsamz518UL86H7Lfg+ARS/RA56jthw4Xg3n6jsACWN8rKn165tjGcq0YG8thJZ9Wnc0G3ns57ZFqKGv9zJIwSvl/u1jUH4UWLdIzTUFjySz/j2OACJdAuXq5EASGDro+x0/lzO1J97VNFXoqp4RMuykvyQcPwIRALxfwITcb3JPLdno2+v0jIRWxK+ASKcfOhAhPqLsEaCsFYOj0cgonLzpc658Hal9HLl2IhaVYBshJmIUnowMshElkfQO2MIShUwPFbCwcMVlJJ4OKtL69Uf3z5X1p8HZe5jn5QZDL45+D/ffBB89kXFembpPbXtPQokeNHzuy7/Pa3gKgD46lKlL94cF5ckKlZnZpAd6kB3Sw7loAvdrIshwabQ5OayeolG3QR1EgITmIOqmC9vKy6rzcLD+cHwqj6QFpmZjAMTfsVskaoJzEQoghwjcpMFBQibYMJGkd+GRhSYd3XxqcfaCLmbBGz8xcn8C91o9veQWY1xecl52AUeEzJr3ZyEEM9xyvtoK68i5omivhocIBgjZWrWrtmf69RIZnoD5fyCTHQnlvAzDYxyLEqEEcm+D4g9ieC1bGMeztp491BwtT7U1w0jBp/+5g/j8ibu8xREEq3EAoEdeI38EB/N5Q/Mv8m44g4MhHqO5vIgZWeq004siLgQX7uxiOxhhBZX9iVdhCrlaUW5ImENLcjNtzrn6jcppY7VxgyUrjjUV8Mq6yKdVaUqzhex5eFrU4BrnXt+WtkXT3WalY2bcb0r916jlXqGe6y1AXP7HT81fMuzPzTTtLwHdrrHgQTginzhkmOfVgAPA4C3LV1/tfMRrv9+tOgl2ARrYHIqN49Z76Uaq5cQQwHd18r0zZAiuZ5vYO67rb2NM99psgfMBP+uuSyQNdQ2KlK8R8xw1uHmYglc3qEGM7EIR6N6/dK1QpH9rPFPxfNx2okbNnJ3WaSxZigI1/F0xeOQ+y2qv5gWahSTJjY3efniP9uTHtMZ0vb+tkTNhBgzCaucPXP2t2VKpuxk/CvVXq5kHHjEttcdeKz7Ko3Coj38yQTJiwHEBzWygs3jtrY8TFS1l8f2Vx66ziS01/cRCQa2dbPwo2lARGZbykQifUWis1yioXVnkeDO4joyEQKRJYC6DiK04Gh2tnl91lUH6xpBRPJFMskXqRS5s1QvGwyr1RFnryehvlhLayOJh6/c+/NKq78MJ5Y5cuQvB6+99BfWb//uuT1OAiAB6D70tx7czerPgFKLmxrFtTMJCcZe76FeYoYUyQUVRnGJ+K51PzMsvpvV1bOKg9mLAbo7+W0QvSEUwC0zcWv/BEwiZsLvnweTKMzWMYdYwA/BhIy8OMwC9iC2f1K+SRzVZcEizIh3VidmMEF0VwyoFlrseaRAZSc1q76NDoitoCJ5KRFTceO4t4QZD5mHloz6tV6mWVEk3a/9OCHToBpXBp1V4uts7LJe5mHbyEQ3r6WPSeDqEumDkx6Tm566saiQQ1QLaw0thOZzXINL8mmcGyp8arzKmgAinunYlZGIcHIMm6luZRgLYBiVJf2pKPlQ2uVK3giOVRYrBupKjk+ANsrOUm/O5tXXSRepzQAckMCqqqoB5N1VNayHkS4yXC6b5eEPGoDLsEPxupjI3BV772sydZNSwJGieLcHw68OPnHb98G+58/YbmOt+X9ivj8pgAQvbf7iy1+kNfypMeYOpcqHLs1cIRhfoisUXHahAhcSPE4vqXpG9Xvk4kLgQDAhF5diF5dWfXN06T7l4f6LXFhwW9guvktWMKGpND0zCfwfkRtKFmGhOBF0W2zXTUjic73gQzeUbxHYyDmh2bted1cL6HgOEp5zGHQWvGQumZJn9ThQcV65cS/omPcWQcYC4Il5b6JRaypEOA4s7KbJq9Zc4cdnGtIG8d4EVzvefeUOl7ifotPwSRwBaUlvchKRxU8qYCH85Oy5xQDC30XnEkRmRbW74mz1uIpvqP20gUjgzrLCuuSJUGVIm3BYLhtTVZ6JKFPrM+Ad+Rb1eWXqQa0ycmNRvghFaWH/9WqgTDWktrmYL5LPjTZVFwGA/lXXfVSBcc2pTFXW5R0HH12+5Tmfuhum7aYe4qQBEryqxV2X/z0ouNTU5gPLN+z52dmvNHRxHcQZmEH/Ag3HD3Vg55acSqhgfgkWdyTxve6bCuYg09RdMcOfAHPamD6A6ddHVu5XHuu9ACBfCJTN2MhHzITdpGGnQp//0ZZnMoaZyLvbFgLsquimLXHXCBF2b3gzI17Y0sToLoKd2EbzdToFIDqf6LrsmkvGEC3EZ+gHoDLB32RrakWhxeFMGb8otEyGqwSzmVn3z4mT0p53C2i4PiPuTjVHCt1WHC0Y5KeI6yoy0cEKnj73x52KgdCTCKOxZPAGyI3XQniIRm95WQfR/aDffSU2Pp5/2GG0GHqKk4x6p4mE4cKSsc63xPZblx7r+GcmQKtUhdV8qzIAETB6q3l3vl19FrPWK52v8k8R17E0PLqzUBfBGlphvsix2yro1yXcuRm6yHW/qZV5fTRzDx955eB1l/7B7Hbvntvz5AKSi1680+j5zykFO+vKvGDlxj3vmP3WtOglwzqHMxcyUKYDCjrQVd2eKqUeV903WdZH0Z3Ed8ot0X2tTR/ZSn3X8gPKpf4vA+RzXqxOAIAsU1Dk0TbFcuK29N6IQnRZM4nE/KSrYUObaZSid7bZG2nRZXz6wVraid11krsrOU4MYvRlaMpiHSXYN/bKRZY/0lTYOMYMp3VCyBAcM7sO90Lorho309bxipAwHo6zxr4N1sGGfDLzsEgS3OqQYDTa2gplcKc1hqnYCKxo8yiDPEYq24QqEtTTEOIgyZBPO5weUY4Ii4v8tYsSmwQidM0koJOrjDscZvyTPlOqKhIQQTjbCn+bbzefhloNKHO91oMKfyouhaK0HqgyG4zMKof5Fj0ufxKWQIl0kfWH+nav+MhFOs//TQH07WMxg+G/Da76qR+a3d7ds3uu4y25e050/qEvfYLK1D8pgOWyLi4a3Pjmr8945NjFFeolvYM5mK0dAASUotetVJeTFRlMkJ1gIyxyd2Ekl1F9MNCv7zx2Qbmy8DyArDuWmXgjKeY+YSY07zhayWsu+Pb4kuq8hEv1GLtMdBKGs568fWhwfVQXaiM6NK5Bwyy3QnfaT2jsY3cXaRxy3vw8Uo3Gmz9Zl8tSNM1IH6ulJIzIRW9Jzpp75TC+ekpwCZhNJF5IooYrwCjRYyGhqAUUxu1HpzOGgbRN2LR4I4OkaEfTgIc7oB89Yiwt+SgtobxNBhIa+NAcNJhK5Opypd/tbUhcWcyIXBx8XDTSiQlyvKDeje9sKDeIWIdjMK5NLp21BRF0ZxExkRpaBpnIwJiqiMBKL5q/z89SHwMDw9ooFtereoC5IoA/FYvro450OkQgWcb+Ilta8kVm00Xgir2L/Uz9p1LwIDeji2Jgbv3mQ0/mWlpr2eCTDkjwhOcv2f1WDerFxsBnlkdbHwVfuAJXBTP8w5frFU29pN6WAfZ6x8z3OejAsGIXF/5nMFkRXV3s4iKGorEcve6DqZCZPKRcWXju+Ox3myxL7q0ZwISttFubJRV2E3YySTfx1n4q7cRuPj66y9uMcNEcAkrTvjeqEMf8IxX2k8DJQNsR6GowlnBWjNVaZpg6M+8SZJXH5yZ/NU7SWdMmVHjXkBsqcV+F9pv3H89AWsSoFh1knBuLnz4DiAVBO1W9q0rCFgNBPQQ4q4c4EA6SHEMmgggvbIg1dN5BGlNFTMRpIvI9gUiDiSg9D/+UnwUfBVADEteVGVQm88mGlR5Q0iHqIujSQhABU7je6+35IuzDXse/3pX73qsVuPqCuNCrDh7+xeKNT/uLdQxz0m16UgIJXPSyhYWs+owC9ZAazJ+uXL/nV2a/cwImjwUNOy7kRliYX4L1uGyyIsx1YHi81837XYOsBNlJjXW5yjmM4MKwYA0cyQWgevXBYxeXg8XnAGBXHOfYToRxu1oVMLE938X0kzlxzITBg//vyvO0gAlvFoPJWlFdwiycv6At74R1D2YoSd6IT0PxcrqNwmpnKHySDbdXi5YSEAYf8RJgS/S9B6yQBzjnlL+/nii0TRq+8Q6WJtuBZDtO5h8fC+w0l5hpRJfBsbR8Zg1CY1/HJKR4be0jwPjk14YGIgzEXUZwzKhGVniesqwZp4XYixkblWXTncIMpjhTnvJa6DAMIjRbWMTyLMT2FwndWbbPCO03FkQ+ku/ArHEzrGthIkpzBjvmiqhqAPj3qBqOOvnQievFcgkDXcJCXsIt0nv9/K/ZOlqzgMhureDqcFrWx5c/MHzNkzagB89uGTdzz5MTSKh8ykt3gVKfVKDmTW1+afmGPX8++4WneslNLL4Pihy2H+9AvjOHclUy3yWSy9RcRqUq5rAWF6Beoqo5g02watOr7zj+8HK0+HQAlbdqJmRM28AkMfwu18S6svAqrW4SaA5Jpvp43QTt0/ick0Zkl2jnfG/HRXd5nItdaGISWbEOVmbj3V5ynKR6r4y/FluxEyAZftKq0E/w5PRmxBLv5Y+E8HbIcmgRfN1441pYB2FBeOZtbisHGMGI4eBBJ0N/+FYGQkwjOq8xeSHukG1ayARBPUoypGcdMhGbKOVAhF1+FMLBLARvOmWmB+4sq4kQI0GmBMREIIzOAqP0HFyX71D/AAoGNVRDWpNE9gAAIABJREFUZbJVzF7nyCw1oL7rCCJY0bdTDaHojCCrR+TOsuJ61q0gqqP1B+uu6tv/g72Pgo7aqwAw2IfftuHwG4Obb3kYXPOCQ7PbtpNjz5MWSPD2zF20+9lZpt5jwKwCqEcuX3/1DTPeNq+XHNyhYMdODdS/ZJjBAuSU+W4jucpRl9xcope4sGDMLdHG5ZiAAgSTi8vBwjOtm0sYeMBMbOY2GjEEB6l5xUaMLJs4Ivh3+r8FFGEmAkfuuqP2vTwfAzsRMAHb3yTZxDEfPnZSTTgGk4kMJXGB+XV6QvXX0lISpuLesjW0lRBUWkHBcZUG/NgPEqbgCMKU3wuzaGEoDaYRjiiGNJzI7i1MqwineR92ekTqesCQKD82rK7LR2mWePfGPDr9JoDQ1w2mIicvtbK8FkITJo7KSjLV+XzcdTVAhAs7agERmqE+Mgt7irBmInW0MtJJ0N2GmkgTRMxH8x2amYgCyRXJWBdBMMGEQwQRLH9SDkbQ2zKEldUCXOb6Tm6Zu0FxHa745M65rLw+KoFSlmV1252PKN7+7JO+IOM0NvekBhK8gPlLLn+jBvh1KqFi6ofD/tcfmebCWrZpiu+LZ2iwkVzdypdRyXTXFBIWjO4sqQ5MiYqYa4IiPOgegcmdSxeWy3PPse165b0dAybSw4TediptugaYeFdXpDUkobtTsROyX6lRt04W35wrCO2NMtajwIAQv8QhF9/v0N0XfrMWU/FAGk/MwN3VeLCtTCg9ncnurlkm1Jpvzhg3lcOUdAArhrUM3NA9eJa5f23uqygKK9w+1TjEsrtNvBsrYSox8xEZ21ftTVhTUrk3YSFJZBZfoGHXFb0azMgsiAi4UDl4jgSjtrk6o/UYVvGNMtaR2yyYD+Znmr2gMtZEKoP1sVYrcm2pVdDVQI3qIYEIaiIwKKiGVrlaugitwXLtW+bOKK5f9r+z/kU79imlHmWfF+kidx16fvH6p79zlql3Mu6z5utwj5/0w17Yma/mr9VKP8oY80/L+/f8zAbOaXwk1+BgDr2FHBagA+VQanJVXOBRIWgUcyjEE4hoxcwEDIPJXUsPKpfmnguQYd6JDXifwEywvwYmwrI7mIm8XeXZwPumqysuOR9+z7+LCeCBolpd+GfagVFe2UgbsZWOQ9BJBO/xGoqLuvKXIprL5Ex1gaKEyDgJYQrGklILN0FSkGmlLuuYTun+/ADHDuA2b27SmucRgQxzgXjsdvDwly/nE0ymAG2sCyjAoJiB0LSxiYUOWFI3Fpt8flppmRO7UwKKwohYVAjHi0V1UWUIKBhRXIdDLsCYCOsOREi7cScMeqt5X77N/CuAGtYYiQX1AMN9KVekFlGdNJJ6SDW0ymoEmYT5jo6XMA8lHOxx3/WvfcKAL8bIl7COf70r9/2xVvDb4S7m8NE/G7zuKb+8jmFO+k1PfiAhVvJr91HQ/awCOMcY+J/L+69+9ex3Nonk2rlNw3lHubPiYJRDdlxqcg27vY7uUs93LD+PzAQTFY24t3Qdg8mhpfPL4/3nctIiW/KYKfCii1lB0F2RfvcFIWmrSDexBn9SvgkPzbs28i4CSAn7zUfvg+MVtA50noeICUQhWbEbzj6NdHv/lDzIteV5pOcyiYGE93bcLFhr/9lnT2PPVqMdb+W9kxNet1bW4Y0jT6k0JNceJ6yFlexjo5+iQwcAJb86AIlP0f9F201KLuQp72HVgpp/8s38EJunwiVOOVrZ5RI6VoJ1F1knyWmCUxWBuoaqXAWo6eWx+xm9pf67fBv8O4IIaiC1BRFyYaE2gr1FkIn0JVekO4LVlYJqaI2yEvRyBcd1CUtHajhwS70REOleed3TMmXeG4HI8upnBq/+tx9abx/3TZyxJ2SoUwJI8Mr7F+1+dJapa3EylzU8cXjDng1UxgwiuY7/jOLOiqMMKCy4zqGzwOJ7p+h2q6yLYcExmGA9LmQmCZgcWT6vPNJ7Htgui6J3eE93CibW6NtOhT7/w+WluSq6YoBbo7os2Fgja/8ODHSUxBhsPyYzXt5sP0DQ/MqiFpmK9PzcNLXGvJlQyCvoNC8lASM/3T1jGcs8HLjYvAyXad+iYCQvUrKFTXWf8nWzezPDsDFdY+KQI4ayBuMQ2xjWvmpcvi2e1QCzNvcVDchbWsPbykD8Fu4WSJ5HpIVEvjXbgz0EsZaoLH9sOWPfEZE/oAZUERPhwovYd0T6iigNdV1AXVApqoCJmEpvg/fkW80NEYgoNahqARHSRDDEN2MmgqI6FmI0dQFDxTW0XJjvzho2EKHVueqjP5hBtk8BzLn7OBodWv3Gf18E73ret6acXqfMZqcMkOAdXbj4pZcrrV8HAEehNj+ydMOem2a/00Ek14GDGnbu0B5MtuTQKQVMsi4lLKqqB6pHIjzlmZh2MDHHVs4uD+fPNVLo0WoOvjkWvSlSZkQEeIqy4n9WnnfruLbkRRfVFZa299Fg07ATHr8tuisuaxIzFDbYQS6iAxqGSPvnGN0iSpoMn9w4TUWO13zInnKsy9FgByK2GHr/phDaZ0xS8UZ7zLuWfNza2TC6AQEYhIab7pXvo97GQNYDII60pG6s6bSQ4Mn5ycDHl9WUgAbXiGzoIVILkvuIuB7rCupqBHVJaWUeRJQZ6DPMX+Vb9BfJnQVmSO6sBoiIOwuF9S7mivRGsAwF2EKMBCIPruDA0Q2BSP+KvfdXmfo3UEDFXuleVFUNdx35icEbn753dpt18u55SgEJgcmuy9+tFPycAfiGqvQjlm587YEZb6/VrxU8dp+GHUEPE8wx2XqfjBIWKZprCjDBHmvo/lK6a1aXzygPqOcY6J8v04iMbwNMiF1YV5dnJ8r4zO1mvonVRlxUl01ukEPZ773RDzo8ekvqDDC3o3WVNdoEeQrnZ2PvSq6EnQhjdJHxwvNoAYQk0dKaRLfCx+ON1VbWoCYW1DxFWKdne40ZlY4bcJFYBU/HaXndJKqJr3ssk/HhXDRkOI4HD0q78IcM8lX89i0Z6emANuPeZ6azKYyqDAsUR9oEO7bcEigQ1G3dGJvsKK4siysc7iueLXRhZfwNebS4PS4FtZcDMHUVaDS4rTmcnQl/kc2rWzk6KxtgwXjSRKw7C+oh9RWpRqNRJ+O+IrBaUMKhQjayo4R8qWrmiqw/zBf+6MPb+mXnUwrgQveyYSrZXYd/e/j6p712Rlt10u92ygEJfPev9xYWOx9SCh5jwPzH8kF4DNy6Z3XGO52AyU4NCwfihMWuyaEadqE/3+kWZc9kvS67uVqYCYIJ1D2oVc/Uo/nytuopxsx9vwOTSMMImAmt8i2jYGCxjiz3ljvdxBplu9Br0U5Ed/H3JEwybHN32dwTOlprHxK2JW1RXlE0WPpHEtIcPqXoPBpCvd0yMIHiN2rTWDw+zjgPWpAustbrGHbCK+VCYfmpTiBTYVUqOXYKHqLCxeCRuK/kOMJyOLQ2upTgL/vdGgzEZrcH7KYJMkE9dYrEstqKlDsxXC2ZMRFzWOifsJKwRa6UPMHIrAL1ENtLRN6KHG7NdsA7s646TCCCTISis/LVCn9HTQTF9qIeki7SyYZD7LWOTASWGUSOdSpKOOxtq+D26w0c3FHDvsfKCm/SXGuZEi98W6d/3gX/rBS4ir40sQ4deefg6kufv45JdMpteuoBCd7ih/3WdyxW9adAqQfVYN63cv2ep2/gzvOreAUo2IfMBHNMbMKiZL+HYBK5uUaBAG/6JlM9Dg1WPTCqa6qqX92++ti6XnycC8yKOhrKy0OlVFqYCZtlp1/Ku0v2h+vtiuGn2ZpmxIttDFb+vJBOo7s8c+DvhaE4KAvNnYCMrMiZoSTlUtzmSWq7q7abZs4nIBCIDmnMbkwEZE1sM9qn7gXhD+DHb1AMp3ZY1cP/nGamSTNNLmyYVvFtG4Dfw8bb2MY8/Hh+oED7CKQXrsobMB0/XAIndP0ULRWBWxPOYgZCJ+CZitRGCFxZYVSWYJyjHtRvSnIOObzXFaVnTYTApq4rqKsBieqeeitQ3foL+dnZexTUK6ARRNSQIrKgHlQUqUXhvgNV6QEykRhEVAFh1vpmgAiVhd/3ZwogAgyztHLt4I+e+LhpZs2pvM2pCSQA0Pve3d/d6ZAf8kxj4LXL+6+OQuzW+VBaEhaD7Pe5KodWMBF3Vt4hhkIgQu4t1dMIJgq6GCJs/vv495ejhUs57IQNvI+ucl4LkcNlMeTcW5OiugQsnBFtYyeWJMQJhC3RXUnIsAWmCQxFDm+xJKo0bE+Nr7ex+KaJ16qpRDva2xWA5mRRJIQE5+iJsGOdq8xwIln9IjH6E91SjYkoRnsiaIiBln1tWkV85UlocBR9xSfIKw53Ai3gwcfhcYOyxYGLyk7XOBorBRDaKrixCApNFiIhV04PoVZbNnNdelGRGwtzRNCVVRVgUAvnNYO7GN2vP57t1B9UCgZQw6jOzFDVagDGDClPRNm6WRkzkcyMPBM5QSBy5b7fVQr+MJouq4PPD7781UfCNb+6tE57dMptfsoCCd7p/kN/8zFZpj+klMJS8C9aueH1b9/AEwhyTA5rOP9RirLf+wtcSmUSmGCeSY7uLAwNxirC2CRLwASBBNnJ4ZUHVse7zzKQb7HWUW6+2Ada34sIjx8hKKBWYrWQeCU/nXbC7ba80Y5FcFkGJ42ofA0wPs81GIqvxRV4xwMtJfherrsVVKIe763sItnNgUMMkJOe/3p4xzS8ZfyxHGWL66i4ty2GO7kvgcmnkh/cLyU6SDvzILMe5H80tZLkTNOMdPt1g4GE0VjWkKdaSSDw26irEJyEBntBXTLTOUOdlRAGDxeZhReNDQqhrvm6HIiYSm+F92fb639XgFoHMBOBkthHhVFZlokggJhsqEozGnZRE1EF/WeZiD5aAZU+CVvlkvN28kql5aF3X7H357JMvTsCkVFxm7rllh9a/fNfumUDNumU2fWUBhK8ywsXvfQ5oPW7SYurzZM2FhaMU9Z2V5wAJoEADxlGdKE2UvUIQIDdW9gQC11dxExq0zMKurC8elZ5l77MmP79YzAJQ2TJHeBdXRFPIO0k9j6sqZ3wmtI/6GZ0VxwIYOduuF0CKHQGjffNfzBOS2mACpvAxtsS7M/fjXu513jn3dfTg83ab669kzbENvCCte487hULExltM6fGAA1RI6rB5RhSWiurrTaXdV/ZJxcykNSpRhFtcuLp9fLfdvXjb7F1Y+EEpVBdl/fCZU3oOSpmIfg7uq+4Ym8AJMqYikR1nx8iAKbhqN5evydf1F8DBSOozLDWGqOzhlhwsSoxNwTLnnQHKkcQyYfYm2qYdUcsrC9MABHMWv8C+rfxctYFJL0rr/1ZpfR7oxpaZTGsbrvrh+8t5U/WfidavLLT7HSybTN/yeW/rwFeCcYsVQYet3rDnn+f/RzDhMUUTALNBMGkrzq9CsupVD3T73aNTV6s636mUCcpCVg0lVOpe6BU14yKufqO4vFVNf/DoQbQmrxIb6xlJGgMkaWwj9zFrsrK1dbda+R1OO0kDBVO3V1sGmTxKA5+uYO2IKN7vSYxFGti2HDTeAkojHd/OQDztilUKiKNxW67lvBuV/4TZoOlHgF+Ti+ztzGL9FgxYEj+zDjGIZgf2HA6v2AZEAjnbKvXcF/R91YrCTWQmFkIYAcMwD3BJFqLkd2DiXdjsTvNYR+jmxAQmgaondMHnBNio7Go3AmypKqg8F4v5Aln7sBX9I76b7NMH0EQUaCGLKaLO8v+bkX1PBuqqh4NMU8EhXUse6KwCONKBSkT2XHQwDXUbz3Ax+msR//KvT8BSv2jAui56VNVtbnr8JOHb3zGB6cb5d6x1SnPSOxjWNi1+8+UUs8HA4fAmMdsPMfE9jFpARMMDcY8E2yMheVUOrprRISncioUClz3sxx/Vz1Tmb7GaC6luggo5Oo6sHxxOZh/CoDu8jVIpJbrCCgpAW6NlOZ82FpdfgHVbOdL73zgHrN/ByVZkqrCcipBqHIw0RM2NNnt5Y/lRhgLKoEVbxKd1hWiM+Ht7EgGXL+bYv2v9bgSKbJyn/yGtTAOB5L8KALW4SxdPGbLEXym+5r6h8OFtNaXT2oMnk4CIHRGsqqxLITrZAkEEOsgFoKb2gq+hCEU4oufUdxIXQ3JleU1Gx5Bz5t92Znqw0rDEIwZIQsBDOetzLACcWV11AAK0UM69XBU1iNQpqBkw4X5AsrlMo7OGhk4eCCMzlo3iOSv/NiP5Lr+FwUglSw4RN4cOvwrwz1P+9P1z6NTe497DZAAXJEvXHL0fQrUkw3A7eXIPHp4056vzP54AmbiKgaLAF+v+gx4BBMwnR66uAhMyh4lL0peSUaiu6Kw4MyFB5ue0bpjjq7cpzycPwtUd4cFk6abCR9RCAZBeRUxomnzKLvq57eel6TemLdFd63FUFres9ZaXhY82jxW6XlYPuZBzbOV4HihWBE9zBaXmIUPy4Sinuw+CdEmI04/+cP+IhI1lfZ8twysdcJZt1JyRIeG8echeFhCkqBp+6lHZUzIDPPZMDWMmIVD2ojRyHmGDEikcXt8pppJSC8fgEu+O4bMVITPn+awsBB0ZeGf6NpSylQl1PWoEZUFygz1Nrgm26puUsaMQHOiIYrryEQ8I0H3lhmCaCKj4aiAhWoEq6agjHXMVses9bxfxSG+s7uzOq/auyur1XVKwVYHsgQiR/9kuOfSl89uc07dPad/l06Fa7z/L/YXtm//JwXqx42Brxs1etTK9W++bfZTbwETm2diwWRkclhQHQDV6Zl+x6iVnql7XdJOUHi37ESZHuknOutSromI8DBa3VIegCebeu6h/jzTOl2BgbY5J04tQWAJamiJDZZXmD0NbtWe5p7wuHEEb2jwA7bjwCg0abJt8BH3QrH/bDZMK6mIP5S/ZB3P9q/Rf102ah0ufMrjQWb2uTDVnk2G4W5F4xf6wIOGtfjipI/ezBbNwyIErxZipuBOtd19haDSGoXFN93vHRRYdMzG7Rm4sVzfEAk1Jg+W1cglrJeFdemvjpmmyEIQQCoCueh8MnN7dia8J5uD20GpkYvMqvQQdO3dWqUZKqOHgK6s1eFopOsRkCYCBRQrDCAIJA0QcXki8rZM9Wxpo+4VH7kwy/OPAcBZ0Yw7dPitg6uf+pLpR7p3bXnvAhJ8Ng974fxitfAhUOpHAODmJa0eDZ993Z0beGzN0GALJp2edoUeO3M5tu3tlaOugW6HS6pUPS43z4mKxE5q3TNZ3dOV6oGGLijTNRV064PLD68Gcz/N5eh5fsvDicy0EwOtrUQ+HWzP72RkaeM8FKn/xfu4BlreGtkblTIZVyU4zNAP7mpDS7GMYy1NJbBb9rWWlTprADb2k6+pHVzs0j4UVSZShPDEkwSOaIk+3bRxzMIeP/zADxGDBl0NP41mdFYcH2GHsKLIOObhtmuK5zJHAmpqX/00Cotvs/0/z64wnBc/kGZTTgThXTD8ilculvxgcrxjI6BQYMfcEcoNGXI9hKTple7Vn87O1h+k7oUoqos7i0R10MPKlEMF4t5CEEEmUtWjke4wgORzrInYAoz54Qp6D25LNrSzbbpnjCkHr9773brU14V9RWiQI0f/ZvDapzxn6oHuhRve+4AEH9Kul56xAGqvUmqXMXD98lLxWPjKm45t4Pk1kxYPHtDwPVs0Vw3GEvQmh848N8iqRt1urrum1sxMSDepmZFYEV7lXV1b3QSQvXTNsdVzqiOdpxnofqcFB3lFk2boQRSSzYhn94XsRq9z4M4ib0TQ391+FTAU91pxBFm4LnXRnDS6GHS2NO0UoQFCYeZ8sN9k4tDkHSmkNoJjp9FE1qQzY6ZJOzikGzfBwlt3dgu1DT+OccgOAevwTyCIuuJb2sKGOHIqVnHaAUTGdWeXurB8Jr64seyFEPOgQ5MW4nJFhJWwS4siswhksFYilTlJKwVrs6TPMO/NFvXNClmIQRcWjCrUQxBAVDkCZCCqgyFdQ4UsZIAuLzMaZWYEA3RlQQFdXQKWgtedigow3v/BFQyP1vDl4ybIWF83iMBVH/3OPmQfVwAPCJ9gffT43w//5MmuB/sGbMwpveu9E0gAYPGil+00uvqYUuoCMPCJpTvN4zdQSkXe6CADHgs93u8SxSXoBxnUCxlgc6x8LgeoSYTvIqgQkCAzwdIpnS7ml2QsvAtLwTyTDEX4LorwUBVz9e3Fj1X13I9wpx9vq5s1s2x0lK1qYiO7+D0RfwcP4LAjyZRfF0NpBw82sUnGvH0t1mQqMqZLnBhn6GklnAAqX5dbqEeEJGYy07yleH/HA8GkEUINxZ/P+kFDjuHcSzbaqiVkV1YY7WfVlv/hHsjYKKwYpHwmOXVIJDRyYVi8jODoDmEvNrlQmlLZZENCGcxQL0my4HkYCvsGQ1Bu1mfB+7IeHIEaCtRDUBepiXFUo8ooTCokkR0KzSCC4b2jUTFEdxbWzEI2MkJXVlbC4eMVQK/iUvA7a9gSgci6VxL9K//lAaB6H1IA3x3eb3Ns6cODP37ST82SezLNfDyVtrnXAgk+BOxjok3n46DU+cbAh5fvNE/ZFDDBlwcLPR7fogD7meQ3Z7Bju4DJkRxGCzkoCQ8G6JAIj4BSVj3oqS6UuucABeqe1jnrJkZcXTV0zKHVB5VL3UsB8m08oSwTCHNOBN/ESU6Uw7EBa3Ob0V309gtDYS/JehhKuzBvJ71YlabBt9fgSrZE67rE5k7UVtrer+mMg/VaJcwm/LjhpQowmK3n1K/3dFtGCerjtI52EIjPZC3wiE9ebkHMQAIXVpOBCHIR6aDdlO1oyCzEAwi7wjLKGkHXJIf00txM+5WUehH+OTvT/KsyekSuLIUAYkbkvlLlqALJFTH2Z0aZ6qOyMwI14MKLlCOSl9xjfWcJ2NnQgogrBT9DAUZ0Z1157QVa6Y8CgHgJ5G1cWv744MO3Pg4++yIEsW/7f9NN9lP4NvUfuvv8LFdISe8DYD6+NBw+Eb7wlo2ULBCv0SsUPBY0YD+TnQc0YNte7AG/fUsGAympkvcpRLhXjbomK72rq+52Ia96ptLCTtjtpZGR4PoM3Vxad2BlsK08pB5v6t6uUDJpN9boWZDS6PzSiuspAJSwIKNlAEGyIo9r95OH7mt4kffCZco725ZsH7ibJjIVx7Sa7ijej7UVr1gE4OISKNYzMd1I04FO+9Dy7Gd8bawYEriqYhBr1LoaF20lZ8fg4TWW8LwkI5wOEDkqPaK4PJQwCksEcxuJRVsjMZZoNZtdSIBie6hbVsLZ6QgrOE+QhQD+Z2uQMv4ws+nAN7Pt5v16Tn1LIZsw2ruyEFDQnUVurWwIdTEiUV2bEekhmYAIRmZ1VQmFKuHYMoNItrWC5ZUavrZqfD+R2UCk+8rrHppp+AiAceXg6Q1ZHvzb4F//+7Gw7/nUFOX0v/Wsr07hu9W/6GUPyHX1EWEm/7EM9U9uoPe7vA34htpck/O1AxMqqYJl6Bcy6Bh2dRno9AamY/Ii0E3E1QVVL8NkRYzu0tDNMMcEs+BRhEeGgozmrtUHVkudJxvoSKSIsBM2Ek39xLnB006MDBRpdjwZiahke6iRpHkoshhtSwBuEejttPHgZ8GqbUKl2fR+mxBc4j3D0OZJY99NEzgCCzqfCHU8iiUah7tRaUZ5eN6ieXgocIDit2rN/4j2cPoHrwHk/FzFtNiFJUjHmSk28sqCiBXq4yRDDOk1CCB0+UEHQ/qgHupFjSzkM6SFAHapwnpZ+VBRoxEGjNqgK0sPoTajSA+BYQH51hGUw5IiszAqCyv4homGUXvc2UCk88qPPyLX1T8DwBnhEzArq58cfO6/Hg8feNHK3TSjTonDzLi0OiWuLTpJatdruh9WCi40xtyk6uzHN9DLRMZuy4KXXBOK6ApE+LyXQ3ms24VeB4idoLsLZZSqB1XdM1p1STsxeZeiumpmJoD5JvizKOeqg/WP1mXvkQDKFX9sL28ixt4mwNucMef6YvdUs3CjWBahAp6h8Hh80b4PSnATmhNiDVBhQpSCYPTK8urVUqCxPAKZC67kUwYTGWC/91g/VpoYEhS7iqlR62W3D5swjPQu2QC7yL2VAAdbYy727N7W5LVtGcfafwYNpnYsuWEStz9gkMUTgJ4v8Y57EdN1uSAsn0txRZsfwmI71sYSHaSNKamuuUmfqf5Jd+EwsRBlRqiFVJitjrkiRg+rTFxYCCDIRiozUshERuD1EBTUSxTVpTWuC++VREPKVp+t5AnervzKjz82V9UHFMBiNCOXlq8d3PDVJ8L/+Y3hqWcBT+wZf9sACd5GEeCxyOPFGBpcVcVPrt74pls3dotbck1cRJcV4UU3yWtsOt3p9XodUyE7URzVhT/J1VX3Mp13KcLLqG6GJVUQRKiKMFCTLXN0cG51VD/ZmO53hVFT7e6uSAvFpC+yJyJ4ustmhhJYavpVWuHKVkG74GDDWUGFx2+Yepc3spb3Sdxpa23WeLAx2ES2OXKj8Y7jwQGvewyjaJ1MtvCgterjZpy8jkGzK79l4rayXzTcVuI6ct/jmsECg2dHBAzW7SUFHx1SSWWTiIE0dBCJxgKlalMxA0GQavRtpzXIMb0N/iHbChyRRSDC4BGBiLCP2JWVjxSMiiFmqod6SLZaQX68gluWaorMsr1ENggivSuve6JS5u+iFrl4L48e/8DqN1afCtc8Eztrnf6X3IFvKyCha9/10jMWQX0QlHokdlksTfn44f43/t+NzYwETGxE1+LBFt2kziHr5w1Xl1ZdQJai6l5Wo2sL80+gq3XNQIOAArpjVN2FGjr1nasPrwb9HwfI5q3ZIxPSvtKn4BpOEWPjb/ucUBqKZyDNplYSdRV62f3vob7RDiqpsW5k2rsb71HBXUfibpv8jORI7no4paHNA7exZx3s7ZiK7z/iimhNdZBA42iv9huMIm43KwqOAAAgAElEQVQkr20FYBcWWRQiR7fDax88UFBannJYZXgCFeu2kuNYBsISizAQEkYkqRBD3CrWQUhHYwATp6scztS6B5/OvkN9FDSsWFcWCusVVAUL6mZUYagvJRaiK6tgBlKZEVT5aISgg/+VgxLMfAF6UDk9JBTV48gsuw6Y6inYjbqvuu6Z2ph3K160uX/10WPvHf7Jzz5jXYN9m2387Qck+IAvetnCgq6xn8FjDMB/K1A/sXT9676wwWcf55pQRJeI8KibhJnwpJ2gED/skKurLrum0+mYumQA0cxSyNWlMcckYCegO6ChY2rowGi4WN1VPboe9R4Byvc6IZPRpp9wxUAxKS5ai2O2wpyOVrcX26EQOuLEx8T1Fb/KYwpSWSI0Lv8jBhcfwhxuv25a0vKY1+ImG5kZwSvWyjTs2Omr2NQ67JZyxfEOoXDeqn24vSXfJEw74agrm0zIEwRF8yBZUfqGUD6IqSMA8UmFDFb0/279Bb0dPqx7cEApXZAWonTAQjhKiwT1GkakhWAoL7mycu/KqgYlzM0V5MpaWq1IEymWa1cCnkT1h9VwDc0OG4287knRv2rv7yhQr06ftDl85J2D1927uxtuZHaPm72bMeapMcZ9d88tfAe8Vyn1BDBwuKzMUwef23PdBk/eR3RddqGCr0nBR8qEH2XQuR/rJotlBiOQnBPV6SnomK6iMGEClUx3KecEhXhkKhTNVXVRRyHtxLq57M+VwVnVYfPjpp77vjS6a0x+hzAUsfZCVLx/i38joGgUanRGl93m7pVNBXp7J9uYis27aLPpdsDpwCVMP2FvTZJ/FzmoNvh03e6haML3g2235H2ENb6iQ7aKLV6biDLX43MdBx78BCXdqCGcu2cl1j1wZ4m6wXBlscXVykoYiC3hGwII40XCIzF5/b/0GeZfsi3ZN9DfRVpIDYVC5qEy1kIsC1GGxXUCEWQgqIuYQmWd0VCpAhBESAuR/JByUMPBfgX3x7a4qR4ym6gOV+zN+7l6mwL4pfCOSwHGPcM9T7t8s2bNvXmcb09GYp/ow17YWagX/1IBPMsYDDk0z1/ev+evN/7AW3STpa6C827OIF/UUG7JoJrLoHPERXXBwHS6GBTZQbbBYjzqJxE7gQxdW70MtRJ0cRGQkBjfQUZiDq+cVx3PHmdML8i+tc6GFmGb+8CSIeGJIH21LDw4lhL3kPf3x5o3qVPuvpgaVFyI8sSJ2MhzGfeE1l6IevefdQP6UvdWMrDY0wQp5wWcYoqMu6KEnLUI7cFVNFgHPaVWt5VLQbUnGYQqC1D4fEJhH5ZBuLImHnB8wUdiIJyNLi6stlpdmTmkt5iPZFv159EVRQAi/ymtR1VVFQQWCCLQxWZUBUA2VLUFENx+VIxIB+nxvoUuJ7qynB4yI4i85hNb+qPifUqpn4hABKsQHz561WDPU39/igd9epMwDuTb+G6oxV27rzIAv4u0va7N76/csOeqjd8PAZMr/gCoF3ybq8sUGZdWQXbSz2HUy3udEYb9dkhcd+xEERsh7YQYSk0hwgQoyFY0dEBBTu4u3PfQ6gXVSv6jxnTukwryYzPQuXyr2FCrN2CagpUaxLyNc3sF6BJbvylApcFstMtXaWgs9jiNTPhpyqMIWEYZKvYI0/6cZmZYt5RV7MfDZHjUxvvodguiv1xtKgYBeirx/Qt8VqSRYH0rCsPFtra8vcUL6bPpWIkNIGBtBTUQAhBPO4PoMTk5VS/pBfXxbLv+d1DVyLmxEEyUHlXCRjDEt9J6RG4sBBTLQnA70kJGGMVVQKlKqpXV3TLelbUJekj/qo/eDyDDXiLfF4FIVVbVkWO/XOx52l9M86RPb8N34NubkQSzYOHi3c8HDW9ToDrGwLuWs6UXwGffvtGs1fGuri7W6ZKornqUUU94jOrK+jmxk7rooruLIrWg0wE17EGWd0g7IfCoWEfJso6pLTsRAFImh7rumLuGD65W8scY6J6TsohWDYXtrLjKw2pdnN9BXwXeLrEqwQJa3NT2YJyXlkwyy5Bo+iUUouEGC55QWgNsild4ci2vKQaYsInzUgV+rClG5AtuqYuVvInkrnLbhgMnvdhdWTU7gBPNGTIoSTXAFl/qnWkoudOklwglJSF4YPSVDU5K63VZADFLegE+kW03/4FtbomBaI2l20uKxoKsUMjyyX0FBWWoaxhBWRZKZ+LGsiyk6wV1SjA8owSMyrp9UIOZ6MqyK4Mp7rzfpHPV3ofnRn0AFATvBYAZFUtw16EnDf7Xs7C67+l/67gDp4EkuFn9S3b/RA7q7wBgmzHmumUwl24wcVHAGs2HJC9Sb5ODGpYuUWCjuqDMKIGx7mfQqRlQjOr0EES0yU1VYtmuDrISqKsuQM4uLkMMpGuyrEPsBAElw6KRdceQ+F53wKjcHBo8pFrOHm2gc26DoYzL54jcXgll4KqtshAOflKPeYsNDTeTi6Iaz1jWAJfoNOyDw2GbDGYsk1nHy7GeTWM+IxUGxi3UGlJJ0rkwODCPG4Q1sI4ilMKSBQEPFmo8eMjs82G9XNudU+Et4NDJsPsKwcO7EYMoLDcQADKQefhkdqb+DGTYoVB0EIz/VTn2Cim8GysbVZUAB7qwMBpL5yN0WmFIL4IPhfUiC7G5IQgglGA4V0WlTpCFbNSVhWXgX3HtU3Sm/1oBSLSjwPVo9LX6lgNPHv35z2806GY90+Zes+1pIEke5cJDdz8UcoXJSPcDgC+WlX7S4MbXfn3jT3ycq2tJQ3+bJiEeI7sWRhkMPTvpDQYdo7jfiUEFBQEF9RNkJJB1MgQWjYwko8TFTGcdAxUxGahQS4GcIrqUyc2dgwurlewxxnTOTiv3jmUoVnC3VV5ddhshkEtMYWGeLSTbszTwNgQWv29gouwK3N1qPznHMBePJVM+HjyHuPBjaNMTNxONGWPXpCq9ySk03ixkGDUL4+5fWzBb4q7iEwhuhQUBF+tNp+nwxbIMewyEFbu3BQ9OMFTYkZDBI+ghE5UzCZ6ONst6znyCAERjIynFQrrVQZQpKnJnIduoCnJjAfbOzUagEEwwIgtzQnAbKIa4X4VurEHJZU6EhaCgjgmGo+M1LO/kUieb4MrCK+lfue/3lYJXppPFrA7+ffBfB54Mf/kLB6acSKc3W2u6n75DAAvf95tnQ67/QSn1gwDmYGXUpav7r/7UJtybdleXFeIPL2rYXmaQna1hUObQWcqh6OeQmZwiu3QnJ+0EBflhyWI8FmKhUGFkJ6yXaBfVhd0bEXzqjgGNpVoYUO4aXFAt6Uca6H1XYNRkaTYp45y8W0FitPjgcU8HHFZLCa28CP0OSxJQYVMoXh9/Rmz/muZ9PMDg9jZZMHCTjUOLjXweTQYGiTBJ0V9he+SzZxoBd7JaRdhel26ddSfJ9KHbnjKP0LXFgMfDEbK4n8bUigCNtA+HNlLTy/LJAAV1fUjPqU9nZ6r/jADEANZAKVQGBekgBCgIHHpU6WzEbiz8rCgonBeKAlRHWIgqYIiau2SopyzknCM13L5k4OCOejNYCPzOP27vLyz+tVLw0413+Oix969+/hvPOp2tvjHrdpqRjLt/D3vh/Hy1+FdawaUGI0mMevny/qtfv7HbTXvHYIKurkiIP66hg3kn6OoaZTDfz2CE5ekxKx46XRh1wAIK6Sd5B9kJurzw9wx/J1DJBFCqjgHVAYVlVWrMPxGGUuXmyPA7q6XskabqPliy1+TyRMcgG9dWxoS+Nz7NwLpWHIjEaNIEkAZoxJmDskMLuARr5KmzDbkUzMb/NQcZkx4THcoGMMgVpm6tpCc7c6CAB0mMNRVCtEDjbkITPGz1EgsekiQk4EE90RsA4q8ioC6Z+S+9CP+abVVfBA2lYyAIIOjOyrKCkgqxai9pIMgwKhLYQaFeErix6rLEsN4h9QtBFoLRWMNqbRYyeztce5Goh2SgrlEA9w8fC4f3HnndcM9TX7bxmXF6hNNAssYcWNh1+e+CglcqgNwYuGa51s+HG1+7vAlTZzw7wbL0/UUN3TkNZj6DxVEGI9FOcpP3im5O9VOh4OguTGaEsgMmZ3HeVCTCM6CEDAXDhFVOGorWGbITLC1kjg/Pqo/DD9ZFdxeARiCKDI445FOqIZtJwknEVMJphU6uQDdJQSUFq+j70LEUGEBxqaWZ602CIW62cOW9KanuSf8Rx5tspII9oLAJPLE67ESYookNe7GMA3/WonUE0Gl9VL4wpCcdFoBkG0oSxKir0G0VUJDW2l3o8erUN6ut8KlsHm4BnZVgAMVz+ukBBAqFfUMIQMoCMD8EwYNyRjAXhH/nHJKiHEG3gGpYQkdApKdKODyqQQVayHgWEk/Gdbx4/Vdd90Iw9RsVdiYN/plRMayPHv250Rue8d51DHd60wl34DSQTDE9+hf9xuMynSM1xnLSXyhqeOrwhqu/PMWua23Szk7On1OASYw2sivva8o7GR3JYa6XQYHRXejuGom7q9sBTaDQMSTGY0MtZCsswseAUnkhvoacRHkEFKMyGBUL9eH6knqodhno7GjrgOhBpW2R70O6bLVxrzc74xnU+gqwiQb2OgtHj8k+QoD8WOMIRgI26d1v7LYWUQlej/RNsZaYTjFkJglI0J8Bc7BAFuWPYG4n5ZHHAV3RNlx/12WOu++YDXLH5Rp/aQePcdoH0UqzrPtwg94Cn1F9OASgSlAIIKoEkEgsrUrSQARALAvhfBBkIB5MVIEAokrVhWJYj0onpq8OKuifUcKdoxoAxfTVGs5KtRDLQmbMDcFnfsXefj9Tb1cKnptOgXow+qL51oFnnBbV1zJN6/v+NJBMeb/mvu/y83RurlFKPQIMHK9U/Uur178eI7w24994doKRXbbEClYUTt1dCCglaicIKjmDiQUPivpiYKEILwQbg2I8dDLMO0FRHoGEAAW/Q7eXysDU6PY6z6xku6oye4jvI78OpsIG04X/Uq3h0DVDdy2s7huwFnsYCy7RYYXhWEMa1ArzekrACKZ+OoFWEe0Tfp6ChCvxEuwh2zgvkc/b4PAr6esRRmO5Ye0vYZHFUOuQw2A+SI0UEMN0OeKq9Z+AhyUwURAZpuHn5qtqzuzPzsi+yKJ5XSkBEXRlIYgoXZekgdDfuE1ZVJD7hEMU0iEXBlJgFjuJ8Ngbl9xYA9RCVAkreQV6paIWuFTi5HsquOOLxnUwjCOy4ok29TME6L/64+erqkKmsaux29Gl96/e8MWfgw/99mZ4FNZxVvf+TU8DyXqe8YWXdee7571eK/gVmunG7Fnef+tvA1yzGRVBx7MTrCa8ZUnDeYsajqburuUcTDeDrJf3MpMbwywFdJ6TIE+gorC6F4EGM5RKIrqyPEPxHYV4DBUWMDGA7IZcX6jP9Otj5ffWK2qXMd37xhGtfkU/manITeZls4WQoOES5jEEonJajdgyFSt12FFSFsMji3WXqe3YTHTkdTz1kOVY8JMKizRKCkBeyeAaMinLSNNIZJuk57r3WfH3rvsllWEZAxwEzFIOLXqzHaphyu0hNa/2qy1qv+6qo6DQ/6VKpWr6iUyEAATqsgojs0xVxgASZK+LBqJqVQ4rXULfFDBA4BhV0OrG2lFTiZNGRJZ9fut4PMGm/av2Pg9Av1GB2RqOYKqqNkeOvHy45+mvm23k03utdQdOA8lad6jl+4Vdu58HCt6iQM1jP/iqLp6z8XL07kATxPglDdvPV5TISO6uEeeemDIjMZ70E5ObDHIS5K27qxD3FjGWsmNUlmem6oLKOIqLGIoASl13QKsMoM6N0Tn9bkwGYDJzbLCjXs4uNoV6sDGdM+Nb0wYq1tC23ERmEgFjCaPBrHG1SZFkrEWgD/qGhIbcgUviruJM/Cj2i0Nl0/4jVuMWxmCZQ2N/zygcSAi+OISMgC4ADqdtxGHEPj5Xc34OkS4chH6GmaHts3US8+CCBcuqC19S8+Zz2dbs62BUBVBWoFRFTIPEdHFlGVVWpioxGotZCQvpCrtVUfn3gI2g+4pApFsM86KE0agiHaSnS1jNKyqseOcdNcB92t1Ym8RC4A8/clavzP9freGpjRs0Gh0yB488bfDWZ260jt4MluLbZ5fTQDLjs17Y9dJdCtTfgFIXAMARA/VLlq9//XtmHK7N0ipKYsQSKzdd4wtAYqiwdXd1jmuoiwzqeQaTuSqDuptB3st7xWoTUCoGEgIQcYEhgBBrsYBCUV0GxfwcagQSBBGVGQBsGyygojOztLLTrHa/px7UD6bM+TDXIRC0nXdqYhMruXwJMQpvhjeyAbiERMBznNaeKjyWdRlF61T5Y5ZXwEoVeHBuQyuxtnI4F68brg4ki9yfDnEH6wF0zAnDcyedk09IjGPGwn0wNLg+rPr6ZujXX87OyL8B2DREqQp/EvsAJU1EOlhQsUIWUmNSoQUPaXOoIGMNJKtK68Ii/QMBpNsthsVyBRWwkK7zCqwOUo1qwJyQE+jGwpvbe9W+J+ga/izNUqcpsrT6CXXbgWevvut539q89/L0SG13YJa36PSdtHeAQoQX/kQB/AqV1wb422VTv3gTsuHtEWJ2ApcBfO2zGlCMR0DB6K4zvktRIqPVTwhQsBU8spQQUExOLq/KsNuLIrrKDugsN6bqZAgaCB4WVAzkGRaCJABRGaiKtRTHUHRGVlRDZpaH28yyuqAewAWm7pxH27t/MVPxNjf1U42ZVm3MhRb5vp0Gl/kIbpnTYgJ2Yj1Qji0IuISfJxJIPGa6YfN8g8aD9KX30PnzsEyDBPoJ1X4jAGwwjuBag9NQur5D9dXNsFB/KZvXt5PqjuAByDwQSKCEWlXIQIiJqLpy7qsawSUrKo0NRrJC1RVmqhdQV6XqdAqoyxL/Q/dVBCAq43wQBBAEkmpYOx1ksKWGc6wb6xMGzn9hUO6dAH6taIfxtuaKD8z3sy2vVeJmjpYIVVXVR4//3ujqS19z2ljdPXfgNJBswn1euGj3T0Om3qEA7mOMuRUqeP7y5/Z8ZBOGbgcUm3tio7vuwux4CRduBRR2eUG3k5kSASVHpsGshIAlyxFUjIY8R/CoUIS3zETnmUG9BItC4rbMUMj1hT/J7SWgApBBWfTM8er+9TB7gBnBAw2kLjA2sdE/V6al5bvWmyhGvYXBRCa2EfWUDJYGW7mv2xhMZKp8OhDBRdBDK9ZkQrSbcjoI42h1aMWsAxQsqS58TXWrr6vF/Cu6q45Lm0Lsp8vggczDMRBVKskJqTGclz5nFxYBisZm6+jOorwpzlzPkH2oEsN4Vd0vh0oYiAMQ1EIGAiDnVhinRaVNFoYmykzfLDcWTtpXXvuITKu/UqAemN5Uszq8uTp0588Xb/25z055w09vtgl34DSQbMJNpCEe/Ktnzfe6b9NaPZ3MoYHXLy8VvwNfedMm9ncO4kgvu0ZBCigYLpwfZ0E+AhRxefW6WQ9Dhzt5ZsqawIR0lAoZStGxbIVdWybPCFBMDpnOoM74M2QmRmUGwQXZCQILMhV0e1FLPnF/YalZUNqsDM8wy+r8eggPNFV2PwA9F69EU6ogjijnLZqSuTQsSlsPdqEJa+FEOlbIVFhyEY09LNg4LuqrbYIFA9pmV9N0SAQoVV7fqrrqqzAPX80W9B1cXVHVpHuoqlakfyTggazEQFmpmjUR0kUqYiUlRlllCBQktBdQVhUzEHZfgcLdRERXooGQC6sFQI4UphHOu4kAAr/+wV5/x/z/AxpejnldEbTXxsCxY3862Hv7b8JnX7TRYqubZRW+bcY5DSSb/KjnL9n9y9qoPaBgizHmJmPK567c8KbrN/Ew3t1l9ZMwO/7sOUX5J22AsqWjKbGxx8DSK2sGEoOkg9hGzgwl59ySCoEG8rzGn5LAaDUUdH2Jm4tBRZiKARbmMeLLKA1aaahMBlTD3GRmaXiOGen7wgDuW5fqvkZ1oggbf59avB5hJWHX331aFrOJT2BdQwVFFnG/sdJ5+ipSfseqysy3VE/fAp3q1mwxvxUyNXIuK477rZUCLJglRbMQNDAKi8GksiI6so+qRvcTi+laAAWZiVbs6iL3lXLAolRZDQuM9p0rKQLLaiDOhSUMZE0AoQuf3Y1FdbKu+3EA86dKwYMaa4bh8HY4svTcwZuevplegHU95W/3jU8DyQmYAf2H7j5fZ/AurdSPYMMsA+YVK9nyn2xCWfrwbNsB5Xv+//bOPMav6rrj33Pf+y2zYQ82YTVEhEQJtoGGtoFA1KgSSZvljyYxDQlNSQskpA01JbRKpTYDmCStwi5oNgiLsqjOqqhRiCBGIQSI2MpipUBJwBCMPfbYnpnf+u491ffe937zm99sHjOb7XcFvm9fznu/95nvOfee2yfYss0gA8rQcOghnykUZk5hHKWchMC8K0SlqBqrxhFMPVbtIhRSiIQaUeSXETKxYQ//DCrB1aUw0ZhSQVAqbQpFqVToAktVShjHVQ0cjFbry7QixyihUtdjFPEKDtQ69Ydn4vfI/33fIUBa3rNxwMmgM15ijAXjO6XKdNuFjojjIidtAmWizkopMqG5sL8mqhwrsLtQjF6WgnvJdGGLdEfbgtpQB2McHGMeHOdWnZiWEkkHTZcQRNcoVR5x6roKzXq5LmHtkNBd5VUJ1QenM/dVYq1XILaU1Nn/0PcDofJgD/S6BQPoPgaSubAOdeh5bhoX1msHCK66+/Cyi68RwUcmik6FDo98t/7b35+PjZ/YPQ8/5fyQe2mBHCR7aajZbzZguk/ZdZGB+UJQJ9hsrb2o9uT1cz3WwcxA2dFnUM6AUjWI2LExiaA2gllmAlQKUcnZqOX2so1Y4wAQaBQFpdL00971FZkopkvLQyWJkaoS4+MmXGZjRWQAm86DudIZazEBLHYMLE4NjB99ycCpkUrSb2vucHXRCm26w5HIYYqofyyIP91ft/v2h+9UCJn9c5/uJ5WmR4bbIzG2S9G8KsYOSkm3S0+8LQTGmc9dHIhZJwEczJfiU/Sm67PapfCAWJs15eUxvPJog4dvrUXXlQ1QyVxZBAmBEZcSaSa2HnNY28iiu2Exmjg/uJRrOowULXrbWmExiD5pDGRdaLPsS6u93uxNmO5R2vCLTxo4jqO+fMJB6o1Bu2v3Jxo3rvv+Pp8g33HOLJCDZM5MOfmBfI/4gt4kkPf7vz3V3TZaiS7DM1cPzvGpp3Z5tQfl2cqLzYbZD2WkaHwer2rBoDBMl5bxnRvVRqWCjbxKKTgfoAehQleXugiWIzqaCJGmy0wURyZSrzoYxKdby0SG863gvDF+faZUfGyFyoRg8SMrUbWEmn+fe7j4tLXsxs33NJJKc7lrYLnaaJmqWaYNtxxWl6uaQyBRT9g/K6/NlTL7Z9Nq8qsQV4O4PRLJLilEQzDJHmOwGwXdJV3xThhthq4t4kJmeXZRp/JwFHcWbEtlMmj4gUJC6ys1zqsODwt1jq2w0ia9WVyELi2vPDrhIcZ615UYMsfCFRlct/WG8SrEnzdzXw03HSS2SBoOzS6HvrQZ7wIBpHjVL04yztGNdfqE5+Cc6p6R22qv7FmPb567Z/bPKd9jPiyQg2Q+rDrJMbtOXv8BI+ZGERwFxU7n9J8qT1x7yzycfnqgsJf8YSXxaVcIlHrMxKwR4mJwedH1RbXSGxuqFLg2qDgXKRWJaQSVQqhwPnKRd38xlqIaxWoi5TIqE8LDA8VExnI7YwCu8y6xEJz38HABIoSKivHOngwufprLfZ4VvrOh5jwhw2mLWGrNZa6pPWq1GxqXVU0ZQLcmrhtWe+BQDilg/LFMegwOUJIOEehBxB6B/qPOETvAbuScD7lN2IS2TqRJZEZhUBGxHNypJrFWEJuKdJldiAzjGBRe/gr9dAaMFkCUt++glrfq4AgR1myeG1RIAAeBEoYs9KqD6z1UEg8X0ZiBDZvFRGAJhlR5EB4eGgSLtUg4T5Aktk5wUH2w9ZUbdqHpbiOtu5xvfbWsz2H4JcW4Zrzp+CDjguhzo0Aw8OAhpbj2OVFcLKEp+riitdr/JjuGLkj+85z75uF3kx/yNVggB8lrMN6sdz3+wmW9h/T8h0LOF6GrR+9vOPvJxhM3PDXrY828w/RAGXlB0Jv2lI+7DHYzfX3VYLRk0F80MARKM/IqhWAhUExkvOuLbqkMKnEKEyVkXFAkXpkU2MMkUpvEscRBjWSKhAkiI2M0BUvEESLDV9cElZIqE69I6O5KVYpqAEwYlCl8/LP5dqiQC4YqxncWDLBpH1CK8+PHl5r4OwjjCIfCkDYvryV2UvcN4y/8xhM+fjgSAofigtt6OKTRG0MXFQMqKaR8zpfUhZUqEQ4Uwo+6X87RQoIrywMiUyQ+BqKkhoVN3VoeFqk7y3u4CBqqD8LDWDRqDlEp4bHrJrHQ2MFw5NuYCsVhgvroDRDJAuh9VcXW4xTP/1LR96aOUQrnCCAXPlworRr+lBH8KyArJgAkSRK3Z3RDY0t9AzaePRfpiGb+9eRbzMoCOUhmZa652bh88sVnRhJ/RQQn+rFOHG4YHU2uwHM3zodUb2sn1Dbc7/AzguP7BSO94gPzjKMsLwS313DZoCcSnyAyqhtExQATQsWDJYNK6v7yUCFESgZaD4F5McarFS6PjUGD7jHxQKGcGReAbwvEsxlx5FWHoxuMx+D3NygWn7yKri46xDKgcF3aFdy3EuOn2LvFxkYWbIEkdT+1hkPvAEzn420b4XYsvRVdZhkssubEhAThweXeXRXSvxAsXo2kaoMgCcuc+J6JVCQhkG7huCwokdSN5ft5pO6sJGGAPWYqd+dBQYXBbRMChUHyTG20K4/I1tW64LYiODhdCABh7MMHzydRH+3xDzwC35EQG4GNmxVgVl4PkH0LRnXYuLjh5x80MF8U4ITJfl06WrnfbR+8oPH1jzGxZF6WqAVykCzWgzn1wkJP0vP3Ivg3iCwHdIcqrhyNRm+e49ZdY39Ht/BI+GAAABJsSURBVJoypUDhmva+KC2317BBX1FQO1IQjxiMVI13fc0ElTphEhnE7WDhMsZHgjvLg6VAyLATYwoWcUbZoivRCBFVSRYroRIRMV6RuOCKaptWqhIuI0q8Igl6xQMng4dfp6kCSQmSpXMZl/59kheh1eKrDRxUGVxO1WE57VVGgIhXHASHUbqnPFzEtsVCCI5ELeFACHgFk8LEJRx/jELE2UhdUBzGz3tIUN74+YYTKabuK+d8rMNvQ7XhHPcRE9laNXboTuFBcHiAtMFj1GqIffQF9VF+XnFErwvqI3NfvVPHA+S1B9AzKxc2bDotUnxJRM6YFCC1+nYMj36mdv0H7lisn2h+3r23QA6SvbfV/Gz5pktXdnfbK0TMBWknq+cs3GfnMEX9JNedBYbbcnl5oFClnCmg24sqZZSxFELlGGm5vhorBDFbfqVKJXN9FY1QqZTpxmLrL8baWQtj7gEmHiIZVDifLWOshHEaYWzEMFeLB4eHi6ULy4TAu/PxlXQ6KBGOOMttg4phh3tuT0Y105qqg+LG+joMNcvCw+7FIw2uK39pYHcNP0NB5eMe/MNc4dL5NB5i2TmOOPMxEE5TfYSYR/u0hwlHjUrUIUrjIVQlHgxZCy7CoTgGFK17WKBhHUpl6yHSML6u0TVWotogOJaNKY8ae5NkgfNeh+FXFOVGiH10qo/5cl+lpi5dec8bBNHnRXD2pABJmnXsqVxTe3TnFbj347W9eEL5JkvAAjlIlsBD4CX0nnTxGjW+vfxZ4ZL0Aat6WfXx6+6fx0uc6PZiPq/t94bhf31OrxQqTMPCFl998TRQaRgUewWjwQ1WlqZh460AE0Il8TBRqpZ2kIj1APHAYG1tOu0Vh4eHWjGxCdCg4lATi4eMsQJOu6yll6VqEbIjqJRsyEDGRSYDyvTWDQBJXVWsfb7DbBkhEY0F0wmMABgqEgWBQkD4eeeSpOhgErrB6FpSRFGARqZKIufQNE6KqRLhulRlwLuoUnA467zqaKatvLyrqhgAUm46uFJwWdF15ZVHr0P5FcVwGzx87GNE8fzxir5hxWGd6iPc9MR8Nvv4Ng5sOqIUm38W1U+JIB2Fc+xYSluNjH5Htu64LE+yuI82XsTdcpAsovEnO3X3SZe83xj5EgRv8t8t4HtWk8/WH7/h2Xm81PFAyXrMTwYVBuhrXTIOKj2xePdXVyQ+nmLqBskh4mvGVqhW6m1gKUdGaylYPFSs0cQYFI1BYlPIpMsiwoOQsWmMxBhEluP3GXAdocHwvHUBNFQevg4A4d/8YNJjjtnkVUlbYyBCaKZCteELs6inasRECt+SlqhKW2Yxy7oWXWKokVKYEATcJgWKr31MhDXVSuQkDrDgNGxDISUrvjYWhch5xcHYhlpXdzFdYw6u4ILySOFBYFB1dKcAyeDRqTxagfOpXFdzDA/2SP/ifcdK4i5T6PkCsBXdhKKVykN22871za+f++BMjyNfvzQtMPMPaWle94F9VR3xE/WJ9fDNxOhV9UevfW6eb35yqGSuL5yKllIhVHAMgvsrjakMbzEgWLpWCEZTF1hpmaBWD4F6Q9XSARYqFbrCmgk7SwrBEuBiGegPIPHTVBoiYTkBkoLEK5NUfXiwpEDJAEKYeKrYMaj4BRNamE5i2hQg/PjbDCreMxZUB5ex5masqTISJtD1PdEVliMRRgEeDYJFmVzGocbaObGESuT8MqqPgnWoxU6KVCdOa53gaAwrygRIKcCDLqtior6/R4l1n8OrW+Gb7tJtNRU8Vm9WDPB2W8Fzb6G5erdKX9h0glj5LIC/kjBi50SA1GpbZXj00ur1H/zWXJ03P87iWCAHyeLYfe/Oesr65b3APwCyngF5ZT4lle80E3dV46nrFqIVyySurzRAzzvodH8xptJfFFQLYy4wQqVBpVI1aLKuG2RgIVAIlnpsUDCCRtOgKzYlSxWSGMQi2rS+RjMaUyDtMMlUCeHCz5WvCz4DlTomsC0AUcL4zZgaIWhmUzJQcB9OMyWgz7Df9M0F/DSB4MHCAScDQLLag4Tz/N9P11UKsUPiFI7QKLhas6p+vpgqjpjrig6d4ChY9W6r0UFF36rUZXWoYteLivIK9Wnbn3sW6G1zW/G62e9j9TrFwOXzBg+epjiwaY2J5F8geraMG06gzeC1+g5XqV5Rf/Txm3HvQErq2TyQfNulZoHZ/aCW2tUfLNfTAZTw17V+VxN35ehT1z+xQGaYWqlkUDkVwFAaV2lXK7WioK9A95Z4tdIOlnIUXGBJJEiMeLVCuCQ9ArPHwPZIuVAXMIhvG4K4LGhWDIpFeMhQgRSLHMfPL/Pr6IInYLxrixDhdPpHsYcKAZOVSf9YTlemSWQ9NAAPCU+RAJQwXAuXp9CICopGg+NNOtYeFoYJ26lYCtpSGR4YBQfCouGoTFJopNN0VRW61SuOFjjSWAcGMdbSqqHjVEd/VfHIIwj9PdKYxzwrj8yK5Q2bzhTIPwKTjFKYbUSAjNQ+X79v6415ht4F+tUu0GlykCyQoefkNBlQhD9YCVlzVX/krL2y8uQNCzn+whQxlaw58TOCU08dg0rWAqy2Q7CcLrA2sDQIl2EBa8ZYqFoIl2ZFvHJJqoJaw6C7GwEwKWxYWyMgZBIjZSqa4L1i+kNBiR94I4gb6TteAlxzbJtZPBAhINBIAeICPDjrXVkFBQcKiNQn1+cqHwTPYIEq0CwpojZgVCrw7qnYKuqERQc0sAvBVbVcUbaK4UTR1VQMNRR4Ca1muh4cgA+Ws1B1sIzr78EFcxg0b7ebT+vedY4Y82lA3zqlSXOAzOJt2z83zUGyPz63tRf198Zl/vV3cQYUVfzEOlxTe+Kaexb4ljoSo3f0UeHF0AXWrlY8WLZLK76CI4C+nYJaqloIlX5+rKMAl8ZIAIyHDAFD9RKFd7cFllpQM9kyQqQrtURSF2Qztm2aqxn+9cs6Cj/+rVINUxGXpdNxur5aDcvjsgIVtBRGoxyURtylwAg8MLzC6A4qo2oVxV5F0SpGE/XQoNoYZp+OhmJXI7iq2uMc/SemiiMDR6Y6Ol1W8wgPHnrDPUeX1VwkkE9AsDIHyAL/4pbg6XKQLMGHsteXdMr65T0in4Ti70TkGO6nwG8c5ObqcOP2eeopP93lpe9T9g1mPxUAT58YljNgPxlYuCxTLZymYmEvexY2N65FgvouQWNY0N8fAMOSQQbLgOaIAIcA5dGgZtALlKqh9nDhdHvpGZspdq4jxAiArIyOTXowsIyEKlMU/r6G0QIF51uwOEQxNAQfFM+AUW4qhg9VYCta0OA+48DRqThScHC7hVIdbSbr+vwvzlDrLobgL6YKoHNzrdRe1Frt6vqWxpex8exUyo23fj53YFkgB8mB8DzZysv1ngPgMwKs9bekGHbQOxMxNzUeu3rzIt3mRLUyGVj8RzhVLZQuQ5tD/xUmzRhOO0Zym8w1RgXD4iEzJOAfxQQNC2FDOZMpmvYbp7JhWZb+k81PZxyqBuz2/3kFMa7sAop9iiEuJCj6UlBwfhBowYLzkwHjGAWehe9Nnrmp/H11KI5FAoe/1S8+vKxsh9eJykUApnRf+YwvlepDMrTnuuqXP/ydRXrf8tMukgVykCyS4efrtD2nXHoW4D4D4CwJmXKZt3aTE9xUfezRHwH3LmYrmUnGB+xQLVnfFQ+XZwQEC91i/ludBvI5ffirArwevvd9VggaHAksZ53Cpt3QtZ1h28P4z+sQIDRDKfcrsA3Ynm5XporoKEwxwkKXVHvx6iKFBRtt9x6nwNNA//HjYxv+mtrUxoQAOTdoXeqcNdGd8s4v/EqhePQb3yOR+agA75+q/4d/t6x1Wqv90G4buia55dz57Dw705PK1y+iBWb+IS3ixeWn3ncLFNdesrYQ4VJAzsl6EtOPog5fc05vqz157fP7fvQ527PDFZYdtxMu6fLMNcbZDDKc9vGX5wVYDa9k2otXNSl0Jlw2QfTK1L+BniPTj/bvxu+ZwYFL23v1dILC75W2osqOkAXEOc/muLgc4/tzZBvOU4B8mkcXX3H36QUTnwvgLwFMyMLbvqs2mjWp1W/VwW1X1279m6XwLs3ZS5kfaPYWyEEye5vtV3t0nXzJ0SJ6voH5SNZb3t+A6v0OcnslKvwXHvn3pTRM6RRw4UVfHtaFjnTA0xvHv7/toOl8Su3g2ecnmDaMY/PaqUo7KGaEBTdYQKUxyTX73FeEh+q5U2XgzXbz7qvRyrPq3NfqL+/+Sj6w1D6/SAfcjjlIDrhHOvUNldde8idRhI8D8iER+GhzaIakP1KVOyuPb7kL2LiUx3uYBjLZfbfDpt0WnwsznfCZzfPPFETnPuN6iE91wMUFRvtVlQfuPl5N/D4RfHjSUQg7bkHrjQqayR12+9A3mrd89NezMVm+7cFhgRwkB8dzHn+XJ3z6kO4ec44x0XkATmv9xekjwvpNB/1e9bHrHtgPTdPxPs9/OKFNUbSZcYlZbmBTXI5wpkLeI4L3CfCWma5QOexvtf5L7Bm+vfbA0B15B8KZLHZwr89BcnA/fxRPvmR1QeQ8CNYJcFzb1/AVUf2xwnx39PG+TUCeymK/elUGfnVoOW68F5D3Au7PBOLbqk1XvOuqWn0ZibsNg9tuzWMfM1ksX59ZIAdJ/i60LNC1dv3pJpJ1EPmQAKtaK1R3qeDHzuEH1e2jd+H3X63kZltiFrjmV13l0frbAHkHgD+H4I/DQCx7AY9KdStUv2Ff3vH95p0fe3imffL1uQU6LZCDJH8nJrOAlE++9IwIug4CxlOOGlMqWhHFXc7hv11D76n95rqOJk25QRfEAgObVhYjML/V243gHQq8VXySsZlL2udjKxS321cHf9D8xscemnmvfIvcAlNbIAdJ/nbMZAEPFWOYzdW7vzo7aPwfVO+xKj+vmubP8diNWY+LmY6br5+FBUoDm04QgzNhcAYgZwrw5lnsHjatVrc5i9vttm0/SG796/0xBjbrW853WBgL5CBZGDsfMGcpr73keCPybmPwLoj+aSt5ZHqHCn0CkLuddQ8A9sHqEze+dMDc/ELdyIa7VpW0uNoI1kDlbYCeCZFJelhOf0Faa1TVJnehVrlXXt31w9q3zn9hoW4hP8/BZYEcJAfX857jux2IyyftPj2O8C5VeTe7BvrxCtuKqr6kwIMCechq8mBtR/QIXro2zXw4x5ezvx3uqrsPL7vCahVdE3pTYg2gq/cmMD7ZrbKXOao1psP5HrZvv692y3kLncBzf3sC+fXOkQVykMyRIfPDAFh7UX83SqfBmNNFcJqIMvgb0t2PKRaO9vg/CnkIcI+r4Onq7spmPP/VpdQpcl4fZ+nye88ykX4bkGl7j890EVqr15EkjwDmZ27nzs2N3/3+J/jZZW0ZJmc6Qr4+t8DcWCAHydzYMT/KpBYYMD1rhtZoZN4uIqcL9O0KvCHLAdapXCDyNFQ3Ey5q5elqUnsKm29O0+weOCbuumLTh2Hk27O5I1VVqVRfVWN+qpXKE25w6L7mnX+bt7CajRHzbefNAjlI5s20+YEntcAffPqwbi38kaieBIMToVgLkTdPlRhQodsBeVGgL6jqi1B50UFfECsvVgrJC0s3uP/OuPyW1UejUDw2MuZYQI8VwXEKPVaPO261/uEpx071hmhindTrrzhjHhTrHpOdO39bHar9FBvP35m/VbkFlqIFcpAsxady0F3Tuqi49tg3RlGyNkK0Gj7IrGtUcMKU4363u8qYs11lB6CDKrLDqO5gHncV7ITqDnWywwG7RFA3oo1mwlrqYlCvVk0dMlRHNFzH5o0NvP68MkyxhF5T6nLdJada0hilmLWipFFcEtdcISIrILJSIExYvxKiK0RlhUJXQrACKv2d8aLssbpjjoa+7VRokjhpNHYqzJMoFh7S3XtedrX6w83Df/NrDAy4g+41yG94v7VADpL99tEdBBd+4rpiuXj0UXCyKjJYBZVVKlhlBKtUsQqiq6DgR33JvccKJIC+IipbVLAFii2AvuRUt+gRRw65ww/d0bjjgidDurO85BbYvy2w5H6A+7c586tfcAucemEBle6VxVhWGiMrReD/h9MVMPI6UT8U7AqB9ihQgqAkimJrmp34qDREygLEqlqnctEwEjsHfK8jzHOkv2zdHj9ylXD0Kgyqqq+dukHn3GCj3hjEM0ftBHJVseDvQ37CRbFADpJFMXt+0twCuQVyCxw4FshBcuA8y/xOcgvkFsgtsCgWyEGyKGbPT5pbILdAboEDxwI5SA6cZ5nfSW6B3AK5BRbFAv8P1/vV3ySxqWYAAAAASUVORK5CYII=");

/***/ }),
/* 11 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__bundle_node_modules_vue_style_loader_index_js_bundle_node_modules_css_loader_index_js_bundle_node_modules_vue_loader_lib_loaders_stylePostLoader_js_bundle_node_modules_sass_loader_dist_cjs_js_bundle_node_modules_vue_loader_lib_index_js_vue_loader_options_Component_vue_vue_type_style_index_0_id_a1d7c38c_lang_scss_scoped_true___ = __webpack_require__(12);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__bundle_node_modules_vue_style_loader_index_js_bundle_node_modules_css_loader_index_js_bundle_node_modules_vue_loader_lib_loaders_stylePostLoader_js_bundle_node_modules_sass_loader_dist_cjs_js_bundle_node_modules_vue_loader_lib_index_js_vue_loader_options_Component_vue_vue_type_style_index_0_id_a1d7c38c_lang_scss_scoped_true____default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__bundle_node_modules_vue_style_loader_index_js_bundle_node_modules_css_loader_index_js_bundle_node_modules_vue_loader_lib_loaders_stylePostLoader_js_bundle_node_modules_sass_loader_dist_cjs_js_bundle_node_modules_vue_loader_lib_index_js_vue_loader_options_Component_vue_vue_type_style_index_0_id_a1d7c38c_lang_scss_scoped_true___);
/* unused harmony reexport namespace */


/***/ }),
/* 12 */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(13);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(15)("44fbad70", content, false, {});
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../../../bundle/node_modules/css-loader/index.js!../../../../bundle/node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../bundle/node_modules/sass-loader/dist/cjs.js!../../../../bundle/node_modules/vue-loader/lib/index.js??vue-loader-options!./Component.vue?vue&type=style&index=0&id=a1d7c38c&lang=scss&scoped=true&", function() {
     var newContent = require("!!../../../../bundle/node_modules/css-loader/index.js!../../../../bundle/node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../bundle/node_modules/sass-loader/dist/cjs.js!../../../../bundle/node_modules/vue-loader/lib/index.js??vue-loader-options!./Component.vue?vue&type=style&index=0&id=a1d7c38c&lang=scss&scoped=true&");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),
/* 13 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(14)(false);
// imports


// module
exports.push([module.i, ".image[data-v-a1d7c38c]{width:100%;flex:1}.box-list[data-v-a1d7c38c]{display:flex;justify-content:space-between;box-sizing:border-box;padding:12px;flex:1}.per[data-v-a1d7c38c]{position:absolute;color:#fff;top:22%;width:100%;text-align:center;font-size:32px}.box[data-v-a1d7c38c]{position:relative;margin:20px}.text[data-v-a1d7c38c]{position:absolute;top:40%;width:100%;text-align:center;color:#01F9FD;font-size:18px;margin-top:12px}.container[data-v-a1d7c38c]{display:flex;align-items:center;background-color:inherit}.box-number[data-v-a1d7c38c]{font-size:23px;color:#01F9FD;text-align:center;width:100%;position:absolute;bottom:-50px}.bad[data-v-a1d7c38c]{color:#FDC201}\n", ""]);

// exports


/***/ }),
/* 14 */
/***/ (function(module, exports) {

/*
	MIT License http://www.opensource.org/licenses/mit-license.php
	Author Tobias Koppers @sokra
*/
// css base code, injected by the css-loader
module.exports = function(useSourceMap) {
	var list = [];

	// return the list of modules as css string
	list.toString = function toString() {
		return this.map(function (item) {
			var content = cssWithMappingToString(item, useSourceMap);
			if(item[2]) {
				return "@media " + item[2] + "{" + content + "}";
			} else {
				return content;
			}
		}).join("");
	};

	// import a list of modules into the list
	list.i = function(modules, mediaQuery) {
		if(typeof modules === "string")
			modules = [[null, modules, ""]];
		var alreadyImportedModules = {};
		for(var i = 0; i < this.length; i++) {
			var id = this[i][0];
			if(typeof id === "number")
				alreadyImportedModules[id] = true;
		}
		for(i = 0; i < modules.length; i++) {
			var item = modules[i];
			// skip already imported module
			// this implementation is not 100% perfect for weird media query combinations
			//  when a module is imported multiple times with different media queries.
			//  I hope this will never occur (Hey this way we have smaller bundles)
			if(typeof item[0] !== "number" || !alreadyImportedModules[item[0]]) {
				if(mediaQuery && !item[2]) {
					item[2] = mediaQuery;
				} else if(mediaQuery) {
					item[2] = "(" + item[2] + ") and (" + mediaQuery + ")";
				}
				list.push(item);
			}
		}
	};
	return list;
};

function cssWithMappingToString(item, useSourceMap) {
	var content = item[1] || '';
	var cssMapping = item[3];
	if (!cssMapping) {
		return content;
	}

	if (useSourceMap && typeof btoa === 'function') {
		var sourceMapping = toComment(cssMapping);
		var sourceURLs = cssMapping.sources.map(function (source) {
			return '/*# sourceURL=' + cssMapping.sourceRoot + source + ' */'
		});

		return [content].concat(sourceURLs).concat([sourceMapping]).join('\n');
	}

	return [content].join('\n');
}

// Adapted from convert-source-map (MIT)
function toComment(sourceMap) {
	// eslint-disable-next-line no-undef
	var base64 = btoa(unescape(encodeURIComponent(JSON.stringify(sourceMap))));
	var data = 'sourceMappingURL=data:application/json;charset=utf-8;base64,' + base64;

	return '/*# ' + data + ' */';
}


/***/ }),
/* 15 */
/***/ (function(module, exports, __webpack_require__) {

/*
  MIT License http://www.opensource.org/licenses/mit-license.php
  Author Tobias Koppers @sokra
  Modified by Evan You @yyx990803
*/

var hasDocument = typeof document !== 'undefined'

if (typeof DEBUG !== 'undefined' && DEBUG) {
  if (!hasDocument) {
    throw new Error(
    'vue-style-loader cannot be used in a non-browser environment. ' +
    "Use { target: 'node' } in your Webpack config to indicate a server-rendering environment."
  ) }
}

var listToStyles = __webpack_require__(16)

/*
type StyleObject = {
  id: number;
  parts: Array<StyleObjectPart>
}

type StyleObjectPart = {
  css: string;
  media: string;
  sourceMap: ?string
}
*/

var stylesInDom = {/*
  [id: number]: {
    id: number,
    refs: number,
    parts: Array<(obj?: StyleObjectPart) => void>
  }
*/}

var head = hasDocument && (document.head || document.getElementsByTagName('head')[0])
var singletonElement = null
var singletonCounter = 0
var isProduction = false
var noop = function () {}
var options = null
var ssrIdKey = 'data-vue-ssr-id'

// Force single-tag solution on IE6-9, which has a hard limit on the # of <style>
// tags it will allow on a page
var isOldIE = typeof navigator !== 'undefined' && /msie [6-9]\b/.test(navigator.userAgent.toLowerCase())

module.exports = function (parentId, list, _isProduction, _options) {
  isProduction = _isProduction

  options = _options || {}

  var styles = listToStyles(parentId, list)
  addStylesToDom(styles)

  return function update (newList) {
    var mayRemove = []
    for (var i = 0; i < styles.length; i++) {
      var item = styles[i]
      var domStyle = stylesInDom[item.id]
      domStyle.refs--
      mayRemove.push(domStyle)
    }
    if (newList) {
      styles = listToStyles(parentId, newList)
      addStylesToDom(styles)
    } else {
      styles = []
    }
    for (var i = 0; i < mayRemove.length; i++) {
      var domStyle = mayRemove[i]
      if (domStyle.refs === 0) {
        for (var j = 0; j < domStyle.parts.length; j++) {
          domStyle.parts[j]()
        }
        delete stylesInDom[domStyle.id]
      }
    }
  }
}

function addStylesToDom (styles /* Array<StyleObject> */) {
  for (var i = 0; i < styles.length; i++) {
    var item = styles[i]
    var domStyle = stylesInDom[item.id]
    if (domStyle) {
      domStyle.refs++
      for (var j = 0; j < domStyle.parts.length; j++) {
        domStyle.parts[j](item.parts[j])
      }
      for (; j < item.parts.length; j++) {
        domStyle.parts.push(addStyle(item.parts[j]))
      }
      if (domStyle.parts.length > item.parts.length) {
        domStyle.parts.length = item.parts.length
      }
    } else {
      var parts = []
      for (var j = 0; j < item.parts.length; j++) {
        parts.push(addStyle(item.parts[j]))
      }
      stylesInDom[item.id] = { id: item.id, refs: 1, parts: parts }
    }
  }
}

function createStyleElement () {
  var styleElement = document.createElement('style')
  styleElement.type = 'text/css'
  head.appendChild(styleElement)
  return styleElement
}

function addStyle (obj /* StyleObjectPart */) {
  var update, remove
  var styleElement = document.querySelector('style[' + ssrIdKey + '~="' + obj.id + '"]')

  if (styleElement) {
    if (isProduction) {
      // has SSR styles and in production mode.
      // simply do nothing.
      return noop
    } else {
      // has SSR styles but in dev mode.
      // for some reason Chrome can't handle source map in server-rendered
      // style tags - source maps in <style> only works if the style tag is
      // created and inserted dynamically. So we remove the server rendered
      // styles and inject new ones.
      styleElement.parentNode.removeChild(styleElement)
    }
  }

  if (isOldIE) {
    // use singleton mode for IE9.
    var styleIndex = singletonCounter++
    styleElement = singletonElement || (singletonElement = createStyleElement())
    update = applyToSingletonTag.bind(null, styleElement, styleIndex, false)
    remove = applyToSingletonTag.bind(null, styleElement, styleIndex, true)
  } else {
    // use multi-style-tag mode in all other cases
    styleElement = createStyleElement()
    update = applyToTag.bind(null, styleElement)
    remove = function () {
      styleElement.parentNode.removeChild(styleElement)
    }
  }

  update(obj)

  return function updateStyle (newObj /* StyleObjectPart */) {
    if (newObj) {
      if (newObj.css === obj.css &&
          newObj.media === obj.media &&
          newObj.sourceMap === obj.sourceMap) {
        return
      }
      update(obj = newObj)
    } else {
      remove()
    }
  }
}

var replaceText = (function () {
  var textStore = []

  return function (index, replacement) {
    textStore[index] = replacement
    return textStore.filter(Boolean).join('\n')
  }
})()

function applyToSingletonTag (styleElement, index, remove, obj) {
  var css = remove ? '' : obj.css

  if (styleElement.styleSheet) {
    styleElement.styleSheet.cssText = replaceText(index, css)
  } else {
    var cssNode = document.createTextNode(css)
    var childNodes = styleElement.childNodes
    if (childNodes[index]) styleElement.removeChild(childNodes[index])
    if (childNodes.length) {
      styleElement.insertBefore(cssNode, childNodes[index])
    } else {
      styleElement.appendChild(cssNode)
    }
  }
}

function applyToTag (styleElement, obj) {
  var css = obj.css
  var media = obj.media
  var sourceMap = obj.sourceMap

  if (media) {
    styleElement.setAttribute('media', media)
  }
  if (options.ssrId) {
    styleElement.setAttribute(ssrIdKey, obj.id)
  }

  if (sourceMap) {
    // https://developer.chrome.com/devtools/docs/javascript-debugging
    // this makes source maps inside style tags work properly in Chrome
    css += '\n/*# sourceURL=' + sourceMap.sources[0] + ' */'
    // http://stackoverflow.com/a/26603875
    css += '\n/*# sourceMappingURL=data:application/json;base64,' + btoa(unescape(encodeURIComponent(JSON.stringify(sourceMap)))) + ' */'
  }

  if (styleElement.styleSheet) {
    styleElement.styleSheet.cssText = css
  } else {
    while (styleElement.firstChild) {
      styleElement.removeChild(styleElement.firstChild)
    }
    styleElement.appendChild(document.createTextNode(css))
  }
}


/***/ }),
/* 16 */
/***/ (function(module, exports) {

/**
 * Translates the list format produced by css-loader into something
 * easier to manipulate.
 */
module.exports = function listToStyles (parentId, list) {
  var styles = []
  var newStyles = {}
  for (var i = 0; i < list.length; i++) {
    var item = list[i]
    var id = item[0]
    var css = item[1]
    var media = item[2]
    var sourceMap = item[3]
    var part = {
      id: parentId + ':' + i,
      css: css,
      media: media,
      sourceMap: sourceMap
    }
    if (!newStyles[id]) {
      styles.push(newStyles[id] = { id: id, parts: [part] })
    } else {
      newStyles[id].parts.push(part)
    }
  }
  return styles
}


/***/ }),
/* 17 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["a"] = normalizeComponent;
/* globals __VUE_SSR_CONTEXT__ */

// IMPORTANT: Do NOT use ES2015 features in this file (except for modules).
// This module is a runtime utility for cleaner component module output and will
// be included in the final webpack user bundle.

function normalizeComponent(
  scriptExports,
  render,
  staticRenderFns,
  functionalTemplate,
  injectStyles,
  scopeId,
  moduleIdentifier /* server only */,
  shadowMode /* vue-cli only */
) {
  // Vue.extend constructor export interop
  var options =
    typeof scriptExports === 'function' ? scriptExports.options : scriptExports

  // render functions
  if (render) {
    options.render = render
    options.staticRenderFns = staticRenderFns
    options._compiled = true
  }

  // functional template
  if (functionalTemplate) {
    options.functional = true
  }

  // scopedId
  if (scopeId) {
    options._scopeId = 'data-v-' + scopeId
  }

  var hook
  if (moduleIdentifier) {
    // server build
    hook = function (context) {
      // 2.3 injection
      context =
        context || // cached call
        (this.$vnode && this.$vnode.ssrContext) || // stateful
        (this.parent && this.parent.$vnode && this.parent.$vnode.ssrContext) // functional
      // 2.2 with runInNewContext: true
      if (!context && typeof __VUE_SSR_CONTEXT__ !== 'undefined') {
        context = __VUE_SSR_CONTEXT__
      }
      // inject component styles
      if (injectStyles) {
        injectStyles.call(this, context)
      }
      // register component module identifier for async chunk inferrence
      if (context && context._registeredComponents) {
        context._registeredComponents.add(moduleIdentifier)
      }
    }
    // used by ssr in case component is cached and beforeCreate
    // never gets called
    options._ssrRegister = hook
  } else if (injectStyles) {
    hook = shadowMode
      ? function () {
          injectStyles.call(
            this,
            (options.functional ? this.parent : this).$root.$options.shadowRoot
          )
        }
      : injectStyles
  }

  if (hook) {
    if (options.functional) {
      // for template-only hot-reload because in that case the render fn doesn't
      // go through the normalizer
      options._injectStyles = hook
      // register for functional component in vue file
      var originalRender = options.render
      options.render = function renderWithStyleInjection(h, context) {
        hook.call(context)
        return originalRender(h, context)
      }
    } else {
      // inject component registration as beforeCreate hook
      var existing = options.beforeCreate
      options.beforeCreate = existing ? [].concat(existing, hook) : [hook]
    }
  }

  return {
    exports: scriptExports,
    options: options
  }
}


/***/ })
/******/ ]);