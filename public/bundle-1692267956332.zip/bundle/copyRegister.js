/*
 * @Author: xqm 13697256625@163.com
 * @Date: 2023-05-18 21:02:04
 * @LastEditors: xqm 13697256625@163.com
 * @LastEditTime: 2023-07-13 10:32:57
 * @FilePath: \lianyong\generateAppmanifest.js
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
const path = require('path')
const fs = require('fs')

const file = fs.readFileSync(path.join(__dirname, './register.js'))
const res = JSON.parse(file.toString())
fs.writeFileSync(path.join(__dirname, './dist/register.js'), res)
