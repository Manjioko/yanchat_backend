/*
 * @Author: xqm 13697256625@163.com
 * @Date: 2023-07-13 09:16:48
 * @LastEditors: xqm 13697256625@163.com
 * @LastEditTime: 2023-07-13 10:34:36
 * @FilePath: \ocsComponentBuild\bundle\webpack.config.js
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
const path = require('path')
const VueLoaderPlugin = require('vue-loader/lib/plugin')
const CleanWebpackPlugin = require('clean-webpack-plugin')

function resolve (dir) {
  return path.join(__dirname, '..', dir)
}

module.exports = {
  entry: {
    component: '../src/views/center/components/table.vue'
  }, // 入口文件
  output: {
    path: path.resolve(__dirname, './dist'),
    publicPath: './',
    filename: '[name].js',
    library: 'component',
    libraryTarget: 'window'
  },
  module: {
    rules: [
      {
        test: /\.vue$/, // 处理 .vue 文件
        use: 'vue-loader'
      },
      {
        test: /\.css$/, // 处理 .css 文件
        use: ['vue-style-loader', 'css-loader']
      },
      {
        test: /\.s[ac]ss$/i,
        use: [
          'vue-style-loader',
          'css-loader',
          'sass-loader'
        ]
      },
      {
        test: /\.(png|jpe?g|gif)$/i, // 处理图片
        use: [
          {
            loader: 'file-loader',
            options: {
              name: '[name]_[hash].[ext]',
              outputPath: './image'
            }
          }
        ]
      },
      {
        test: /\.js$/,
        exclude: /node_modules/,
        use: [
          {
            loader: 'expose-loader',
            options: '__PACKAGING_TOOL_webpack__'
          },
          {
            loader: 'babel-loader',
            options: {
              presets: ['@babel/preset-env'],
              plugins: ['@babel/plugin-proposal-object-rest-spread']// 此插件只能在webpack里面配置
            }
          }
        ]
      }
    ]
  },
  plugins: [
    // new CleanWebpackPlugin(['dist']),
    new VueLoaderPlugin()
  ],
  resolve: {
    extensions: ['.js', '.vue', '.json'],
    alias: {
      '@': resolve('src')
    }
  }
}
