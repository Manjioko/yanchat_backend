// eslint-disable-next-line import/no-extraneous-dependencies
// import { VariableVisibleTypes, variableValueType } from '@/utils/types/VariableVisibleTypes'
// VALUE_STRING,
// VALUE_NUMBER,
// VALUE_BOOLEAN,
// VALUE_ARRAY,
// VALUE_OBJECT,
{
    const { VariableVisibleTypes, variableValueType } = window.__ocs__.ocsVariableVisibleTypes
    const register = {
        component: 'BadTest',
        label: '三饼图',
        icon: {
            name: 'test',
            width: '48px',
            height: '24px',
        },
        variablesList: [
            {
                label: '显示组件(从左到右分别为 1,1,1)',
                key: 'show',
                value: '1,2,3',
                type: variableValueType.VALUE_STRING,
                variableVisibleType: VariableVisibleTypes.ALL
            },
            {
                label: '出勤率配置(如 12#ddd,23#eee,12#efefef)',
                key: 'attendance',
                value: '32#fff,18#01F9FD,23#01F9FD',
                type: variableValueType.VALUE_STRING,
                variableVisibleType: VariableVisibleTypes.ALL
            },
            {
                label: '计划达成率配置(如 12#ddd,23#eee,12#efefef)',
                key: 'plan',
                value: '32#fff,18#01F9FD,23#01F9FD',
                type: variableValueType.VALUE_STRING,
                variableVisibleType: VariableVisibleTypes.ALL
            },
            {
                label: '直通率配置(如 12#ddd,23#eee,12#efefef)',
                key: 'pass',
                value: '32#fff,18#01F9FD,23#FDC201',
                type: variableValueType.VALUE_STRING,
                variableVisibleType: VariableVisibleTypes.ALL
            },
            {
                label: '出勤人员总数',
                key: 'attTotal',
                value: 0,
                type: variableValueType.VALUE_NUMBER,
                variableVisibleType: VariableVisibleTypes.ALL
            },
            {
                label: '获取数据频率(次) 默认 5 秒获取一次',
                key: 'getDataByTime',
                value: 5,
                type: variableValueType.VALUE_NUMBER,
                variableVisibleType: VariableVisibleTypes.ALL
            },
        ],
        events: [],
        lineIds: '',
        initEvents: [],
        actions: [],
        style: {
            width: 600,
            height: 400,
            fontSize: 16,
            fontWeight: 400,
            lineHeight: '',
            backgroundColor: '#221294',
            color: '',
            border: '',
            borderRadius: '',
            boxShadow: '',
            borderStyle: '',
            textAlign: 'center',
            fontFamily: 'PingFangSC',
            position: '',
        },
    }

    function run (global, data) {
        if (!global.globalRegisterObject || !Array.isArray(global.globalRegisterObject))
            global.globalRegisterObject = {}
        global.globalRegisterObject = data
    }

    run(this, register)
}
