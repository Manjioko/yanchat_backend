const path = require('path')
const VueLoaderPlugin = require('vue-loader/lib/plugin')
const CleanWebpackPlugin = require('clean-webpack-plugin')

function resolve (dir) {
  return path.join(__dirname, '..', dir)
}

module.exports = {
  entry: {
    component: '../src/views/OrderStatistics/Component.vue'
  }, // 入口文件
  output: {
    path: path.resolve(__dirname, './dist'),
    publicPath: './',
    filename: '[name].js',
    library: 'component',
    libraryTarget: 'window'
  },
  module: {
    rules: [
      {
        test: /\.vue$/, // 处理 .vue 文件
        use: 'vue-loader'
      },
      {
        test: /\.css$/, // 处理 .css 文件
        use: ['vue-style-loader', 'css-loader']
      },
      {
        test: /\.s[ac]ss$/i,
        use: [
          'vue-style-loader',
          'css-loader',
          'sass-loader'
        ]
      },
      {
        test: /\.(png|jpe?g|gif)$/i, // 处理图片
        use: [
          {
            loader: 'file-loader',
            options: {
              name: '[name]_[hash].[ext]',
              outputPath: './image'
            }
          }
        ]
      },
      {
        test: /\.js$/,
        exclude: /node_modules/,
        use: [
          {
            loader: 'expose-loader',
            options: '__PACKAGING_TOOL_webpack__'
          },
          { loader: 'babel-loader' }
        ]
      }
    ]
  },
  plugins: [
    new CleanWebpackPlugin(['dist']),
    new VueLoaderPlugin()
  ],
  resolve: {
    alias: {
      '@': resolve('src')
    }
  }
}
