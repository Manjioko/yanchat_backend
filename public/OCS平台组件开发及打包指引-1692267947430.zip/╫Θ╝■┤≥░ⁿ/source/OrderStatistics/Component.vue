<template>
    <div 
        class="wrapper-box" 
        :style="{
            width: currentWidth+ 'px',
            height: currentHeight + 'px'
        }"
    >
        <section class="wrapper-box-title">
            <p>{{ elementVariable.name }}</p>
            <img src="@/assets/images/screen/background-image/center/header-top.png" alt="" />
        </section>
        <section class="wrapper-box-content">
            <ul v-if="orderStatisticsList.length" class="order-statistics-ul">
                <li
                    v-for="(item, index) in orderStatisticsList"
                    :key="index"
                    class="box-li"
                >
                    <span class="li-span1">{{ item.name }}</span>
                    <span class="li-span2">{{ item.value }}</span>
                    <span class="li-span3">{{ item.analysisCompareVO.name }}</span>

                    <span
                        v-if="item.analysisCompareVO.growthStatus != null"
                        :class="{
                            'li-span4': true,
                            'up-color': item.analysisCompareVO.growthStatus == 'up',
                            'down-color': item.analysisCompareVO.growthStatus == 'down',
                            'keep-color': item.analysisCompareVO.growthStatus == 'keep'
                        }"
                    >
                        <i>{{ item.analysisCompareVO.value.slice(0, -1) }}</i><i>%</i>
                        <i
                            :class="{
                                'el-icon-top': item.analysisCompareVO.growthStatus == 'up',
                                'el-icon-bottom': item.analysisCompareVO.growthStatus == 'down',
                                'el-icon-right': item.analysisCompareVO.growthStatus == 'keep'
                            }"
                        ></i>
                    </span>
                    <span v-else class="li-span4 li-span4-null">--</span>
                </li>
            </ul>
        </section>
    </div>
</template>

<script>
export default {
    props: {
        element: {
            type: Object,
            default: () => {},
        },
    },
    data() {
        return {
            currentWidth: 518,
            currentHeight: 293,
            elementVariable: {
                name: '订单统计',
                lineId: '',
            },
            orderStatisticsList: [],
        }
    },
    watch: {
        'element.initData': {
            handler(newVal) {
                const { variableData } = newVal || {}
                const tem = {}
                variableData.forEach(el => {
                    const { variableENName, variableValue } = el || {}
                    if (variableValue) {
                        tem[variableENName] = variableValue
                    }
                })
                this.elementVariable = {
                    ...this.elementVariable,
                    ...tem,
                }
                if (Reflect.has(this.elementVariable, 'list')) {
                    this.orderStatisticsList = this.elementVariable.list
                }
            },
            deep: true,
            immediate: true,
        },
        'element.style': {
            handler(newVal) {
                if (!Object.keys(newVal).length) return
                this.currentWidth = newVal.width
                this.currentHeight = newVal.height
            },
            deep: true,
        },
    },
    methods: {
    },
}
</script>

<style lang="scss" scoped>
@mixin before-after($direction1, $direction2) {
  content: '';
  width: 8px;
  height: 8px;
  position: absolute;
  #{$direction1}: -2px;
  #{$direction2}: -2px;
  @if ($direction1==left) {
    border-left: 2px solid #00F2FF;
  }
  @if ($direction1==right) {
    border-right: 2px solid #00F2FF;
  }
  @if ($direction2==top) {
    border-top: 2px solid #00F2FF;
  }
  @if ($direction2==bottom) {
    border-bottom: 2px solid #00F2FF;
  }
}

$up-color: #FEDB65;
$keep-color: #fff;
$down-color: #FC6565;
.wrapper-box {
    width: 400px;
    height: 195px;
    overflow: hidden;
    background: url('~@/assets/images/screen/background-image/center/background-five.png') no-repeat center;
    background-repeat: no-repeat;
    background-position:center top;
    background-size: 100% 100%;
    &-title {
        padding: 0px 0 0 9px;
        p {
            font-size: 18px;
            font-weight: 500;
            color: #ffffff;
            padding-top: 10px;
        }
        img {
            width: 152px;
            height: 3px;
        }
    }
    &-content {
        width: 100%;
        .order-statistics-ul {
            padding: 0 18px;
            .box-li {
                width: 480px;
                height: 50px;
                display: flex;
                align-items: center;
                border-bottom: 1px solid #01256e;
                .li-span1 {
                    display: inline-block;
                    width: 170px;
                    padding-left: 37px;
                    font-size: 14px;
                    font-weight: 400;
                    color: #ffffff;
                }
                .li-span2 {
                    display: inline-block;
                    width: 125px;
                    font-size: 22px;
                    font-weight: 400;
                    color: #2aceff;
                }
                .li-span3 {
                    display: inline-block;
                    width: 80px;
                    font-size: 14px;
                    font-weight: 400;
                    color: #ffffff;
                }
                .li-span4 {
                    display: inline-block;
                    width: 102px;
                    font-weight: 400;
                    text-align: right;
                > i {
                    font-style: normal;
                }
                > i:nth-of-type(1) {
                    font-size: 22px;
                }
                > i:nth-of-type(2) {
                    font-size: 14px;
                }
                > i:nth-of-type(3) {
                    font-size: 22px;
                }
                }
                .li-span4-null {
                    text-align: center;
                    color: #fff;
                }
                .up-color {
                    color: $up-color;
                }
                .keep-color {
                    color: $keep-color;
                }
                .down-color {
                    color: $down-color;
                }
            }
        }
    }
}
</style>
