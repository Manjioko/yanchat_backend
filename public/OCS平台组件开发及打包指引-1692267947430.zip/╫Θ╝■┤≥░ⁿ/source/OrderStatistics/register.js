export default {
    component: 'OrderStatistics',
    label: '订单统计',
    icon: {
        name: 'default-icon',
        width: '24px',
        height: '24px',
    },
    // 初始化数据
    initData: {
        variableData: [
            {
                variableName: '组件名称', // lable(页面展示的中文字段)
                variableENName: 'name', // 对应的变量名称
                variableValue: '订单统计',
                customBindIndex: '', // 对应的customBindData里面的item数据绑定的索引 0
                varDescription: '',
            },
            {
                variableName: '列表数据', // lable(页面展示的中文字段)
                variableENName: 'list', // 对应的变量名称
                variableValue: '',
                customBindIndex: '', // 对应的customBindData里面的item数据绑定的索引 0
                varDescription: '',
            },
        ],
        customBindData: [],
    },
    initEvents: [],
    actions: [
        { fn() {}, funList: [], type: 'edit', descript: '列表 item 触发事件' },
        { 
            async fn() {
                const res = await window.$axios({
                    url: `${localStorage.getItem('baseUrl')}/doc/sale/orders/analysis/compare`,
                    method: 'get',
                    headers: {
                        Authorization: `${localStorage.getItem('Token-Type')} ${localStorage.getItem('Token')}`,
                    },
                })
                const { code, data, message } = res.data || {}
                if (+code === 200) {
                    this.initData.variableData[1].variableValue = data
                } else {
                    console.log(message)
                }
            },
            funList: [],
            type: 'init', 
            label: '', 
            params: {},
        },
    ],
    isNotPrevent: true,
    style: {
        width: 518,
        height: 293,
        fontSize: 16,
        fontWeight: 400,
        lineHeight: '',
        backgroundColor: '',
        color: '',
        borderRadius: '',
        boxShadow: '',
        borderStyle: '',
        borderWidth: '',
        borderColor: '',
        textAlign: '',
    },
    screen_style: {
        title: {
            titleFontSize: '30',
            titleFontColor: '#ffffff',
        },
    },
    custom_style: {
    },
    screenType: 'CENTER_SCREEN',
    requestConfig: [],
}