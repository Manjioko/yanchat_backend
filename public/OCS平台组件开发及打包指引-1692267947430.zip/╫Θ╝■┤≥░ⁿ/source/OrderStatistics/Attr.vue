<template>
    <div>
        <AttrTab @attrActiveName="activeNameHandler" />
    </div>
</template>

<script>
import AttrTab from '@/components/PropertySetting/AttrTab.vue'
import { mapState } from 'vuex'

export default {
    components: { AttrTab },
    data() {
        return {
            // 右侧属性栏的 tab 页面切换依赖 components
            activeName: '',
            isShow: false,
        }
    },
    computed: mapState([
        'curComponent',
    ]),
    methods: {
        activeNameHandler(val) {
            this.isShow = val === 'initData'
        },
    },
}
</script>

<style lang="scss" scoped>
    .normal-style {
        padding: 12px;
    }
</style>
