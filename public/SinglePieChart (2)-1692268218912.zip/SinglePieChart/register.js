// eslint-disable-next-line import/no-extraneous-dependencies
// import { VariableVisibleTypes, variableValueType } from '@/utils/types/VariableVisibleTypes'
// VALUE_STRING,
// VALUE_NUMBER,
// VALUE_BOOLEAN,
// VALUE_ARRAY,
// VALUE_OBJECT,
{
    const { VariableVisibleTypes, variableValueType } = window.__ocs__.ocsVariableVisibleTypes
    const register = {
        component: 'SinglePieChart',
        label: '单饼图',
        icon: {
            name: 'test',
            width: '48px',
            height: '24px',
        },
        variablesList: [
            {
                label: '配置(如 12#ddd,23#eee,12#efefef)',
                key: 'style',
                value: '32#fff,18#01F9FD,23#01F9FD',
                type: variableValueType.VALUE_STRING,
                variableVisibleType: VariableVisibleTypes.ALL
            },
            {
                label: '饼图名称',
                key: 'name',
                value: '名称壹',
                type: variableValueType.VALUE_STRING,
                variableVisibleType: VariableVisibleTypes.ALL
            },
            {
                label: '个数(分子)',
                key: 'num',
                value: 0,
                type: variableValueType.VALUE_NUMBER,
                variableVisibleType: VariableVisibleTypes.ALL
            },
            {
                label: '总数(分母)',
                key: 'total',
                value: 0,
                type: variableValueType.VALUE_NUMBER,
                variableVisibleType: VariableVisibleTypes.ALL
            },
        ],
        constantList:[],
        customVariablesList:[],
        events: [],
        lineIds: '',
        initEvents: [],
        actions: [],
        style: {
            width: 215,
            height: 255,
            fontSize: 16,
            fontWeight: 400,
            lineHeight: '',
            // backgroundColor: '#221294',
            color: '',
            border: '',
            borderRadius: '',
            boxShadow: '',
            borderStyle: '',
            textAlign: 'center',
            fontFamily: 'PingFangSC',
            position: '',
        },
    }
    
    function run (global, data) {
        if (!global.globalRegisterObject || !Array.isArray(global.globalRegisterObject))
            global.globalRegisterObject = {}
        global.globalRegisterObject = data
    }

    run(this, register)
}
